#Copyright 2023 Sound Agriculture Company
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' Create Gene Percent Data Frames
#'
#' A function to create different subsets of the LongPercent df depending on the
#' column of interest
#'
#' @param LongPercent (df) - containing the methylation data as percents in
#' long format using `dcast()`
#' @param x (str) the column to compare to Gene * Zeroth_pos
#' @param function_name (function) an aggregation function such as mean, sd, or var
#' @return dcast_output (df) - a subset of the LongPercent dataframe
#' @examples
#' # Generate sample data
#' LongPercent <- data.frame(
#'  Gene = c('Gene1', 'Gene1', 'Gene1', 'Gene2', 'Gene2'),
#'  Zeroth_pos = c(1, 1, 1, 2, 2),
#'  Group = c('C', 'C', 'T', 'C', 'T'),
#'  Percent = c(30, 50, 0, 75, 80))
#'
#' # Aggregate based on Group using mean
#' create_gene_percent_x(LongPercent, 'Group', mean)
#'
#' # Aggregate based on Group using standard deviation
#' create_gene_percent_x(LongPercent, 'Group', sd)
#'
#' @import reshape2
#' @import Formula
#' @export

create_gene_percent_x <- function(LongPercent, x = 'Chromosome',
                                  function_name = mean) {
  formula <- Formula::as.Formula(paste('Gene * Zeroth_pos ~', x))
  if (x %in% colnames(LongPercent)) {
    dcast_output <- tryCatch({
      reshape2::dcast(LongPercent, formula, function_name, value.var = 'Percent',
                      na.rm = T)
    }, error = function(e) {
      print('Did not find a recognized function. Try mean or sd')
      return(NA)
    })
  } else {
    print(paste(x, 'is not a column found in the data. Try another column name.'))
    return(NA)
  }
  
  return(dcast_output)
}


#' Create DMR Object
#'
#' A function to clean the input data of methylation data. It filters the data
#' frame to contain only the columns of interest passed in as an argument and
#' removes rows where the mean methylation is 0.
#'
#' @param ZoomFrame (df) containing the input methylation data
#' @param experimental_design_df (df) containing the experimental design
#' @param colnames_of_interest *optional* (list of strings) - the columns to keep
#' in the analysis
#' @return out (list) - is a list of dataframes. This is the dmr object.
#' @import tidyverse
#' @export

create_dmr_obj <- function(ZoomFrame = dataframe,
                           experimental_design_df = dataframe) {
  # Clean the data
  print('Step 1: removing rows that contain 0 methylation')
  Inputpers <- dplyr::select(ZoomFrame, starts_with("Per"))
  Inputpers$MeanMeth <- rowMeans(Inputpers, na.rm=TRUE)
  ZoomFrame_filtered <- ZoomFrame[Inputpers$MeanMeth != 0,]
  
  # Important columns
  colnames_of_interest <- c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                            'Zeroth_pos', 'Plant')
  
  #QC Make sure the correct columns are present
  print('Step 2: checking for missing columns in experimental id')
  for (col in colnames_of_interest) {
    if (!col %in% colnames(ZoomFrame_filtered) & !col %in% c('Individual', 'Plant')){
      print(paste(col, 'not found in the ZoomFrame_filtered'))
    }
  }
  
  # Create columns if they are not present
  if (!'Zeroth_pos' %in% colnames(ZoomFrame_filtered)){
    print('Zeroth_pos column not found, running analysis on Positon column')
    ZoomFrame_filtered$Zeroth_pos <- ZoomFrame_filtered$Position
  }
  if ('Chr' %in% colnames(ZoomFrame_filtered)) {
    print('Changing name of Chr column to Chromosome')
    ZoomFrame_filtered$Chromosome <- ZoomFrame_filtered$Chr
  }
  if (!'Gene' %in% colnames(ZoomFrame_filtered)) {
    print('Gene column not found, running analysis on Chromosome column')
    ZoomFrame_filtered$Gene <- ZoomFrame_filtered$Chromosome
  }
  if (!'Plant' %in% colnames(experimental_design_df) & !'Individual' %in% colnames(experimental_design_df)) {
    stop('No Plant or Individual column name found in Experimental ID. One is necessary to continue')
  }
  if (!'Plant' %in% colnames(experimental_design_df)) {
    print('Plant column not found in the Experimental ID, using Individual')
    experimental_design_df$Plant <- experimental_design_df$Individual
  }
  if (!'Individual' %in% colnames(experimental_design_df)) {
    print('Individual column not found in the Experimental ID, using Plant')
    experimental_design_df$Individual <- experimental_design_df$Plant
  }
  if (!'Individual_Name' %in% colnames(experimental_design_df)) {
    print('Individual_Name column not found in the Experimental_ID, using Plant')
    experimental_design_df$Individual_Name <- experimental_design_df$Plant
  }
  
  # Convert the experimental ID 'Plant' column to character
  experimental_design_df$Plant <- as.character(experimental_design_df$Plant)
  
  # We want to order the input frame in such a way that it will be easy to recreate analysis
  print('Step 3: reordering ZoomFrame_filtered')
  ZoomFrame_filtered <- ZoomFrame_filtered[order(ZoomFrame_filtered[,'Gene'], ZoomFrame_filtered[,'Zeroth_pos']), ]
  
  # Create the Longer dataframes
  #------------------------------
  print('Step 4: creating longer dataframes')
  #Make percent methylation data long, based on each individual and each position
  LongPercent <- pivot_and_subset(ZoomFrame_filtered, 'Per', 'Percent',
                                  colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                           'Zeroth_pos', 'Individual'))
  LongPercent$Individual <- gsub("PerMeth_", "", LongPercent$Individual, perl = T)
  
  #Very similar steps, but for #methylated and unmethylated reads
  LongUnMeth <- pivot_and_subset(ZoomFrame_filtered, 'UnMeth', 'RD',
                                 colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                          'Zeroth_pos', 'Individual'))
  LongMeth <- pivot_and_subset(ZoomFrame_filtered, 'Meth', 'RD',
                               colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                        'Zeroth_pos', 'Individual'))
  
  #Replacing read depth of NA with 0
  LongUnMeth$RD[is.na(LongUnMeth$RD)] = 0
  LongMeth$RD[is.na(LongMeth$RD)] = 0
  
  #Creating column of total read depth
  LongMeth$total_RD <- LongMeth$RD + LongUnMeth$RD
  LongMeth$Individual <- gsub("Meth_","", LongMeth$Individual, perl = T)
  
  #QC to check that LongPercent contains the correct number of rows
  if (nrow(LongPercent) == nrow(ZoomFrame_filtered) * nrow(experimental_design_df)) {
    print('LongPercent contains the expected number of rows')
  } else {
    print(paste('LongPercent contains', nrow(LongPercent), 'rows. Expected:',
                (nrow(ZoomFrame_filtered) * nrow(experimental_design_df)), 'rows'))
  }
  
  print('Step 5: merging long files with experimental_design_df to annotate')
  # Merge Long files with Exp_ID to annotate
  print('Step 6: annotating long files with experimental_design data frame')
  LongPercent <- dplyr::left_join(LongPercent, experimental_design_df, by = c('Individual' = 'ID'))
  LongMeth <- dplyr::left_join(LongMeth, experimental_design_df, by = c('Individual' = 'ID'))
  
  # Aggregate
  print('Step 7: aggregating by plant')
  
  LongPercent$total_RD<-LongMeth$total_RD
  
  if(nrow(experimental_design_df)!=length(unique(experimental_design_df$Individual))){
    
    LongPercent <- LongPercent %>%
      mutate(Percent = weighted.mean(Percent, total_RD, na.rm = T), .by=c(Plant,Group, Chromosome, Position, Zeroth_pos))
    
    LongMeth <- LongMeth %>%
      group_by(Gene, Zeroth_pos, Plant, Position, CX, Strand, Group, Chromosome) %>%
      summarize(total_RD = sum(total_RD, na.rm = T))
  }
  
  LongMeth <- LongMeth[,c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                          'Zeroth_pos', 'Plant', 'total_RD', 'Group')]
  
  # Save all the outputs
  out <- list()
  out$ZoomFrame_filtered <- ZoomFrame_filtered
  out$LongPercent <- LongPercent
  out$LonUnMeth <- LongUnMeth
  out$LongMeth <- LongMeth
  out$experimental_design_df <- experimental_design_df
  out$Inputpers <- Inputpers
  
  return(out)
}


#' Subset Data Frames to Contain Only Columns of Interest
#'
#' Keep only the necessary columns from a given data frame
#'
#' @param df (df) data frame to subset
#' @inheritParams create_dmr_obj
#' @return subsetted_df (df) - data frame with only the columns of interest
#' @examples
#' # Generate data to subset
#' df <- data.frame(
#'  x = c(1, 2, 3, 4),
#'  y = c(6, 7, 8, 9),
#'  z = c(14, 23, 15, 4))
#'
#' # Subset the data
#' subset_cols(df, c('x', 'z'))
#'
#' @export

subset_cols <- function(df,
                        colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                 'Zeroth_pos', 'Individual')) {
  subsetted_df <- df[,c(colnames_of_interest, colnames(df)[ncol(df)])]
  
  return(subsetted_df)
}



#' Arrange Data into Long Format and Subset
#'
#' This function is used to get data into LongPercent and LongMeth formats to
#' allow for summary analysis. This function utilizes `tidyr::pivot_longer()`
#' and `subset_cols()` from this package.
#'
#' @param data (df) - the `ZoomFrame_filtered`
#' @param starts_with_cols (str) - the string pattern that the columns start with
#' @inheritParams tidyr::pivot_longer
#' @inheritParams create_dmr_obj
#' @return pivoted_and_subsetted_df (df) - the cleaned data frame that has been
#' pivoted to be longer and subsetted to only include the important columns.
#' @import tidyr
#' @export

pivot_and_subset <- function(data,
                             starts_with_cols = 'start',
                             values_to,
                             colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                      'Zeroth_pos', 'Individual')){
  # Pivot data
  pivoted_df <- tidyr::pivot_longer(data, cols = starts_with(starts_with_cols),
                                    names_to = 'Individual', values_to = values_to)
  
  # Subset columns
  pivoted_and_subsetted_df <- subset_cols(pivoted_df, colnames_of_interest)
  
  return(pivoted_and_subsetted_df)
}



#' Building Individual Methylation Columns
#'
#' Set up the output frame to include individual methylation change and Read
#' Depth columns
#'
#' @param Exp_ID_Treated (df) - containing the experimental design
#' @param Output_Frame (df) - the Output_Frame
#' @param GenePercentPlant (df) - summary dataframe built from `create_gene_percent_x()`
#' containing % methylation for each Plant
#' @param GenePercentGroup (df) - summary dataframe built from `create_gene_percent_x()`
#' containing % methylation for groups
#' @param GeneDepthPlant (df) - summary dataframe containing read depth for individuals
#' @param control (str) - the control variable in GenePercentGroup
#' @return Output_Frame (df) - the updated Output_Frame with 3 new columns for each individual in
#' the `Exp_IF_Treated` parameter
#' @export

create_cols_for_individuals <- function(Exp_ID_Treated,
                                        Output_Frame,
                                        GenePercentPlant,
                                        GeneDepthPlant,
                                        GenePercentGroup,
                                        control = 'C') {
  for(id in unique(Exp_ID_Treated$Plant)) {
    Output_Frame$NewZ <- 0
    # Name this column using trickery
    colnames(Output_Frame)[ncol(Output_Frame)] <- paste(id, "Z", sep="_")
    # Create new column that is difference in percent methylation between individual "i" and the control average
    Output_Frame[,ncol(Output_Frame) + 1] <- GenePercentPlant[,id] - GenePercentGroup[[control]]
    # Name this column
    names(Output_Frame)[ncol(Output_Frame)] <- paste(id, "MethChange", sep="_")
    # Create a column that is read depth for that individual
    Output_Frame[,ncol(Output_Frame) + 1] <- GeneDepthPlant[,id]
    # Name this column
    names(Output_Frame)[ncol(Output_Frame)] <- paste(id, "RD", sep="_")
  }
  return(Output_Frame)
}


#' Create Methyl Summary
#'
#' This function creates the methyl_summary that the group and individual DMR
#' functions rely on for their analysis. It includes some quality control checks
#' to make sure the output is in the correct format.
#'
#' @inheritParams create_cols_for_individuals
#' @param dmr_obj the dmr object containing the experimental design and raw data
#' @param treated the string representing the treated group
#' @param additional_summary_cols a nested list of parameters to create additional
#' summary columns. Each nested list will be a tuple where the first value is
#' the summary stats function (e.g. sd, mean, var) and the second value is the
#' string name of the column on which to run the summary statistic function
#'
#' @export
create_methyl_summary <- function(dmr_obj, control = 'C', treated = 'T',
                                  colnames_of_interest = c('Chromosome', 'Gene',
                                                           'Position', 'Strand', 'CX',
                                                           'Zeroth_pos', 'Plant'),
                                  additional_summary_cols = list()) {
  # Create the summary files
  GeneDepthPlant <- dcast(dmr_obj$LongMeth,Gene*Zeroth_pos~Plant,mean,
                          value.var = "total_RD", na.rm=TRUE)
  GenePercentGroup <- create_gene_percent_x(dmr_obj$LongPercent, 'Group', mean)
  GenePercentPlant <- create_gene_percent_x(dmr_obj$LongPercent, 'Plant', mean)
  
  # QC
  # Make sure the GenePercentX dfs are the same length as the Zoomframe_filtered
  # and in the same order
  if (sum(GenePercentPlant$Zeroth_pos == dmr_obj$ZoomFrame_filtered$Zeroth_pos) != nrow(dmr_obj$ZoomFrame_filtered) |
      sum(GenePercentPlant$Gene == dmr_obj$ZoomFrame_filtered$Gene) != nrow(dmr_obj$ZoomFrame_filtered)) {
    print('Output is in a different order. Try running again.')
  }
  
  # Create experimental_design_df_treated
  experimental_design_df_treated <- dmr_obj$experimental_design_df[dmr_obj$experimental_design_df$Group != control,]
  
  # Create the beginnings of the Output statistic data frame
  Output_Frame <- dmr_obj$ZoomFrame_filtered[,colnames_of_interest[-length(colnames_of_interest)]]
  
  # Create 3 new cols for each individual
  Output_Frame <- create_cols_for_individuals(experimental_design_df_treated,
                                              Output_Frame,
                                              GenePercentPlant, GeneDepthPlant,
                                              GenePercentGroup, control)
  
  # QC
  # Checking Output_Frame created the three new cols for each individual
  if (ncol(Output_Frame) == (length(colnames_of_interest) - 1) + 3 * length(unique(experimental_design_df_treated$Plant))) {
    print('Number of columns in methyl_summary is correct')
  } else {
    print('The number of columns in methyl_summary is incorrect. Double check there are no duplicates')
    print(paste('Expected:', (length(colnames_of_interest) - 1) + 3 * length(unique(experimental_design_df_treated$Plant)),
                'Found:', ncol(Output_Frame)))
  }
  
  #Add in any summary statistic columns, such as this one
  Output_Frame <- cbind(Output_Frame,GenePercentPlant[,3:ncol(GenePercentPlant)])
  Output_Frame$Treat_V_Control <- GenePercentGroup[[treated]] - GenePercentGroup[[control]]
  Output_Frame$Control <- GenePercentGroup[[control]]
  Output_Frame$Treated <- GenePercentGroup[[treated]]
  
  # Additional summary columns
  if (length(additional_summary_cols) != 0) {
    for (tuple in additional_summary_cols) {
      GenePercentX = create_gene_percent_x(dmr_obj$LongPercent, x = tuple[[2]],
                                           function_name = get(tuple[[1]]))
      GenePercentX <- GenePercentX %>% select(-c(Gene, Zeroth_pos))
      colnames(GenePercentX) = paste0(colnames(GenePercentX), '_',
                                      tuple[[1]])
      Output_Frame <- cbind(Output_Frame, GenePercentX)
    }
  }
  
  return(Output_Frame)
}


#' Subset Methyl Summary
#'
#' A function to subset the methyl_summary file to only include individuals of
#' interest in the analysis
#'
#' @param methyl_summary (df) - the input data
#' @param individuals_to_keep (list of strings) - the individuals to keep for
#' analysis
#' @return methyl_summary_subset (df) - the data only including the individuals
#' for analysis
#'
#' @export
subset_methyl_summary <- function(methyl_summary, individuals_to_keep) {
  methyl_summary_subset <- methyl_summary %>%
    select(Chromosome, Gene, Position, Strand, CX, Zeroth_pos,
           contains(individuals_to_keep), Treat_V_Control, Control)
  return(methyl_summary_subset)
}

#' Create Fixed Effects
#'
#' A function to create the string combining fixed effects that will be passed
#' into `create_function()`
#'
#' @param fixed (list of strings) - the fixed effects elements
#' @return fixed_effects (str) - the fixed effects properly formatted
#' to be passed into `create_function()`
#' @examples
#' # create multiple independent fixed effects
#' create_fixed_effects(c('Group', 'Individual'))
#' # [1] "Group + Individual"
#'
#' # Create fixed effects with interactions
#' create_fixed_effects(c('Group * Individual'))
#' # [1] "Group * Individual"
#' @export

create_fixed_effects <- function(fixed = c('effect1', 'effect2')) {
  fixed_effects = ''
  if (length(fixed) >= 1) {
    fixed_effects = fixed[1]
  }
  if (length(fixed) > 1) {
    for (i in fixed[2:length(fixed)]) {
      fixed_effects = paste0(fixed_effects, ' + ', i)
    }
  }
  return(fixed_effects)
}


#' Create Random Effects
#'
#' Create a string combining the list of random effects to be passed into the
#' `create_formula()` function
#'
#' @param random (list of strings) - the random effects elements
#' @return random_effects (str) - the random effects properly formatted
#' @examples
#' # Create independent random effects
#' create_random_effects(c("Group", "Individual"))
#' # [1] "(1 | Group) + (1 | Individual)"
#'
#' # Create random effects with an interaction
#' create_random_effects(c("Group * Individual"))
#' # [1] "(1 | Group * Individual)"
#'
#' @export

create_random_effects <- function(random = c('Group', 'ID')) {
  random_effects = ''
  if (length(random) >= 1) {
    random_effects = paste0('(1|', random[1], ')')
  }
  if (length(random) > 1) {
    for (i in random[2:length(random)]) {
      random_effects = paste0(random_effects, ' + ', '(1|', i, ')')
    }
  }
  return(random_effects)
}


#' Create Formula
#'
#' Combine the fixed and random effects into the formula to be used
#' in the model
#'
#' @param fixed (str) - the fixed effects variables. Note: this
#' value **cannot** be 'ID'. ID is used to merge data together downstream for
#' running the model so including the value in the effects will break the model.
#' @param random (str) - the random effects variables. Note: this
#' value **cannot** be 'ID'. ID is used to merge data together downstream for
#' running the model so including the value in the effects will break the model.
#' @return effects_formula (formula) - a formula of the mixed effects
#' @examples
#' # Create formula of independent and random effects
#' create_formula(fixed = c('Group'), random = c('Individual'))
#' # [1] "cbind(Meth, UnMeth) ~ Group + (1 | Individual)"
#'
#' create_formula(fixed = c('Group', 'Individual'), random = c('Plant * Gene'))
#' # [1] "cbind(Meth, UnMeth) ~ Group + Individual + (1 | Plant * Gene)"
#' @import stats
#' @export

create_formula <- function(fixed, random) {
  fixed_effects <- create_fixed_effects(fixed)
  random_effects <- create_random_effects(random)
  
  if (fixed_effects != '' & random_effects != '') {
    effects = paste(random_effects, '+', fixed_effects)
  } else if (fixed_effects != '' & random_effects == '') {
    effects = fixed_effects
  } else if  (fixed_effects == '' & random_effects != '') {
    effects = random_effects
  }
  #  Create the formula
  formula = stats::as.formula(paste0('cbind(Meth, UnMeth) ~ ', effects))
  return(formula)
}


#' Save Model Summary
#'
#' Update the `Output_Frame` dataframe for a given row with the summary statistics
#' provided by the model
#'
#' @param i (int) - the row number of the dataframe
#' @param Output_Frame (df) - all the information
#' @param model_summary (df) - the summary statistics from the model
#' @param ind_name (str) - *optional* containing the name of the z score column for
#' individual DMR analysis
#' @return Output_Frame (df) - the data frame with the proper row updated to include
#' the summary statistics
#' @export

save_model_summary <- function(i, Output_Frame, model_summary, ind_name = '') {
  # Get the row names
  row_names <- rownames(model_summary)[2:length(rownames(model_summary))]
  
  for (name in row_names) {
    if (ind_name == '') {
      # Group Analysis
      Output_Frame[i, paste0('Z_', name, '_small')] = model_summary[name, 'z value']
      Output_Frame[i, paste0('Estimate_', name, '_small')] = model_summary[name, 'Estimate']
      Output_Frame[i, paste0('StdErr_', name, '_small')] = model_summary[name, 'Std. Error']
    } else {
      # Individual Analysis
      Output_Frame[i, ind_name] = model_summary[name, 'z value']
    }
  }
  return(Output_Frame)
}


#' Run Binomial Model
#'
#' This function runs the glmer function using a binomial model for a given
#' optimizer function
#'
#' @param LM (df) - the information to put in the model, usually this is
#' in a "long" format
#' @param i (int) - the row number
#' @param Output_Frame (df) - all the summary information
#' @param formula (formula) - the formula to use in the model
#' @param optimizer_func (str) - the optimizer function to use in the model
#' @return Output_Frame (df) - the data frame containing updated summary information
#' @import lme4
#' @export
#'

run_binomial <- function(LM, i = int, formula,
                         optimizer_func = 'optimizer', control=" ", target_variable="Treatment") {
  LM[,target_variable]<-as.factor(LM[,target_variable])
  LM[,target_variable] <- relevel(LM[,target_variable], ref = control)
  binom_model <- glmer(formula, data=LM, family = binomial,
                       glmerControl(check.conv.grad = .makeCC(action = "stop",
                                                              tol = 2e-3, relTol = NULL),
                                    optimizer=optimizer_func, optCtrl = list(maxfun = 500000)))
  # Outputs of this model
  model_summary <- as.data.frame(summary(binom_model)$coefficients)
  return(model_summary)
}


#' Run Model
#'
#' Function to run the correct model
#'
#' @param data (df) - the information to put in the model, usually this is
#' in "long" format
#' @inheritParams run_binomial
#' @param individual_name_z (str) - *optional* the name of the z column when running
#' individual DMR analysis
#' @return input_frame (df) - updated with the summary data from the model
#' @export
#'

run_model <- function(data, i, input_frame, formula, model_type,
                      individual_name_z = '', control=" ", target_variable="Treatment"){
  if (model_type == 'binomial') {
    tryCatch({
      ith_model_summary <- run_binomial(data, i, formula, 'bobyqa', control, target_variable)
      input_frame <- save_model_summary(i, input_frame, ith_model_summary,individual_name_z)
      # If that model didn't converge, it tried again with a different optimizer, allows ~20% more model convergence
    },error = function(e){tryCatch({ print(paste(i, "No bobyqa Converge, trying Nelder"))
      # Run the model with Nelder_Mead optimizer
      ith_model_summary <- run_binomial(data, i, formula, 'Nelder_Mead', control, target_variable)
      input_frame <- save_model_summary(i, input_frame, ith_model_summary,individual_name_z)
    }, error=function(e){print(paste(i, "No Converge"))})
    })
  } else if (model_type == 'beta-binomial') {
    tryCatch({
      #The model in the individual version will generally be this, but if complex design, potentially can be multi-factorial
      beta_binomial <- glmmTMB(formula, data=data,
                               family=betabinomial(link = "logit"),
                               control=glmmTMBControl(
                                 optimizer=optim, optArgs=list(method="BFGS")))
      # Save the model output
      ith_model_summary <- as.data.frame(summary(beta_binomial)$coefficients$cond)
      input_frame <- save_model_summary(i, input_frame, ith_model_summary,
                                        individual_name_z)
    }, error=function(e){
      #print(paste(i, "No Converge"))
      paste(i, 'No Converge')
    })
  } else {
    print('Please choose a model type of "binomial" or "beta-binomial".')
  }
  return(input_frame)
}

#' Group DMR Analysis
#'
#' To run a binomial model to compare the methylation between groups
#'
#' @param methyl_sum (df) - the read depth and methylation
#' change information
#' @param ZoomFrame_filtered (df) - the percent methylation information
#' @param experimental_design_df (df) - the experimental design
#' @inheritParams create_formula
#' @param reads_threshold (int) - the number of reads that are each
#' methylated and unmethylated. This is important since data containing only one
#' methylated read is unlikely to provide statistical power to our analysis. A
#' value of 3 here means that the read depth is *at least* the depth provided by
#' the threshold. Both the methylated and unmethylated samples need a read depth
#' greater than or equal to this threshold in order to be considered for the model.
#' @inheritParams subset_cols
#' @return methyl_sum (df) - Output_Frame with the summary statistics from the model
#' @export

group_DMR <- function(methyl_sum, ZoomFrame_filtered, experimental_design_df, fixed = c('Group'),
                      random = c('Plant'), reads_threshold = 3, model = 'binomial',
                      colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                               'Zeroth_pos', 'Individual'), control=" ", target_variable="Treatment") {
  #  Create the model formula first
  formula <- create_formula(fixed, random)
  print(formula)
  #  Get the number of columns in the Output_Frame dataframe
  original_methyl_sum_col_number <- ncol(methyl_sum)
  # The modelling here is the most "delicate" part of the operation.  Options include:
  # (A) cbind(Meth, UnMeth) ~ (1|Plant) + Treatment
  # (B) cbind(Meth, UnMeth) ~ (1|Plant) + Treatment + Generation
  # (C) cbind(Meth, UnMeth) ~ (1|Plant) + Treatment + Generation +Treatment*Generation
  # (D) cbind(Meth, UnMeth) ~ (1|Plant) + Gene_Expression
  # (E) cbind(Meth, UnMeth) ~ (1|Plant) + Phenotype
  # Loop to run groupwise analysis for each BP
  for(i in 1:nrow(methyl_sum)){
    ZoomFrame_filtered_temp <- ZoomFrame_filtered[i,]
    # Make long version of input frame for the i'th cytosine row
    LM <- pivot_and_subset(ZoomFrame_filtered_temp, 'Meth', 'Meth',
                           colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                    'Zeroth_pos', 'Individual'))
    LM$Individual <- gsub("Meth_","", LM$Individual, perl = T)
    # For rows with at least X(3) methylated reads across all individuals, move forward
    if(sum(as.numeric(LM$Meth), na.rm=TRUE) >= reads_threshold){
      # Do the same thing for unmethylated reads
      LUM <- pivot_and_subset(ZoomFrame_filtered_temp, 'UnMeth', 'UnMeth',
                              colnames_of_interest = c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                                                       'Zeroth_pos', 'Individual'))
      LM <- cbind(LM,LUM[,ncol(LUM)])
      # Merge with experimental_design_df to allow for DML testing for that base
      LM <- LM %>% left_join(experimental_design_df, by=c('Individual'='ID'))
      # Has to have Y unmethylated reads across all individuials
      if(sum(as.numeric(LM$UnMeth), na.rm=TRUE) >= reads_threshold){
        # Run the model and save the output
        methyl_sum <- run_model(LM, i, methyl_sum, formula, model, control=control, target_variable=target_variable)
        rm(LM, LUM, ZoomFrame_filtered_temp)
      }
    }
  }
  #  Replace NA values in the new model columns with 0s (not the existing columns)
  if (ncol(methyl_sum) > original_methyl_sum_col_number) {
    new_cols <- (original_methyl_sum_col_number + 1):ncol(methyl_sum)
    methyl_sum[, new_cols][is.na(methyl_sum[, new_cols])] = 0
  }
  return(methyl_sum)
}

#' Individual DMR Analysis
#'
#' Purpose: to run individual DMR analysis
#'
#' @inheritParams group_DMR
#' @param control (str) - the control variable
#' @return methyl_sum (df) - a data frame with additional columns
#' @export

individual_DMR <- function(methyl_sum, ZoomFrame_filtered, experimental_design_df,
                           fixed = c('Group'), random = c('Individual'),
                           reads_threshold = 3, control = 'C', model = 'beta-binomial',
                           colnames_of_interest = c('Chromosome', 'Gene', 'Position',
                                                    'Strand', 'CX', 'Zeroth_pos', 'Individual')) {
  
  # Obtain the formula
  formula <- create_formula(fixed, random)
  print(formula)
  
  Exp_ID_Treated <- experimental_design_df[experimental_design_df$Group == 'T',]
  
  # Create a progress bar
  pb = txtProgressBar(min = 0, max = nrow(methyl_sum), initial = 0, style = 3)
  
  #This model compares each of the treated individuals with the whole group of control individuals.
  for(i in 1:nrow(methyl_sum)){
    #First steps up until "For k in ..." are the same as group models.
    LM <- pivot_and_subset(ZoomFrame_filtered[i,], 'Meth', 'Meth',
                           colnames_of_interest)
    LM$Individual <- gsub("Meth_", "", LM$Individual, perl = T)
    
    if(sum(as.numeric(LM$Meth), na.rm=TRUE) >= reads_threshold){
      LUM <- pivot_and_subset(ZoomFrame_filtered[i,], 'UnMeth', 'UnMeth',
                              colnames_of_interest)
      LM <- cbind(LM, LUM[,ncol(LUM)])
      LM <- merge(LM, experimental_design_df, by.x="Individual", by.y="ID", all=FALSE)
      
      #Here we return to the Exp_ID_Treated file, this file has only individuals that are in a treated group. Starting with the first row in this file.
      for(k in 1:nrow(Exp_ID_Treated)){
        #Make subset version of the longmeth file that only includes the control individual and you individual of interest.  Need to confirm Exp_ID_Treated$ID corresponds to LM$Individual
        LMEX <- LM[LM$Group == control | LM$Individual == Exp_ID_Treated$ID[k], ]
        individual_name <- Exp_ID_Treated$Individual_Name[k]
        individual_name_z <- paste0(individual_name, '_Z')
        
        #Now, if has more than 2 meth and unmeth cytosines, runs the statistical model
        if(sum(as.numeric(LMEX$UnMeth), na.rm=TRUE) > reads_threshold & sum(as.numeric(LMEX$Meth), na.rm=TRUE) > reads_threshold){
          # Run the model
          methyl_sum = run_model(LMEX, i, methyl_sum, formula, model,
                                 individual_name_z = individual_name_z)
        }
      }
    }
    setTxtProgressBar(pb, i)
  }
  close(pb)
  return(methyl_sum)
}

#' DMR Analysis
#'
#' This function runs the DMR analysis based on whether analysis is between
#' groups or for an individual compared to a group.
#'
#' @inheritParams individual_DMR
#' @param analysis_type (str) - either "individual" or "group"
#' @param dmr_obj (list) - the dmr_object containing the experimental design df and zoomFrame_filtered
#' @return Output_Frame (df)
#' @export

find_DMR<- function(methyl_sum, dmr_obj, fixed = c('Group'),
                    random = c('Plant'), reads_threshold = 3,
                    model, control = " ", analysis_type, target_variable = "Treatment") {
  # The required columns
  colnames_of_interest <- c('Chromosome', 'Gene', 'Position', 'Strand', 'CX',
                            'Zeroth_pos', 'Plant')
  # The models pair methyl_sum row i with ZoomFrame_filtered row i, so put the ZoomFrame
  # in methyl_sum's row order (they differ e.g. after changepoint_analysis(), which
  # groups rows by context)
  dmr_obj$ZoomFrame_filtered <- align_zoomframe(methyl_sum, dmr_obj$ZoomFrame_filtered)
  if (tolower(analysis_type) == 'group') {
    Output_Frame <- group_DMR(methyl_sum, dmr_obj$ZoomFrame_filtered,
                              dmr_obj$experimental_design_df,
                              fixed = fixed,random = random, colnames_of_interest,
                              reads_threshold = reads_threshold, model = model, control=control, target_variable=target_variable)
  } else if (tolower(analysis_type) == 'individual') {
    Output_Frame <- individual_DMR(methyl_sum, dmr_obj$ZoomFrame_filtered,
                                   dmr_obj$experimental_design_df,
                                   fixed = fixed, random = random,
                                   reads_threshold = reads_threshold,
                                   control = control, model = model)
  } else {
    print(paste(analysis_type, 'analysis type not supported. Please try "individual" or "group"'))
  }
  return(Output_Frame)
}

#' Put ZoomFrame_filtered in the row order of a methyl summary
#'
#' Matches rows on Chromosome, Gene, Position, Strand and CX. Stops if a cytosine of
#' `methyl_sum` is missing from the ZoomFrame or if keys are duplicated.
#'
#' @param methyl_sum (df) - methyl summary
#' @param zoomframe (df) - `dmr_obj$ZoomFrame_filtered`
#' @return the ZoomFrame rows in `methyl_sum` order
#' @export
align_zoomframe <- function(methyl_sum, zoomframe) {
  keys <- c('Chromosome', 'Gene', 'Position', 'Strand', 'CX')
  miss <- setdiff(keys, intersect(names(methyl_sum), names(zoomframe)))
  if (length(miss)) stop("Cannot match methyl_sum to ZoomFrame_filtered: missing ", paste(miss, collapse = ", "))
  k_ms <- do.call(paste, c(as.list(as.data.frame(methyl_sum)[keys]), sep = "|"))
  k_zf <- do.call(paste, c(as.list(as.data.frame(zoomframe)[keys]), sep = "|"))
  if (length(k_ms) == length(k_zf) && identical(k_ms, k_zf)) return(zoomframe)
  if (anyDuplicated(k_ms) || anyDuplicated(k_zf)) stop("Duplicated cytosines (Chromosome, Gene, Position, Strand, CX) - cannot match methyl_sum to ZoomFrame_filtered.")
  idx <- match(k_ms, k_zf)
  if (anyNA(idx)) stop(sum(is.na(idx)), " cytosines of methyl_sum are not in dmr_obj$ZoomFrame_filtered (e.g. ",
                       paste(head(k_ms[is.na(idx)], 3), collapse = "; "), ").")
  message("find_DMR: methyl_sum and ZoomFrame_filtered were in a different row order - matched by cytosine.")
  zoomframe[idx, , drop = FALSE]
}

#'  Find the Columns for Changepoint Analysis
#'
#' This function is used to find the column names on which to run changepoint
#' analysis from the `group_DMR()` or `individual_DMR()` output frames.
#' These columns are usually the Z score column created from the `run_model`
#' model summary. The Z score column is based on the fixed effects that are
#' passed into the model. Note: any column can be passed into the changepoint
#' analysis function, the output of this function are the columns deemed to
#' provide the greatest use to the analysis.
#'
#' @param DMR_output (df) - the DMR Analysis output
#' @return z_cols (list of strings) - a list of strings representing the potential
#' column names that are suggested to be used in the changepoint analysis.
#' @export

find_changepoint_col_options <- function(DMR_output, Output_Frame = Output_Frame) {
  #added_cols <- colnames(DMR_output[c((ncol(Output_Frame) + 1):ncol(DMR_output))])
  z_cols <- colnames(DMR_output)[grepl('Z_', colnames(DMR_output))]
  
  print(z_cols)
}

#' Store Changepoint Information
#'
#' Add the important changepoint summary info to the dataframe from
#' which the changepoints were found
#'
#' @param whole_df (df) - all the information for one gene
#' @param changepoint (df) - the changepoint summary
#' @param col_name (str) - the name of the column upon which the changepoint analysis
#' is being conducted
#' @return whole_df (df) - information for one gene including the
#' changepoint summary
#' @export

add_changepoint_info <- function(whole_df, changepoint, col_name) {
  # The new column names
  MethRegionName <- paste0('MethRegion_', col_name)
  MethRegionLengthName <- paste0('MethRegionLength_', col_name)
  MethGroupName <- paste0('MethGroup_', col_name)
  MethCytosinesName <- paste0('MethCytosines_', col_name)
  
  if (typeof(changepoint) != 'NULL') {
    changepoint <<- changepoint
    changepoints <- changepoint@cpts
    
    #Add in the first and last cytosine if needed for the changepoint start and stop sites
    if ((1 %in% changepoints) & (nrow(whole_df) %in% changepoints)) {
      start <- c(1, changepoints[-length(changepoints)]+1)
      stop <- c(changepoints[-length(changepoints)], nrow(whole_df))
      #start <- changepoints+1
      #stop <- c(changepoints[-1] - 1, nrow(whole_df))
    } else if ((1 %in% changepoints) & (!nrow(whole_df) %in% changepoints)) {
      start <- c(1, changepoints[-length(changepoints)]+1)
      stop <- c(changepoints[-length(changepoints)], nrow(whole_df))
      #start <- changepoints
      #stop <- c(changepoints[-1] - 1, nrow(whole_df))
    } else if ((!1 %in% changepoints) & (nrow(whole_df) %in% changepoints)) {
      start <- c(1, changepoints[-length(changepoints)]+1)
      stop <- c(changepoints[-length(changepoints)], nrow(whole_df))
    } else {
      start <- c(1, changepoints[-length(changepoints)]+1)
      stop <- c(changepoints[-length(changepoints)], nrow(whole_df))
      #start <- changepoints
      #stop <- changepoints - 1
    }
    
    BP_CG <- data.frame(cbind(start,stop))
    BP_CG$DifMean <- param.est(changepoint)$mean
    
    # Add the start and stop sites at a given position
    for(i in 1:nrow(BP_CG)){
      BP_CG[i, 'BPStart'] <- whole_df[BP_CG[i,'start'], 'Position']
      BP_CG[i, 'BPStop'] <- whole_df[BP_CG[i,'stop'], 'Position']
    }
    
    # Find the MethRegion, MethGroupName, and MethRegionLength
    whole_df[MethRegionName] = 0
    whole_df[MethRegionLengthName] = 0
    whole_df[MethCytosinesName] = 0
    for(i in 1:nrow(BP_CG)){
      whole_df[c(BP_CG[i, 'start']:BP_CG[i, 'stop']),MethRegionName] <- BP_CG[i, 'DifMean']
      whole_df[c(BP_CG[i, 'start']:BP_CG[i, 'stop']),MethRegionLengthName] <- abs(as.numeric(BP_CG[i, 'BPStop']) -
                                                                                    as.numeric(BP_CG[i, 'BPStart']))
      whole_df[c(BP_CG[i, 'start']:BP_CG[i, 'stop']),MethGroupName] <- i
      whole_df[c(BP_CG[i, 'start']:BP_CG[i, 'stop']),MethCytosinesName]<-BP_CG$stop[i]-BP_CG$start[i]+1
    }
    
  } else {
    if (nrow(whole_df) == 1) {
      #This is in case there are no changepoints bc the data isn't big enough
      whole_df[MethRegionName] = whole_df[[col_name]]
      whole_df[MethRegionLengthName] = 1
      whole_df[MethGroupName] = 1
      whole_df[MethCytosinesName] = 1
    } else {
      whole_df[nrow(whole_df) + 1,] <- NA
      whole_df[1, MethRegionName] = whole_df[[col_name]]
      whole_df[1, MethRegionLengthName] = 0
      whole_df[1, MethGroupName] = 1
      whole_df[MethCytosinesName] = 1
    }
  }
  
  return(whole_df)
}

#' Find CPT Mean
#'
#' Purpose: find the changepoints based on mean values and include error catches
#'
#' @inheritParams changepoint_analysis
#' @param data (df) - the dataframe that has been subsetted for the gene and cytosine
#' context
#' @param penalty (int) - the penalty value to include for the changepoint analysis
#' @return changepoint_object (S4) - containing the changepoint information
#' @import changepoint
#' @export

find_cpt_mean <- function(data, z_col, penalty){
  changepoint_object <- tryCatch(
    {
      # Filter out any rows containing NAs
      data <- data[is.na(data[[z_col]]) == 0, ]
      
      # Run the changepoing analysis
      changepoint::cpt.mean(data[[z_col]], method = 'PELT',
                            penalty = 'Manual', pen.value = penalty)
    }, error = function(e) {
      #print(e)
      warning('No changepoints found, data contains 1 or 0 rows')
      return(NULL)
    })
  return(changepoint_object)
}


#' Plot Changepoints Volcano
#'
#' Create a volcano plot of the changepoints
#'
#' @param data (df) - containing the cytosines with their percent methylation
#' @param changepoint_obj (S4) - the S4 object created from finding the changepoints
#' @param gene_name (str) - the name of the gene
#' @param penalty_val (int) - the penalty value being used
#' @param cyt_context (str) - the cytosine context
#' @param z_col (str) - the column upon which the changepoints are calculated
#' @return changepoint_plot (plot) - the volcano plot of the changepoints
#' @import ggplot2
#' @import tidyverse
#' @export

plot_changepoints_volcano <- function(data, changepoint_obj, gene_name, 
                                      penalty_val, cyt_context, z_col) {
  tryCatch({
    changepoint_df <- data.frame(matrix(ncol=2, nrow=0))
    colnames(changepoint_df) <- c('Average Z-score', 'Changepoint Length')
    # Get the segment data
    for (i in 1:length(changepoint_obj@cpts)) {
      if (i == 1) {
        start = 0
      } else {
        start = changepoint_obj@cpts[i -1] + 1
      }
      subset = data[start:changepoint_obj@cpts[i],c(z_col, 'Zeroth_pos')]
      changepoint_df[i,] = c(mean(subset[[z_col]], na.rm = TRUE), 
                             max(subset['Zeroth_pos'], na.rm = TRUE) - min(subset['Zeroth_pos'], na.rm = TRUE) + 1)
    }
    plot <- changepoint_df %>%
      ggplot(aes(x = log(`Changepoint Length` + 1), y = `Average Z-score`)) +
      geom_point(aes(color = abs(`Average Z-score`))) +
      theme_bw() +
      labs(x = "log(1 + Changepoint Length)", y = paste("Average", z_col),
           color = paste0("abs(", z_col, ")"),
           title = paste("Changepoints for", cyt_context, gene_name, "; penalty",
                         penalty_val)) +
      scale_color_gradient(low = 'grey', high = 'red')
    
    print(plot)
    return(plot)
  }, error = function(e) {
    return(warning('Figure could not be created for:', gene_name))
  })
}


#' Plot Changepoints Line
#'
#' Create a line plot of the changepoints
#'
#' @param data (df) - containing the cytosines with their percent methylation
#' @param changepoint_obj (S4) - the S4 object created from finding the changepoints
#' @param gene_name (str) - the name of the gene
#' @param penalty_val (int) - the penalty value being used
#' @param cyt_context (str) - the cytosine context
#' @param z_col (str) - the column upon which the changepoints are calculated
#' @return changepoint_plot (plot) - the line plot of the changepoints
#' @import ggplot2
#' @import tidyverse
#' @export

plot_changepoints_line <- function(data, changepoint_obj, gene_name, 
                                   penalty_val, cyt_context, z_col) {
  tryCatch({
    # Get the segment data
    segment_data = data.frame(matrix(nrow = 0, ncol = 4))
    colnames(segment_data) = c('x', 'xend', 'y', 'yend')
    for (i in 1:length(changepoint_obj@cpts)) {
      group_data = data[data[[paste0('MethGroup_', z_col)]] == i, 'Zeroth_pos']
      segment_data[i, 'x'] = min(group_data)
      segment_data[i, 'xend'] = max(group_data)
      segment_data[i, 'y'] = changepoint_obj@param.est$mean[i]
      segment_data[i, 'yend'] = changepoint_obj@param.est$mean[i]
    }
    
    # Create basic plot
    plot <- data %>%
      ggplot(aes(x = Zeroth_pos, y = !!sym(z_col))) +
      geom_line(linewidth = 0.5) +
      theme(panel.background = element_blank(), axis.line = element_line()) +
      labs(title = paste('Changepoints for', cyt_context, gene_name, '; penalty',
                         penalty_val)) +
      scale_x_continuous(expand = c(0, 0))
    
    # Add in the segments
    plot <- plot + geom_segment(data = segment_data,
                                aes(x = x, y = y, xend = xend, yend = yend),
                                color = 'red')
    print(plot)
    return(plot)
  }, error = function(e) {
    return(warning('Figure could not be created for:', gene_name))
  })
}

#' Save Plot
#' 
#' Save a plot
#' 
#' @param file_name (str) - the name of the filepath
#' @param plot_obj (obj) - the plot object to save
#' @export
#' 

save_plot <- function(file_name, plot_obj) {
  png(file=file_name)
  print(plot_obj)
  dev.off()
}


#' Changepoint Analysis
#'
#' Purpose: run the changepoint analysis for each gene and each cytosine
#' context
#'
#' @param whole_df (df) - the information such as genes, z scores, etc
#' @param CG_penalty,CHG_penalty,CHH_penalty (int) - penalty values for the
#' change point analysis. The higher the value the fewer changepoints that will
#' be created. The lower the value the more changepoints that will be created.
#' @param target_genes (list of strings) - a list of the target genes
#' @param save_plots (boolean) - if TRUE save plots to working directory, default
#' is FALSE
#' @param z_col (str) - the column to run the changepoint analysis on. This
#' can be any column, but for DMR analysis we recommend using the z scores for
#' a fixed effect variable.
#' @param whole_genome (boolean) - whether to run changepoints on a whole genome
#' scale. Setting to TRUE will find changepoints per chromosome. Setting to FALSE
#' will find changepoints per gene. 
#' @param plot_prefix (str) - added to the start of plot file names and titles, e.g.
#' the treatment ("T6" -> T6_<gene>_CG_changepoints_line.png). Use it when running
#' several treatments so their plots don't overwrite each other.
#' @param plot_dir (str) - folder for the plot files (created if needed); default is
#' the working directory
#' @param drop_zero_z (bool) - leave cytosines with `z_col` exactly 0 out of the
#' changepoint analysis. `find_DMR()` gives Z = 0 to cytosines it could not model
#' (too few reads), so including them pulls region means toward 0 and hides
#' changes, mostly in CHH. They stay in the returned table with NA region columns
#' and are not part of any region in `sound_score()`. Default FALSE (as in
#' earlier versions); the example workflows set it to TRUE.
#' @return everything (df) - the input rows (same order within each gene and
#' context) with the mean changepoint value and region columns for `z_col`
#' @import tibble
#' @export

changepoint_analysis <- function(whole_df,
                                 CG_penalty = int,
                                 CHG_penalty = int,
                                 CHH_penalty = int,
                                 target_genes = c(),
                                 save_plots = FALSE,
                                 z_col = 'column',
                                 whole_genome = FALSE,
                                 plot_prefix = '',
                                 plot_dir = '.',
                                 drop_zero_z = FALSE) {
  # Plot file names: [<plot_prefix>_]<gene>_<CX>_changepoints_<line|volcano>.png in
  # plot_dir. Characters that are unsafe in file names (e.g. ':' in chr7:123_tr2) -> '_'.
  plot_file <- function(gene, cx, type) {
    safe_gene <- gsub("[^A-Za-z0-9._-]", "_", gene)
    file.path(plot_dir, paste0(if (nzchar(plot_prefix)) paste0(plot_prefix, "_") else "",
                               safe_gene, "_", cx, "_changepoints_", type, ".png"))
  }
  if (save_plots) dir.create(plot_dir, showWarnings = FALSE, recursive = TRUE)
  region_cols <- paste0(c('MethRegion_', 'MethRegionLength_', 'MethCytosines_', 'MethGroup_'), z_col)
  # Cytosines used for changepoints: Z not NA (and not 0 with drop_zero_z). The others are
  # set aside and added back with NA region columns, keeping the original row order.
  # (Filtering here, not inside find_cpt_mean(), keeps changepoint positions aligned with rows.)
  run_context <- function(df, penalty) {
    df$.row_order <- seq_len(nrow(df))
    use <- !is.na(df[[z_col]]) & (if (drop_zero_z) df[[z_col]] != 0 else TRUE)
    used <- df[use, , drop = FALSE]
    cpt <- if (nrow(used) > 0) find_cpt_mean(used, z_col, penalty) else NULL
    if (nrow(used) > 0) used <- add_changepoint_info(used, cpt, z_col)
    used <- used[!is.na(used$.row_order), , drop = FALSE]   # drop the placeholder row added when no changepoints
    list(cpt = cpt, used = used, rest = df[!use, , drop = FALSE])
  }
  combine_context <- function(r) {
    rest <- r$rest
    for (cl in setdiff(region_cols, names(r$used))) r$used[[cl]] <- rep(NA_real_, nrow(r$used))
    if (nrow(rest) > 0) {
      for (cl in region_cols) rest[[cl]] <- rep(NA_real_, nrow(rest))
      for (cl in setdiff(names(r$used), names(rest))) rest[[cl]] <- rep(NA, nrow(rest))
      out <- rbind(r$used, rest[, names(r$used), drop = FALSE])
    } else out <- r$used
    out <- out[order(out$.row_order), , drop = FALSE]
    out$.row_order <- NULL
    out
  }

  # Create the list of subset groups
  if (whole_genome == FALSE) {
    subset_col <- "Gene"
  } else {
    subset_col <- "Chromosome"
    target_genes <- unique(whole_df$Chromosome)
    message(paste("Running whole genome changepoint analysis on chromosomes:", 
                  paste(target_genes, collapse = " ")))
  }
  
  subsets <- unique(whole_df[[subset_col]])
  large_genes <- c()
  
  # Create the structure of the final df
  everything <- tibble::as_tibble(matrix(ncol = 8))
  colnames(everything) = c('index', 'CX', 'Zeroth_pos', subset_col, paste0('MeanMeth_',z_col),
                           paste0('MeanMethRegion_',z_col), paste0('MethRegionLength_',z_col),
                           paste('MethylGroup',z_col))
  #  remove the first row
  everything <- everything[-1,]
  
  # Create a progress bar
  pb = txtProgressBar(min = 0, max = length(subsets), initial = 0, style = 3)
  #  Work through the genes and cytosine contexts
  for (i in 1:length(subsets)) {
    subset = subsets[i]
    plot_label <- if (nzchar(plot_prefix)) paste(plot_prefix, subset) else subset
    # Create the filtered df to contain the gene of interest
    subset_df <- whole_df[whole_df[[subset_col]] == subset,]
    
    # Find the changepoints per cytosine context and add the region info
    r.CG  <- run_context(subset_df[subset_df$CX == 'CG', ], CG_penalty)
    r.CHG <- run_context(subset_df[subset_df$CX == 'CHG', ], CHG_penalty)
    r.CHH <- run_context(subset_df[subset_df$CX == 'CHH', ], CHH_penalty)
    x.CG <- r.CG$cpt; x.CHG <- r.CHG$cpt; x.CHH <- r.CHH$cpt
    # plots use the cytosines the changepoints were run on
    subset_df.CG <- r.CG$used; subset_df.CHG <- r.CHG$used; subset_df.CHH <- r.CHH$used
    
    # Create the plots
    if (subset %in% target_genes) {
      vol_plot.CG <- plot_changepoints_volcano(data=subset_df.CG, 
                                               changepoint_obj=x.CG,
                                               gene_name=plot_label, 
                                               penalty_val=CG_penalty,
                                               cyt_context='CG', z_col=z_col)
      vol_plot.CHG <- plot_changepoints_volcano(data=subset_df.CHG, 
                                                changepoint_obj=x.CHG,
                                                gene_name=plot_label,
                                                penalty_val=CHG_penalty,
                                                cyt_context='CHG', z_col=z_col)
      vol_plot.CHH <- plot_changepoints_volcano(data=subset_df.CHH, 
                                                changepoint_obj=x.CHH,
                                                gene_name=plot_label,
                                                penalty_val=CHH_penalty,
                                                cyt_context='CHH', z_col=z_col)
      if (save_plots == TRUE & nrow(subset_df) < 100000) {
        # Create line plots
        line_plot.CG <- plot_changepoints_line(data=subset_df.CG,
                                               changepoint_obj=x.CG,
                                               gene_name=plot_label,
                                               penalty_val=CG_penalty,
                                               cyt_context='CG', z_col=z_col)
        line_plot.CHG <- plot_changepoints_line(data=subset_df.CHG,
                                                changepoint_obj=x.CHG,
                                                gene_name=plot_label,
                                                penalty_val=CHG_penalty,
                                                cyt_context='CHG', z_col=z_col)
        line_plot.CHH <- plot_changepoints_line(data=subset_df.CHH,
                                                changepoint_obj=x.CHH,
                                                gene_name=plot_label,
                                                penalty_val=CHH_penalty,
                                                cyt_context='CHH', z_col=z_col)
        
        # Save the plots
        save_plot(file_name=plot_file(subset, 'CG', 'line'), 
                  plot_obj=line_plot.CG)
        save_plot(file_name=plot_file(subset, 'CG', 'volcano'), 
                  plot_obj=vol_plot.CG)
        save_plot(file_name=plot_file(subset, 'CHG', 'line'), 
                  plot_obj=line_plot.CHG)
        save_plot(file_name=plot_file(subset, 'CHG', 'volcano'), 
                  plot_obj=vol_plot.CHG)
        save_plot(file_name=plot_file(subset, 'CHH', 'line'), 
                  plot_obj=line_plot.CHH)
        save_plot(file_name=plot_file(subset, 'CHH', 'volcano'), 
                  plot_obj=vol_plot.CHH)
      }
    } else if (subset %in% target_genes & nrow(subset_df) >= 100000) {
      large_genes <- c(large_genes, subset)
    }
    
    # Combine everything into the everything dataframe (rename)
    everything <- rbind(everything, combine_context(r.CG), combine_context(r.CHG), combine_context(r.CHH))
    
    # Update progress bar
    setTxtProgressBar(pb, i)
  }
  close(pb)
  
  for (gene in large_genes) {
    warning(gene, ' has more than 100,000 cytosines. Plot not created')
  }
  
  return(everything)
}


#' Sound Score
#' @description
#' Takes in an Output_Frame that has been broken in to changepoint regions based on a specific test statistic of interest, and creates an aggregated changepoint region file that includes summary statistics for each region, and the "sound score" a measure of the strength of a DMR within that region.
#'
#' @param changepoint_OF (df) - the OF file that has had changepoint calling ran on it
#' @param Statistic (str) - name of the test statistic that changepoint was run on
#' @param Per_Change (str) - Column that captures the change in methylation between two groups of interest
#' @param other_columns (str) - Names of any other columns that one is interested in calculating region averaqges on.
#' @param CF (str) - True/False if there is a custom function to be calculated in addition to soundscore
#' @param User_Function (str) - The function to use for the custome function
#' @param score4_count_exponent (num) - region-size exponent for `dmr_score4`.
#' `dmr_score4` is `score4_scale` x `dmr_score3` with n^score4_count_exponent in
#' place of n^(1/3); the default 0.5 shifts weight toward larger regions.
#' @param score4_scale (num) - multiplier that keeps `dmr_score4` on a similar scale to
#' `dmr_score3` (so similar cutoffs apply). With the defaults (exponent 0.5, scale 0.7)
#' `dmr_score4` relative to `dmr_score3` is x0.70 at 1 cytosine, x0.92 at 5, x1.15 at
#' 20 and x1.51 at 100; the two are equal at ~8-9 cytosines. To keep the crossover at
#' n0 cytosines for another exponent e, use scale = n0^-(e - 1/3).
#' @param score4_min_mean_z,score4_min_mean_dif (num) - signal gate for `dmr_score4`:
#' a region only gets a non-zero `dmr_score4` if its |mean Z| (MethRegion_Z mean) and
#' |mean change| (`Per_Change` mean, \% points) are at least these values. Stops long,
#' flat regions (mean Z near 0) from scoring on size alone. Defaults 0.175 and 2.
#' Set both to 0 to turn off.
#' The result is in the `dmr_score4_signal` column.
#' @return Aggregated_Changepoint_Object (list) - File that contains information about methylation patterns within each changepoint region
#' @export



sound_score <- function(changepoint_OF = dataframe, Statistic="Z_GroupT_small",
                        Per_Change = "Treat_V_Control", Control="Control",
                        other_columns=c("Estimate_GroupT_small"), CF=FALSE, UserFunction=NA,
                        score4_count_exponent = 0.5, score4_scale = 0.7,
                        score4_min_mean_z = 0.175, score4_min_mean_dif = 2) {
  # Determine proper column names givwen the test statistic of interest
  MethGroup <- paste("MethGroup_",Statistic, sep = "")
  MethRegion_Z <- paste("MethRegion_",Statistic, sep = "")
  MethRegion_Length <- paste("MethRegionLength_",Statistic, sep = "")
  # Create vector of columns that include information that the user wants aggregated across each changepoint region.  Includes Statistic, Per_Change, region length, and any other columns of interest.
  keep_cols <- c(MethRegion_Z, MethRegion_Length,Per_Change, Control,other_columns, Statistic)
  # Create new dataframe that includes a new column that has a column for every unique changepoint region
  cp_OF <- within(changepoint_OF, cp_group <- paste(Gene,CX,changepoint_OF[[MethGroup]], sep='_'))
  # Cytosines without a region (left out of the changepoint analysis, e.g. drop_zero_z) are
  # kept in methyl_summary but are not a region
  cp_reg <- cp_OF[!is.na(cp_OF[[MethGroup]]) & !is.na(cp_OF$Gene), ]
  #Calculate statistics and aggregate for every region
  RegionStats <- cp_reg %>%
    group_by(cp_group) %>%
    mutate(Count = n()) %>%
    group_by(cp_group, Gene,CX, Count) %>%
    summarise_at(vars(one_of(keep_cols)),list(mean = ~mean(., na.rm = TRUE),max = ~max(abs(.), na.rm = TRUE)), na.rm=TRUE)
  
  Ag_Pos <- cp_reg %>%
    group_by(cp_group) %>%
    summarise(Chr=unique(Chromosome),Start=min(Zeroth_pos), Stop=max(Zeroth_pos), Genome_Low=min(Position), Genome_High=max(Position))
  RegionStats <- cbind(Ag_Pos, RegionStats[,-1])
  #Calculate Sound Statistic
  RegionStats$dmr_score<-(((RegionStats$Count)^(1/3))*((abs(RegionStats[[paste(MethRegion_Z,"_mean", sep="")]]))^(1))*(abs(RegionStats[[paste(Per_Change,"_mean", sep="")]])^(1/2)))
  RegionStats$dmr_score2<-(((RegionStats$Count)^(1/3))*((abs(RegionStats[[paste(MethRegion_Z,"_mean", sep="")]]))^(1))*abs(asin(sqrt(RegionStats[[paste(Per_Change,"_mean", sep="")]]/100+RegionStats[[paste(Control,"_mean", sep="")]]/100))-asin(sqrt(RegionStats[[paste(Control,"_mean", sep="")]]/100)))^(1/2))
  RegionStats$dmr_score3<-(((RegionStats$Count)^(1/3))*((abs(RegionStats[[paste(MethRegion_Z,"_mean", sep="")]]))^(1/2))*(abs(RegionStats[[paste(Per_Change,"_mean", sep="")]])^(1/2))*(abs(RegionStats[[paste(Statistic,"_max", sep = "")]])^(1/2)))
  RegionStats$dmr_score_noZ<-(((RegionStats$Count)^(1/3))*abs(RegionStats[[paste(Per_Change,"_mean", sep="")]])^(1/2))
  # if(CF==TRUE){
  #   RegionStats$CustomFunction<<-UserFunction
  #   RegionStats$CustomFunction_Percentile<-ecdf(RegionStats$CustomFunction)(RegionStats$CustomFunction)
  # }
  for(i in 1:nrow(RegionStats)){
    if (!is.na(RegionStats[[paste(Per_Change,"_mean", sep="")]][i])) {
      if(RegionStats[[paste(Per_Change,"_mean", sep="")]][i]<0){
        RegionStats$dmr_score[i]<-RegionStats$dmr_score[i]*-1
        RegionStats$dmr_score_Percentile<-ecdf(RegionStats$dmr_score)(RegionStats$dmr_score)
        RegionStats$dmr_score2[i]<-RegionStats$dmr_score2[i]*-1
        RegionStats$dmr_score2_Percentile<-ecdf(RegionStats$dmr_score2)(RegionStats$dmr_score2)
        RegionStats$dmr_score3[i]<-RegionStats$dmr_score3[i]*-1
        RegionStats$dmr_score3_Percentile<-ecdf(RegionStats$dmr_score3)(RegionStats$dmr_score3)        
        RegionStats$dmr_score_noZ[i]<-RegionStats$dmr_score_noZ[i]*-1
        RegionStats$dmr_score_noZ_Percentile<-ecdf(RegionStats$dmr_score_noZ)(RegionStats$dmr_score_noZ)
      }
    }
  }
  
  RegionStats$dmr_score[!is.finite(RegionStats$dmr_score)] <- 0
  RegionStats$dmr_score2[!is.finite(RegionStats$dmr_score2)] <- 0
  RegionStats$dmr_score3[!is.finite(RegionStats$dmr_score3)] <- 0  
  RegionStats$dmr_score_noZ[!is.finite(RegionStats$dmr_score_noZ)] <- 0
  RegionStats$dmr_score_Percentile[!is.finite(RegionStats$dmr_score_Percentile)] <- 0.5
  RegionStats$dmr_score3_Percentile[!is.finite(RegionStats$dmr_score3_Percentile)] <- 0.5
  RegionStats$dmr_score2_Percentile[!is.finite(RegionStats$dmr_score2_Percentile)] <- 0.5
  RegionStats$dmr_score_noZ_Percentile[!is.finite(RegionStats$dmr_score_noZ_Percentile)] <- 0.5

  # dmr_score4: dmr_score3 with a larger region-size exponent, rescaled to dmr_score3's
  # magnitude: score4_scale * n^score4_count_exponent * |mean Z|^(1/2) * |mean change|^(1/2) * |max Z|^(1/2)
  # (with defaults: equal to dmr_score3 at n ~ 8-9, lower for smaller regions, higher for larger)
  # Negative when the mean change is negative, as for the other scores. Set to 0 for
  # regions failing the signal gate (|mean Z| / |mean change| below the floors).
  per_change_mean <- RegionStats[[paste(Per_Change,"_mean", sep="")]]
  RegionStats$dmr_score4 <- score4_scale * (RegionStats$Count^score4_count_exponent) *
    (abs(RegionStats[[paste(MethRegion_Z,"_mean", sep="")]])^(1/2)) *
    (abs(per_change_mean)^(1/2)) *
    (abs(RegionStats[[paste(Statistic,"_max", sep = "")]])^(1/2)) *
    ifelse(!is.na(per_change_mean) & per_change_mean < 0, -1, 1)
  RegionStats$dmr_score4[!is.finite(RegionStats$dmr_score4)] <- 0
  # Signal gate: no score for regions whose average shift is ~0, however large they are
  RegionStats$dmr_score4_signal <- !is.na(per_change_mean) &
    abs(RegionStats[[paste(MethRegion_Z,"_mean", sep="")]]) >= score4_min_mean_z &
    abs(per_change_mean) >= score4_min_mean_dif
  RegionStats$dmr_score4[!RegionStats$dmr_score4_signal] <- 0
  RegionStats$dmr_score4_Percentile <- stats::ecdf(RegionStats$dmr_score4)(RegionStats$dmr_score4)

  plot(RegionStats$dmr_score3_Percentile, RegionStats$dmr_score3)
  plot <- RegionStats %>%
    ggplot(aes(x = .data[[paste(MethRegion_Z,"_mean", sep="")]], y = Count)) +
    geom_point(aes(color = dmr_score3))
  print(plot)
  SS_Obj <- list(RegionStats, cp_OF)
  names(SS_Obj) <- c("region_summary", "methyl_summary")
  return(SS_Obj)
}

#' split_by_chromosome
#' @description
#' A function to split a bed file into multiple file by chromosome. 
#' Note: scaffolds are ignored in the function
#' It will create a new directory per each chromosome.
#' @param input_file (str) - A string with the name of the input file. It uses a 
#' fill (absolute) path.
#' @return output_filelist(list) - A list with the bedfile names of the output files.
#' @export

split_by_chromosome <- function(input_file) {
  
  output_filelist <- c()
  # get dir only
  fields <- strsplit(input_file, "/")[[1]]
  input_dir <- paste(fields[1:(length(fields) - 1)], collapse = "/")
  # Get name without extension
  base_name <- tools::file_path_sans_ext(basename(input_file))
  # Open the input file for reading
  con <- file(input_file, "r")
  # Create a list to store the file connections for each chromosome output file
  output_files <- c()
  # Read the input file line by line and process each line
  while (TRUE) {
    line <- readLines(con, n = 1)
    if (length(line) == 0) break # Exit loop if end of file is reached
    # Split the line by tab to get the chromosome
    fields <- strsplit(line, "\t")[[1]]
    chromosome <- fields[1]
    if (startsWith(tolower(chromosome), "scaf")) {
      next
    }
    # Create the output directory for the chromosome if not already created
    if (!dir.exists(file.path(input_dir, paste0("chr_", chromosome)))) {
      dir.create(file.path(input_dir, paste0("chr_", chromosome)))
    }
    # Create the output file for the chromosome if not already opened
    if (!(chromosome %in% names(output_files))) {
      output_file <- file.path(input_dir, paste0("chr_", chromosome), paste0(base_name, ".bed"))
      output_filelist <- append(output_filelist, output_file)
      output_files[[chromosome]] <- file(output_file, "w")
    }
    # Write the line to the corresponding output file
    writeLines(line, output_files[[chromosome]])
  }
  # Close all output file connections
  i <- 1
  for (chr in names(output_files)) {
    close(output_files[[chr]])
    cat(paste("Chromosome", chr, "data has been written to", output_filelist[[i]], "\n"))
    i <- i + 1
  }
  
  # Close the input file connection
  close(con)
  
  return(output_filelist)
}

#' split_by_chunk
#' @description
#' A function to split a bed file into multiple chunks. Each chunk is stored in a separated directory.
#'
#' @param input_file (str) - A string with the name of the input file.
#' @param chunk_size (int) - Maximum region/position in the bedfile per chunk.
#' @param output_dir (str) - A string with the name of the directory with the chunks
#' @export

split_by_chunk <- function(input_file, chunk_size, output_dir = "./chunks/") {
  options(scipen = 999)
  # Get base name
  base_name <- basename(input_file)
  # Create the output directory if it doesn't exist
  dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
  # Read the BED file into a data frame
  column_names <- c("chromosome", "start", "end", "4", "5", "6", "7", "8", "9", "10", "11", "12")
  bed_df <- read.table(input_file, header = FALSE, col.names = column_names)
  nucls <- tail(bed_df$start, n = 1)
  # Get number of chunks
  total_chunks <- ceiling(nucls/chunk_size)
  # Initialize variables for chunk creation
  lower_val <- 0
  upper_val <- chunk_size
  for (chunk_n in 1:total_chunks) {
    chunk <- subset(bed_df, start > lower_val & start <= upper_val)
    # check if it is blank, if so make a all NA line
    if (dim(chunk)[1] == 0) {
      chunk <- data.frame(matrix(NA, nrow = 1, ncol = length(column_names)))
    }
    chunkndir <- paste0("chunk", chunk_n, "_", as.integer(lower_val), "_", as.integer(upper_val))
    dir.create(file.path(output_dir, chunkndir), showWarnings = FALSE, recursive = TRUE)
    output_file <- file.path(output_dir, chunkndir, base_name)
    write.table(chunk, file = output_file, sep = "\t", quote = FALSE, col.names = FALSE, row.names = FALSE)    
    lower_val <- lower_val + chunk_size
    upper_val <- upper_val + chunk_size
  }
}

#' get_standard_methyl_bed
#' @description
#' A function to create a data frame for every individual in the experimental design without having to re run for every individual separately.
#' This function takes in the methyl_bed file, subsets and then creates Methylated and unmethylated counts for each position to be used in the next steps.
#' @param Methyl_bed (df) - Data frame containing the ONT methylation calls in a bed file for each individual separately
#' @param Sample_ID (str) - A string that is used inplace of sample name to keep it uniform. We are using an enumerator to generate this based on the number of samples/individuals in the experiment.
#' @param Methyl_call_type (str) - A string that includes information about the type of run. Currently this package works on Megalodon , DSP (DeepSignal Plant), Modkit, Dorado and Bonito. Default call type is Modkit.
#' @param max_read_depth (int) - This parameter can be used to filter out rows with high red depth such as highly repetative regions to not be included in the analysis. Default is 0. 
#' @return Methyl_bed_sub (df) - Standard data frame methyl file for every individual with Meth, Unmeth and Per_Meth columns
#' @import tidyverse
#' @import stringr
#' @export

get_standard_methyl_bed <-function(Methyl_bed="Methyl.bed", Sample_ID = "S1", Methyl_call_type="Modkit", max_read_depth=100) {
  
  # Extract columns of interest based on which process was run
  #Columns of Interest include Chromosome|Position|Strand|Total_reads|Percent_Methylation|Cytosine_context
  
  if (Methyl_call_type %in% c('DSP', 'Bonito', 'Dorado', 'Modkit')){
    
    Methyl_bed <- Methyl_bed[,c(1,2,3,4,5,6)]
  }
  else if(Methyl_call_type=="Megalodon"){
    Methyl_bed <- Methyl_bed[,c(1,2,3,4,5,7)]
  }
  #Assign column names
  colnames(Methyl_bed) <- c("Chromosome","Position",paste("Strand", Sample_ID, sep="_"),"Tot_reads", paste("PerMeth", Sample_ID, sep="_") ,paste("CX", Sample_ID, sep="_"))
  #calculate Meth and Unmeth reads from total reads. This is necessary for downstream Differential Methylation Region (DMR) analysis.
  Methyl_bed[[paste("Meth", Sample_ID, sep="_")]] <- round( (Methyl_bed[[paste("PerMeth", Sample_ID, sep="_")]] * Methyl_bed$Tot_reads)/100 )
  Methyl_bed[[paste("UnMeth", Sample_ID, sep="_")]] <- (Methyl_bed$Tot_reads - Methyl_bed[[paste("Meth", Sample_ID, sep="_")]])
  Methyl_bed <- Methyl_bed %>% dplyr::filter(Tot_reads< max_read_depth)
  Methyl_bed <- Methyl_bed %>% select(-Tot_reads)
  
  return(Methyl_bed)
}


#' generate_megaframe
#' @description
#' A function to create a single-combined data frame from individual methyl beds in the experiment
#' This function only works with bedfiles output from only either of the three methylation call algorithms - DeepSignal Plant(DSP), Megalodon and Bonito.
#'
#' @param methyl_bed_list (list) - ONT methyl bed filenames for each individual contained within the directory. This will just be a list of bedfile names.
#' Hint : The input will be the "methyl_bed_list" vector that you create in the previous step.
#' @param Sample_count (int) - This is required to assign proper alphabet codes. If you need to include the samples from a previous round, then enter the total number of samples from the previous round here. Default is 0. By default alphabetizing starts with 'A'.
#' @param Methyl_call_type (str) - A string that includes information about the type of run. Currently this package works on Dorado, Modkit , Megalodon , DSP (DeepSignal Plant) and Bonito.
#' @param File_prefix (Flexible str) - This is to add a prefix to all the files that get exported and saved to the working directory while running the function.
#' @return Megaframe(df) - Clean data frame containing combined methyl bed information for every individual in the experiment.
#' @import tidyverse
#' @import stringr
#' @import data.table
#' @examples
#' # Basic usage for methyl_call_type
#' # generate_megaframe(Methyl_call_type="DSP") # OR
#' # get_standard_methyl_bed(Methyl_call_type="Megalodon") # OR
#' # get_standard_methyl_bed(Methyl_call_type="Bonito")
#' @export



generate_megaframe <- function(methyl_bed_list=All_methyl_beds, Sample_count, Methyl_call_type="Modkit", File_prefix="", max_read_depth=100, bed_header=TRUE, gene_cord_df=gene_coordinate_file){
  
  #QC
  QC <- missing(methyl_bed_list)
  if(QC==TRUE){
    stop("methyl_bed_list parameter cannot be empty.
         Hint: Use methyl_bed_list vector you create in the previous step")
  }
  
  if(Methyl_call_type==""){
    message("Methylation call type not given, using default type i.e Modkit \n")
  }
  
  
  if (!(Methyl_call_type %in% c('DSP', 'Megalodon', 'Bonito', 'Dorado', "Modkit"))){
    stop("Methylation call not recognized, use 'DSP' or 'Megalodon' or 'Bonito' or 'Dorado' or 'Modkit', exiting!")
    
  }
  
  sample_number_list <- c()
  for (i in 1:(Sample_count + length(methyl_bed_list)) ){
    S_enumerator <- paste("S",i,sep="")
    sample_number_list[(length(sample_number_list) + 1)] <- list(S_enumerator)
  }
  
  sample_number_list <- unlist(sample_number_list)
  sample_number <- sample_number_list[(Sample_count+1):(Sample_count+length(methyl_bed_list))]
  
  message("Creating the Megaframe")
  
  mylist <- c()
  experimental_design_df <- data.frame()
  for (i in 1:length(methyl_bed_list)){ #Iterate through methyl beds one by one
    
    if(Methyl_call_type == "Modkit"){
      tmpsampleData <- read.csv(methyl_bed_list[i], sep="\t", header=bed_header, nrows = 5)  
      classes <- sapply(tmpsampleData, class)
      classes[c(3, 5, 7, 8, 9,12,13,14,15,16,17,18)] <- "NULL"
      #import the bed file
      import_bedfile <- data.frame(purrr::map(methyl_bed_list[i], ~fread(.x, sep="\t", header=bed_header, colClasses = classes)))
      colnames(import_bedfile)<-c("Chromosome", "Position", "name", "strand", "TRs", "Pers")
      import_bedfile$name<-gsub("m,*", "", import_bedfile$name)
      import_bedfile$name<-gsub("*,0", "", import_bedfile$name)
      import_bedfile<-import_bedfile[,c(1,2,4,5,6,3)]
    }else{
      tmpsampleData <- read.csv(methyl_bed_list[i], sep="\t", header=bed_header, nrows = 5)
      classes <- sapply(tmpsampleData, class)
      #replace some columns to null to delete them
      classes[c(3, 4, 5, 7, 8, 9)] <- "NULL"
      #import the bed file
      import_bedfile <- data.frame(purrr::map(methyl_bed_list[i], ~fread(.x, sep="\t", header=bed_header, colClasses = classes)))
    }
    
    #call get_standard_methyl_bed function to clean up the bed file from each sample
    methyl_data <- get_standard_methyl_bed(Methyl_bed = import_bedfile, Sample_ID = sample_number[i], Methyl_call_type = Methyl_call_type, max_read_depth = max_read_depth )
   
    Final_md <- methyl_data[0,] 
     if(is.null(gene_cord_df)==FALSE){
      for(b in 1:nrow(gene_cord_df)){
        X1_data <- methyl_data[methyl_data$Chromosome %in% gene_cord_df$Chromosome[b], ] #subset based on the gene
        X1_data <- X1_data %>% dplyr::filter(Position >= (gene_cord_df$Adapt_Low[b]) & Position <=(gene_cord_df$Adapt_High[b]) )
        Final_md <- rbind(Final_md,X1_data)
      }
       methyl_data<-Final_md
    }
    
      #getting the count of nrow for sanity checks
    raw_count <- nrow(methyl_data)
    methyl_data <- unique(methyl_data) #remove duplicates if any
    clean_count <- nrow(methyl_data)
    #QC
    if (raw_count==clean_count){
      cat("QC : No duplicates in ",methyl_bed_list[i] ,", proceeding \n")
    }
    else {
      cat("QC : Duplicates found in ",methyl_bed_list[i] ,", cleaning data before proceeding \n")
    }
    mylist[(length(mylist) + 1)] <- list(methyl_data) #append it to a list
    #get a list of alphabet codes and bed files - this will be saved in the experimental design starter
    Bedfile_comb <- data.frame(sample_number[i],methyl_bed_list[i])
    experimental_design_df <- rbind(experimental_design_df,Bedfile_comb)
    
  }
  write.table(experimental_design_df, paste(File_prefix, "Experimental_design_starter.csv",sep="_"), row.names=F, col.names = c("ID","Bedfile"), sep=",")
  
  message("The experimental design file is now available in current directory!")
  
  #merge the methyl beds from diff samples into a signle large data frame
  combined_methyl_beds <-Reduce(function(x, y) full_join(x, y, by=c("Chromosome", "Position")), c(mylist) )
  
  #get Strand and CX columns to coalesce.
  Strands <- combined_methyl_beds %>% select(starts_with("Strand_")) %>% colnames()
  combined_methyl_beds$Strand <- do.call(dplyr::coalesce, combined_methyl_beds[Strands])
  
  Cxs <- combined_methyl_beds %>% select(starts_with("CX_")) %>% colnames()
  combined_methyl_beds$CX <- do.call(dplyr::coalesce, combined_methyl_beds[Cxs])
  
  #Remove unwanted columns
  combined_methyl_beds <- combined_methyl_beds  %>% select(-(starts_with("Strand_")), -starts_with(("CX_")))
  #Rearrange
  Megaframe <- combined_methyl_beds[,c(1:2,(ncol(combined_methyl_beds)-1),(ncol(combined_methyl_beds)),3:(ncol(combined_methyl_beds)-2) )]
  
  #sanity check - to ensure no NAs in Strand and CX columns after coalesce
  if ( (sum(is.na(Megaframe$Strand))==0 ) &
       sum(is.na(Megaframe$CX))==0 ) {
    cat('QC : Megaframe looks good \n')
  } else {
    cat('QC: Strand and CX should not have NAs, re-run the megaframe function \n')
  }
  
  #QC : Filter rows/sample with missing data
  Megaframe$NAs <- rowSums(is.na(Megaframe))
  #make a histogram
  
  cat("QC: The plot provides information about missing data that can be filtered out in the next step by using the filter_NAs parameter \n")
  QCplot <- suppressMessages(ggplot(Megaframe, aes(x=NAs/3))+geom_histogram(bins=30) +
                               labs(title = "Missing data per cytosine") +
                               xlab("Individual") +
                               ylab("Count of rows with missing data")) + theme_bw()
  
  print(QCplot)
  rm(QCplot)
  
  return (Megaframe)
}



#' add_zoom_coords
#'
#' A function to add Zoom codes based on the gene positions.
#' Currently the codes for this is as below
#' 1- Anything that is only between gene start and gene stop
#' 2- Anything that is between Adaptive start and Adaptive Stop
#' 0- Anything that doesn't fall within in the above - to ensure we don't include these in the DMR analysis.
#'
#' @param target (df) - Subset of ONT-methyl bed to positions pertaining to a single gene at a time
#' @param geneco_index (int) - This is index that refers to the row number of the geneco df, required to assign proper Alphabet codes.
#' @param gcoord_exist (Boolean) - This is to use the function only the gene_cord_df file has the location of the gene.
#' @param Gene_col (str) - Use this column to specifify wether to add Gene Names or Ids in the Zoomframe.
#' @return Zoomframe (df) - Similar to Megaframe except this includes more information on targets, positions zero'ed to ATG for each target and a few other information with an additional column that included zoom codes
#' @import tidyverse
#' @import stringr
#' @export

add_zoom_coords <- function(target, gene_cord_df, geneco_index, gcoord_exist=TRUE, Gene_col="Gene_name") {
  if (gcoord_exist == TRUE) {
    g <- gene_cord_df[geneco_index, ]
    if (any(target$Gene != g[[Gene_col]])) print("Gene Names don't match, please check the gene_coordinate file")
    pos <- target$Position
    target$Zoom_co <- ifelse(pos >= g$Low & pos <= g$High, 1,              # gene body
                      ifelse(pos >= g$Adapt_Low & pos <= g$Adapt_High, 2,  # adaptive region
                             0))                                            # beyond the adaptive region
  } else {
    target$Zoom_co <- "NA"
  }
  return(target)
}



#' Create Zoomframe
#'
#' A function to create a single-merged data frame from individual methyl beds in the experiment
#'
#' @param gene_cord_df (df) - Data frame containing gene-coordinate info
#' @param MFrame (df) - Megaframe data from the previous function
#' @param File_prefix (Flexible str) - This is to add a prefix to all the files that get exported while running the function.
#' @param filter_NAs (int) - Select this parameter based on the histogram plot. This will filter out NAs based on per sample
#' @param target_info (Boolean) - This takes in TRUE or FALSE. Enter TRUE only if the megaframe contains target genes that need to be differentiated from non-targets.
#' @param gene_list (list) - Provide a list of target genes to distiguish from non-target genes within the Zoomframe. By deafult it will take in the All the genes from the gene coordinates file.
#' @inheritParams add_zoom_coords
#' @return Zoomframe (df) - Similar to Megaframe except this includes more information on targets, positions zero'ed to ATG for each target and a few other information.
#' @import tidyverse
#' @import stringr
#' @export

generate_zoomframe <- function(gene_cord_df, MFrame, Gene_col, target_info=TRUE, gene_list=gene_cord_df[[Gene_col]], File_prefix="") {
  
  
  message("Creating the ZoomFrame!")
  
  gene_sets <- list()
  no_chrom <- character(0)                 # genes whose chromosome isn't in the bed files
  no_data  <- character(0)                 # genes with no cytosines in their window
  for (i in 1:nrow(gene_cord_df)){
    gene_name <- gene_cord_df[[Gene_col]][i]
    if (!any(gene_cord_df$Chromosome[i] == MFrame$Chromosome)) { #make sure the chromosomes match between Mframe and gene_cord_df
      no_chrom <- c(no_chrom, paste0(gene_name, " (", gene_cord_df$Chromosome[i], ")"))
      next
    }
    Gene_subset <- MFrame[MFrame$Chromosome %in% gene_cord_df$Chromosome[i], ] #subset based on the gene
    Gene_subset <- Gene_subset %>% dplyr::filter(Position >= (gene_cord_df$Adapt_Low[i]) & Position <=(gene_cord_df$Adapt_High[i]) )
    if (nrow(Gene_subset) == 0) {            # no data in this gene's window: skip it
      no_data <- c(no_data, gene_name)
      next
    }
    Gene_subset$Gene <- gene_name #Add-in the gene/geneID names
    if (gene_cord_df$Strand[i]=="+") {
      Gene_subset$Zeroth_pos <- (Gene_subset$Position - gene_cord_df$Low[i]) #Computing the Zeroth position to center everything around ATG.
    }
    else if (gene_cord_df$Strand[i] == "-") {
      Gene_subset$Zeroth_pos <-  (gene_cord_df$High[i]- Gene_subset$Position) #reorienting the anti-sense genes
    }
    #Call the add_zoom_coords function to add Zoom_co-ordinates
    gene_sets[[length(gene_sets) + 1]] <- add_zoom_coords(target=Gene_subset, gene_cord_df=gene_cord_df, geneco_index=i, gcoord_exist=TRUE, Gene_col=Gene_col)
  }
  if (length(no_data) || length(no_chrom)) {
    warning(paste0(
      "generate_zoomframe(): ", length(no_data) + length(no_chrom), " of ", nrow(gene_cord_df),
      " genes have no data and were left out of the ZoomFrame.",
      if (length(no_data)) paste0("\n  No cytosines between Adapt_Low and Adapt_High: ", paste(no_data, collapse = ", ")),
      if (length(no_chrom)) paste0("\n  Chromosome not in the bed files: ", paste(no_chrom, collapse = ", ")),
      "\n  Check the gene coordinates file (chromosome names, Adapt_Low / Adapt_High) and the bed subsetting."),
      call. = FALSE, immediate. = TRUE)
  }
  if (!length(gene_sets)) stop("None of the genes in the gene coordinates file have data in the bed files - ",
                               "check that chromosome names and coordinates match the bed files.", call. = FALSE)
  Final_gene_set <- do.call(rbind, gene_sets)
  Final_gene_set <- Final_gene_set[,c(1,(ncol(Final_gene_set)-2),2:4,5:(ncol(Final_gene_set)-3),ncol(Final_gene_set)-1,ncol(Final_gene_set))]
  
  message("Zoomframe generated, Adding in target info column; Almost done!")
  
  #Clean up columns with NAs
  Meth_Unmeth <- Final_gene_set %>% select(starts_with("Meth"), starts_with("UnMeth")) %>% colnames()
  cat("Changing NAs in Methylated and UnMethylated columns to 0\n")
  cat("Columns :", Meth_Unmeth, "\n" )
  #convert NAs to 0s. Here we are not changing the Percent methylation column
  Final_gene_set[Meth_Unmeth][is.na(Final_gene_set[Meth_Unmeth])] <- 0
  
  if (target_info==TRUE){
    Final_gene_set$Target_info <- ifelse(Final_gene_set$Gene %in% gene_list, "T", "NT")
  }
  
  
  write.table(Final_gene_set, paste(File_prefix, "ZoomFrame.csv",sep="_"), row.names=F, sep=",")
  message("Zoomframe is available in your current directory!")
  
  return(Final_gene_set)
}

#' Create Methylframe
#'
#' A function to create either Megaframe (A single data frame containing all samples bedMethyl data) or Zoomframe (A version of the Megaframe which includes the Gene Name, Position Zero'ed in on ATG of the respective gene and other columns to help with downstream analysis)
#' NOTE:
#' 1.  In both cases, Megaframe data will be exported in the current working directory and Zoomframe will only be exported if the Gene coordinates file is provided
#' 2. If this function is run using 'gene_info= TRUE' then it needs additional parameters like gene_cordinate_file,  Gene_column,target_info, gene_list etc to precoeed. If no such file is present, enter gene_info as false and
#'
#' @param methyl_bed_list (list) - ONT methyl bed filenames for each individual contained within the directory. This will just be a list of bedfile names. The input will be the "methyl_bed_list" vector that you create in the previous step.
#' @param Sample_count (int) - This is required to assign proper alphabet codes. If you need to include the samples from a previous round, then enter the total number of samples from the previous round here. Default is 0. By default alphabetizing starts with 'A'.
#' @param Methyl_call_type (str) - A string that includes information about the type of run. Currently this package works on Megalodon , DSP (DeepSignal Plant) and Bonito.
#' @param filter_NAs (int) - Select this parameter based on the histogram plot. This will filter out NAs based on per sample, by default this is (Total samples)/2.
#' @param gene_info (str) - This takes in a boolean variable. If the gene info- coordinates, gene name etc are present then make sure to have the gene-cordinates.csv file in the right format (as shown in the sample data on github).
#' @param gene_cordinate_file (str) - File containing gene-coordinate info. It is important to be in a specific format and should have but not limited to the following columns : Chromosome | Gene_Name | Low | High | Adapt_Low | Adapt_High
#' Low and High : These are Start and Stop cordinates of the gene. Low is always the lower coordinate which could be start for the positive stranded gene and stop for the negative stranded gene and vice versa.
#' Adapt_Low and Adapt_High : Cordinates for adaptive regions around the Lower and Higher co-ordinate of the gene respectively
#' @param File_prefix (Flexible str) - This is to add a prefix to all the files that get exported and saved to the working directory while running the function.
#' @inheritParams generate_megaframe
#' @inheritParams generate_zoomframe
#' @return Megaframe(df) or Zoomframe(df) - Clean data frame containing combined methyl bed information for every individual in the experiment.
#' @import tidyverse
#' @export

generate_methylframe <-function(methyl_bed_list=All_methyl_beds, Sample_count = 0,
                                Methyl_call_type="Modkit", filter_NAs=0, max_read_depth=100,
                                gene_info = FALSE, gene_coordinate_file = NULL, Gene_column='',
                                target_info=TRUE, gene_list = gene_coordinate_file[[Gene_column]],
                                File_prefix="Sample", file_type_output = "text", bed_header = TRUE)
{
  
  if (typeof(gene_info) != 'logical'){
    stop("gene_info variable needs to be a boolen variable. Default is False")
  }
  
  QC <- is.null(gene_coordinate_file)
  if (gene_info==TRUE & (QC==TRUE | Gene_column=='') ) {
    stop("gene_info is TRUE. Please provide gene-coordinates file, additional values such as Gene_column and re-run the function. Look into documentation for additional information \n")
  }
  
  if (gene_info==TRUE & target_info==TRUE ) {
    message("NOTE: target_info is TRUE. Using all genes in the Geneco as targets. Use gene_list parameter to change \n")
  }
  
  Megaframe <- generate_megaframe(methyl_bed_list=methyl_bed_list, Sample_count = Sample_count,
                                  Methyl_call_type=Methyl_call_type, max_read_depth=max_read_depth, File_prefix=File_prefix, bed_header=bed_header, gene_cord_df = gene_coordinate_file)
  
  message('\nNOTE: Filtering NAs default is set to ',filter_NAs ,' (Total_samples/2). See documentation for ideas on how to use the filter \n')
  
  Megaframe <- Megaframe[Megaframe$NAs<=(filter_NAs*3),]
  
  if (file_type_output == "text"){
    write.table(Megaframe, paste(File_prefix, "MegaFrame.csv",sep="_"), row.names=F, sep=",")
  }
  
  if (file_type_output == "parquet"){
    write_parquet(Megaframe, sink=paste(File_prefix, "MegaFrame.parquet",sep="_"))
  }
  
  message("Megaframe is now available in current directory and in the R-env!")
  
  if (gene_info==TRUE) {
    
    Zoomframe <- generate_zoomframe(gene_cord_df=gene_coordinate_file, MFrame = Megaframe,
                                    Gene_col=Gene_column,
                                    target_info=target_info, gene_list=gene_list ,
                                    File_prefix=File_prefix)
    
    return(Zoomframe)
  }
  else {
    
    #Duplicating the column for downstream analysis since the functions look for a Zeroth_pos column
    Megaframe$Zeroth_pos <- Megaframe$Position
    
    return(Megaframe)
    
  }
  
}


#' Boot_score
#' @description
#' Bootstrap test of whether the DMRs near the oligo target are unusual compared with
#' random positions in other genes.
#'
#' Every changepoint region of the target gene gets a distance weight w = 1 - 0.00006 x
#' distance to the target window (0 beyond 15 kb; distance = gap between region and
#' window, 0 if they overlap) and a distance-weighted ("adjusted") score = w x region
#' score. The same is computed for `nboots` random windows of the same width, centred on
#' random cytosines in the other genes. Three tests are reported:
#' \itemize{
#'   \item **Best DMR, per context** - the best adjusted score near the target vs. the best
#'   in each background window (`P_Best_DMR`).
#'   \item **Best DMRs combined** - Fisher combination of the three per-context p-values,
#'   calibrated on the same background windows so correlation between contexts is
#'   accounted for.
#'   \item **Total of all DMRs** - the summed adjusted score of all regions above
#'   `overall_cutoff` (all contexts; the bar total in the score summary figure) vs. the
#'   same sum in each background window. Accounts for several DMRs, within and across
#'   contexts.
#' }
#' It also reports the **methylation effect** of the DMRs above the cutoff:
#' sum of w x cytosines in the region x mean methylation change / 100, in
#' "cytosine-equivalents" (10 cytosines each gaining 50 points = 5). Unlike the scores it
#' does not depend on read depth / number of plants (beyond which DMRs pass), on
#' changepoint penalties (splitting a region does not change it) or on the scoring
#' function, so its excess over the background is the measure to compare between
#' experiments.
#'
#' @param sound_score_obj (list) - Aggregated Changepoint Object created from sound_score
#' @param target_gene (str) - name of the target gene that was hit with oligos
#' @param target_start (num) - Start of the oligo target window, relative to the gene (Zeroth_pos)
#' @param target_end (num) - End of the oligo target window, relative to the gene (Zeroth_pos)
#' @param nboots (int) - Number of bootstrap (background) windows. The smallest possible
#' p-value is 1 / (nboots + 1).
#' @param scoring_col_name (str) - Region score column to use (e.g. dmr_score3, dmr_score4)
#' @param direction_DMR (str) - "positive" (default, gain of methylation), "negative"
#' (loss of methylation scored as positive) or "absolute"
#' @param exclude_genes (chr) *optional* - genes to leave out of the bootstrap background
#' in addition to `target_gene`. Use this when the same treatment targeted several genes,
#' so the other targets' DMRs don't inflate the background.
#' @param overall_cutoff (num) - adjusted-score cutoff for the total test and the
#' methylation effect (use the same cutoff as for significant DMRs, so the total equals
#' their summed score). Can be changed later with `boot_overall()`.
#' @param change_col (str) *optional* - region-summary column with the mean methylation
#' change (% points) per region, i.e. `<Per_Change>_mean` from `sound_score()`. Found
#' automatically if there is one column ending in `_mean_dif_mean`.
#' @param verbose (bool) - print a summary table to the console
#' @param make_plot (bool) - print the bootstrap plot
#' @return Boot_Obj (list):
#' \itemize{
#'   \item `summary` - one row per context (`Test` = "Best DMR") plus an `Overall` row
#'   (`Test` = "Total of DMRs > cutoff"). Per context: best target region, its adjusted
#'   score (`Target_Score`), background mean / SD / 95th percentile, `Background_Z`,
#'   `P_Value` ((n background >= target + 1) / (nboots + 1)), `Final_Score` (target x z,
#'   the original sounDMR final score) and `Evidence` from the p-value (strong < 0.01,
#'   significant < 0.05, suggestive < 0.1). Overall: `N_Regions` above the cutoff, their
#'   summed adjusted score (`Target_Score`), the same statistics for the background totals,
#'   `Excess_Score` (summed score - background mean), `P_Value`, `P_Best_DMRs_Combined`
#'   (calibrated Fisher), and `Meth_Effect`, `Bg_Mean_Meth_Effect`,
#'   `Bg_95pct_Meth_Effect`, `Excess_Meth_Effect` (methylation effect - background mean)
#'   \item `bootstrap_scores` - row 1 = target, rows 2.. = background windows: best
#'   adjusted score per context and where it was
#'   \item `target_rs` - the target gene's regions with `distance_from_target`,
#'   `adjusted_soundscore` and `meth_effect` (used by `get_sig_dmrs()`)
#'   \item `plot` - background distributions with the target marked
#'   \item `region_plot` - adjusted score of every target-gene region along the gene
#'   \item `settings` - the arguments used
#' }
#' @import ggplot2
#' @export
boot_score <- function(sound_score_obj = NA, target_gene = NA, target_start = -1000, target_end = 0,
                       nboots = 1000, scoring_col_name = "dmr_score", direction_DMR = "positive",
                       exclude_genes = NULL, overall_cutoff = 8, change_col = NULL,
                       verbose = TRUE, make_plot = TRUE) {
  rs <- as.data.frame(sound_score_obj$region_summary)
  ms <- as.data.frame(sound_score_obj$methyl_summary)
  contexts <- c("CG", "CHG", "CHH")
  max_reach <- 15000                       # regions further than this from the window score 0
  if (!target_gene %in% rs$Gene) stop("target_gene '", target_gene, "' not found in the region summary")
  if (!scoring_col_name %in% names(rs)) stop("scoring column '", scoring_col_name, "' not found")
  if (!direction_DMR %in% c("positive", "negative", "absolute")) stop("direction_DMR must be positive, negative or absolute")
  if (target_end < target_start) stop("target_end must be >= target_start")
  if (is.null(change_col)) {
    cand <- grep("_mean_dif_mean$", names(rs), value = TRUE)
    change_col <- if (length(cand) == 1) cand else NA_character_
    if (length(cand) != 1) message("boot_score: no single '*_mean_dif_mean' column - set change_col ",
                                   "to get the methylation effect (left NA).")
  } else if (!change_col %in% names(rs)) stop("change_col '", change_col, "' not found")
  has_change <- !is.na(change_col) && "Count" %in% names(rs)

  directed <- function(x) switch(direction_DMR, positive = x, negative = -x, absolute = abs(x))
  gap <- function(s, e, a, b) pmax(0, a - e, s - b)          # 0 if region and window overlap
  weight <- function(d) ifelse(d > max_reach, 0, 1 - 0.00006 * d)
  meth_eff <- function(r, w) if (has_change) w * r$Count * directed(r[[change_col]]) / 100 else rep(NA_real_, nrow(r))
  # adjusted scores of all regions r for window [a, b], plus the best per context
  score_window <- function(r, a, b) {
    w <- weight(gap(r$Start, r$Stop, a, b))
    adj <- w * directed(r[[scoring_col_name]])
    best <- t(vapply(contexts, function(cx) {
      k <- which(r$CX == cx & !is.na(adj))
      if (!length(k)) return(c(0, NA, NA))                  # no regions in this context
      j <- k[which.max(adj[k])]
      c(adj[j], r$Start[j], r$Stop[j])
    }, numeric(3)))
    keep <- !is.na(adj) & adj > 0                            # positive scores for the total test
    list(best = best, adj = adj[keep], me = meth_eff(r, w)[keep])
  }

  # ---- target ----------------------------------------------------------------
  target_rs <- rs[rs$Gene == target_gene, ]
  target_rs$distance_from_target <- gap(target_rs$Start, target_rs$Stop, target_start, target_end)
  tw_w <- weight(target_rs$distance_from_target)
  target_rs$adjusted_soundscore  <- tw_w * directed(target_rs[[scoring_col_name]])
  target_rs$meth_effect          <- meth_eff(target_rs, tw_w)
  tw <- score_window(target_rs, target_start, target_end)

  # ---- background: windows of the same width, centred on random cytosines ----
  half <- (target_end - target_start) / 2
  keep_bg <- !rs$Gene %in% c(target_gene, exclude_genes)
  bg_ms <- ms[!ms$Gene %in% c(target_gene, exclude_genes), c("Gene", "Zeroth_pos")]
  lims <- do.call(rbind, lapply(split(bg_ms$Zeroth_pos, bg_ms$Gene),
                                function(z) data.frame(lo = min(z), hi = max(z))))
  lo <- lims[bg_ms$Gene, "lo"]; hi <- lims[bg_ms$Gene, "hi"]
  margin <- max_reach + half               # whole scoring reach must lie inside the covered region
  ok <- pmin(bg_ms$Zeroth_pos - lo, hi - bg_ms$Zeroth_pos) > margin
  if (!any(ok)) {
    warning("No background positions are ", round(margin), " bp from both ends of a gene window; ",
            "using positions where the target-width window fits inside the gene window instead.")
    ok <- pmin(bg_ms$Zeroth_pos - lo, hi - bg_ms$Zeroth_pos) > half
  }
  if (!any(ok)) stop("No usable background positions (gene windows too small for this target window).")
  pool <- bg_ms[ok, ]
  picks <- pool[sample.int(nrow(pool), nboots, replace = TRUE), ]
  rs_by_gene <- split(rs[keep_bg, ], rs$Gene[keep_bg])
  bw <- lapply(seq_len(nboots), function(i) {
    c0 <- picks$Zeroth_pos[i]
    score_window(rs_by_gene[[picks$Gene[i]]], c0 - half, c0 + half)
  })

  # ---- bootstrap table (row 1 = target) --------------------------------------
  boot_out <- data.frame(Gene = c(target_gene, picks$Gene), Target = c(1, rep(0, nboots)),
                         Window_Center = c((target_start + target_end) / 2, picks$Zeroth_pos))
  for (j in seq_along(contexts)) {
    cx <- contexts[j]
    boot_out[[paste0(cx, "_Score")]] <- c(tw$best[j, 1], vapply(bw, function(w) w$best[j, 1], numeric(1)))
    boot_out[[paste0("Start_", cx)]] <- c(tw$best[j, 2], vapply(bw, function(w) w$best[j, 2], numeric(1)))
    boot_out[[paste0("Stop_", cx)]]  <- c(tw$best[j, 3], vapply(bw, function(w) w$best[j, 3], numeric(1)))
  }

  # ---- per-context summary (best DMR) ----------------------------------------
  ctx_rows <- do.call(rbind, lapply(seq_along(contexts), function(j) {
    cx <- contexts[j]; s <- boot_out[[paste0(cx, "_Score")]]; tgt <- s[1]; bg <- s[-1]
    reg <- target_rs[target_rs$CX == cx, ]
    best <- if (nrow(reg) && tgt > 0) reg$cp_group[which.max(reg$adjusted_soundscore)] else NA
    bsd <- stats::sd(bg); z <- if (is.finite(bsd) && bsd > 0) (tgt - mean(bg)) / bsd else NA
    pval <- (sum(bg >= tgt) + 1) / (nboots + 1)
    data.frame(Context = cx, Test = "Best DMR", Best_Region = best,
               Region_Start = tw$best[j, 2], Region_Stop = tw$best[j, 3],
               N_Regions = NA_integer_, Target_Score = round(tgt, 3),
               Background_Mean = round(mean(bg), 3), Background_SD = round(bsd, 3),
               Background_95pct = round(stats::quantile(bg, 0.95, names = FALSE), 3),
               Background_Z = round(z, 2), Excess_Score = NA_real_,
               P_Value = signif(pval, 3), P_Best_DMRs_Combined = NA_real_,
               Final_Score = round(tgt * z, 2), Evidence = boot_evidence(pval),
               Meth_Effect = NA_real_, Bg_Mean_Meth_Effect = NA_real_,
               Bg_95pct_Meth_Effect = NA_real_, Excess_Meth_Effect = NA_real_,
               stringsAsFactors = FALSE)
  }))

  Boot_Obj <- list(summary = ctx_rows, bootstrap_scores = boot_out, target_rs = target_rs,
                   plot = NULL, region_plot = NULL,
                   settings = list(target_gene = target_gene, target_start = target_start,
                                   target_end = target_end, nboots = nboots,
                                   scoring_col_name = scoring_col_name, direction_DMR = direction_DMR,
                                   exclude_genes = exclude_genes, overall_cutoff = overall_cutoff,
                                   change_col = change_col),
                   background_region_scores = lapply(bw, `[[`, "adj"),
                   background_region_effects = lapply(bw, `[[`, "me"))
  Boot_Obj <- boot_overall(Boot_Obj, overall_cutoff, verbose = FALSE, make_plot = FALSE)

  if (verbose) print_boot_summary(Boot_Obj, n_genes = length(unique(picks$Gene)))
  if (make_plot) print(Boot_Obj$plot)
  Boot_Obj
}

#' Evidence label from a bootstrap p-value
#' @noRd
boot_evidence <- function(p) as.character(cut(p, c(-Inf, 0.01, 0.05, 0.1, Inf), right = FALSE,
                                             labels = c("strong", "significant", "suggestive", "none")))

#' Total-of-DMRs Bootstrap Test at a Given Cutoff
#'
#' (Re)computes the `Overall` row of a `boot_score()` result: the summed adjusted score of
#' all target regions above `cutoff` (all contexts) and their methylation effect, compared
#' with the same sums in each background window, plus the calibrated Fisher combination
#' of the per-context best-DMR p-values. Use it when the significance cutoff changes after
#' `boot_score()` (e.g. step 4.0 of the example workflows) so the test matches the DMRs
#' that are kept.
#'
#' @param boot_obj (list) - output of `boot_score()`
#' @param cutoff (num) - adjusted-score cutoff (regions strictly above it count)
#' @param verbose (bool) - print the summary table
#' @param make_plot (bool) - print the updated plot
#' @return `boot_obj` with the `Overall` row of `summary`, `plot` and
#' `settings$overall_cutoff` updated
#' @import ggplot2
#' @export
boot_overall <- function(boot_obj, cutoff, verbose = FALSE, make_plot = FALSE) {
  st <- boot_obj$settings; nb <- st$nboots; contexts <- c("CG", "CHG", "CHH")
  bo <- boot_obj$bootstrap_scores
  trs <- boot_obj$target_rs
  sel <- !is.na(trs$adjusted_soundscore) & trs$adjusted_soundscore > cutoff
  t_tot <- sum(trs$adjusted_soundscore[sel]); t_n <- sum(sel)
  b_tot <- vapply(boot_obj$background_region_scores, function(a) sum(a[a > cutoff]), numeric(1))
  bsd <- stats::sd(b_tot); z <- if (is.finite(bsd) && bsd > 0) (t_tot - mean(b_tot)) / bsd else NA
  p_tot <- (sum(b_tot >= t_tot) + 1) / (nb + 1)
  # methylation effect of the same regions (cytosine-equivalents)
  has_me <- !is.null(trs$meth_effect) && !all(is.na(trs$meth_effect)) &&
    !is.null(boot_obj$background_region_effects)
  if (has_me) {
    t_me <- sum(trs$meth_effect[sel], na.rm = TRUE)
    b_me <- mapply(function(a, m) sum(m[a > cutoff], na.rm = TRUE),
                   boot_obj$background_region_scores, boot_obj$background_region_effects)
  } else { t_me <- NA_real_; b_me <- rep(NA_real_, nb) }
  # Fisher combination of the best-DMR p-values, calibrated on the background windows
  pv <- function(x, ref) (sum(ref >= x) + 1) / (length(ref) + 1)
  F_t <- -2 * sum(vapply(contexts, function(cx) log(pv(bo[[paste0(cx, "_Score")]][1], bo[[paste0(cx, "_Score")]][-1])), numeric(1)))
  F_b <- -2 * Reduce(`+`, lapply(contexts, function(cx) {
    b <- bo[[paste0(cx, "_Score")]][-1]
    log((rank(-b, ties.method = "max") + 1) / (nb + 1))      # each window's p vs. the background
  }))
  p_fis <- (sum(F_b >= F_t) + 1) / (nb + 1)
  ov <- data.frame(Context = "Overall", Test = paste0("Total of DMRs > ", cutoff),
                   Best_Region = NA, Region_Start = NA, Region_Stop = NA,
                   N_Regions = t_n, Target_Score = round(t_tot, 3),
                   Background_Mean = round(mean(b_tot), 3), Background_SD = round(bsd, 3),
                   Background_95pct = round(stats::quantile(b_tot, 0.95, names = FALSE), 3),
                   Background_Z = round(z, 2), Excess_Score = round(t_tot - mean(b_tot), 3),
                   P_Value = signif(p_tot, 3), P_Best_DMRs_Combined = signif(p_fis, 3),
                   Final_Score = NA_real_, Evidence = boot_evidence(p_tot),
                   Meth_Effect = round(t_me, 3), Bg_Mean_Meth_Effect = round(mean(b_me), 3),
                   Bg_95pct_Meth_Effect = if (has_me) round(stats::quantile(b_me, 0.95, names = FALSE), 3) else NA_real_,
                   Excess_Meth_Effect = round(t_me - mean(b_me), 3),
                   stringsAsFactors = FALSE)
  s <- boot_obj$summary[boot_obj$summary$Context != "Overall", ]
  if (!"Test" %in% names(s)) s$Test <- "Best DMR"          # objects from older versions
  if ("P_Fisher" %in% names(s)) names(s)[names(s) == "P_Fisher"] <- "P_Best_DMRs_Combined"
  for (m in setdiff(names(ov), names(s))) s[[m]] <- NA
  boot_obj$summary <- rbind(s[, names(ov)], ov)
  rownames(boot_obj$summary) <- NULL
  boot_obj$settings$overall_cutoff <- cutoff
  boot_obj$background_totals <- b_tot
  boot_obj$background_meth_effects <- b_me
  boot_obj <- build_boot_plots(boot_obj)
  if (verbose) print_boot_summary(boot_obj)
  if (make_plot) print(boot_obj$plot)
  boot_obj
}

#' Console table for a boot_score() result
#' @noRd
print_boot_summary <- function(boot_obj, n_genes = NULL) {
  st <- boot_obj$settings; s <- boot_obj$summary
  if (is.null(n_genes)) n_genes <- length(unique(boot_obj$bootstrap_scores$Gene[-1]))
  fp <- function(p) format(p, digits = 2, scientific = FALSE)
  cat(sprintf("\nboot_score: %s | target window %s to %s bp (%s bp) | %s | direction: %s\n",
              st$target_gene, st$target_start, st$target_end, st$target_end - st$target_start,
              st$scoring_col_name, st$direction_DMR))
  cat(sprintf("Background: %d windows of the same width in %d other genes%s\n", st$nboots, n_genes,
              if (length(st$exclude_genes)) paste0(" (excluded: ", paste(st$exclude_genes, collapse = ", "), ")") else ""))
  cat("\nBest DMR per context\n")
  ctx <- s[s$Context != "Overall", ]
  show <- data.frame(Context = ctx$Context,
                     `Best DMR` = ifelse(is.na(ctx$Best_Region), "-",
                       paste0(ctx$Best_Region, " (", ctx$Region_Start, " to ", ctx$Region_Stop, ")")),
                     Score = round(ctx$Target_Score, 2), `Bg mean` = round(ctx$Background_Mean, 2),
                     `Bg 95%` = round(ctx$Background_95pct, 2), z = ctx$Background_Z,
                     p = fp(ctx$P_Value), Evidence = ctx$Evidence, check.names = FALSE)
  print(show, row.names = FALSE)
  o <- s[s$Context == "Overall", ]
  cat(sprintf("  Best DMRs combined (calibrated Fisher): p %s\n", fp(o$P_Best_DMRs_Combined)))
  cat(sprintf(paste0("\nAll DMRs > %s (%d, all contexts)\n",
                     "  Total score        %.1f vs. background mean %.1f (95%%: %.1f) | excess %.1f | z %.2f | p %s | %s\n"),
              st$overall_cutoff, o$N_Regions, o$Target_Score, o$Background_Mean, o$Background_95pct,
              o$Excess_Score, o$Background_Z, fp(o$P_Value), o$Evidence))
  if (!is.na(o$Meth_Effect)) {
    cat(sprintf("  Methylation effect %.1f C-equiv. vs. background mean %.1f (95%%: %.1f) | excess %.1f\n",
                o$Meth_Effect, o$Bg_Mean_Meth_Effect, o$Bg_95pct_Meth_Effect, o$Excess_Meth_Effect))
  }
  cat("\nScore = distance-weighted region score; z = (Score - Bg mean) / Bg SD; p = share of background",
      "\nwindows at least as high (strong < 0.01, significant < 0.05, suggestive < 0.1). Excess = target",
      "\nminus background mean. Methylation effect = sum of weight x cytosines x mean change / 100.\n\n")
  invisible(boot_obj)
}

#' Build the bootstrap and region plots
#' @noRd
build_boot_plots <- function(boot_obj) {
  st <- boot_obj$settings; s <- boot_obj$summary; bo <- boot_obj$bootstrap_scores
  contexts <- c("CG", "CHG", "CHH")
  o <- s[s$Context == "Overall", ]
  has_me <- !is.na(o$Meth_Effect) && !is.null(boot_obj$background_meth_effects)
  panel_lab <- c(CG = "Best CG DMR (score)", CHG = "Best CHG DMR (score)", CHH = "Best CHH DMR (score)",
                 Overall = paste0("Total score of all DMRs > ", st$overall_cutoff),
                 Effect = paste0("Methylation effect of all DMRs > ", st$overall_cutoff, " (cytosine-equivalents)"))
  if (!has_me) panel_lab <- panel_lab[names(panel_lab) != "Effect"]
  cols <- c(CG = "#2a78d6", CHG = "#eb6834", CHH = "#1baf7a", Overall = "#1f1f1f", Effect = "#6b4fbb")
  long <- rbind(do.call(rbind, lapply(contexts, function(cx)
                  data.frame(Panel = cx, Score = bo[[paste0(cx, "_Score")]][-1]))),
                data.frame(Panel = "Overall", Score = boot_obj$background_totals),
                if (has_me) data.frame(Panel = "Effect", Score = boot_obj$background_meth_effects))
  long$Panel <- factor(long$Panel, levels = names(panel_lab), labels = panel_lab)
  fp <- function(p) format(p, digits = 2)
  marks <- data.frame(Key = s$Context, Target = s$Target_Score, Bg = s$Background_Mean,
                      label = ifelse(s$Context == "Overall",
                        sprintf("target %.1f (%d DMRs)\nexcess %.1f, p = %s", s$Target_Score, s$N_Regions,
                                s$Excess_Score, fp(s$P_Value)),
                        sprintf("target %.1f\np = %s", s$Target_Score, fp(s$P_Value))))
  if (has_me) marks <- rbind(marks, data.frame(Key = "Effect", Target = o$Meth_Effect, Bg = o$Bg_Mean_Meth_Effect,
                      label = sprintf("target %.1f\nexcess %.1f", o$Meth_Effect, o$Excess_Meth_Effect)))
  marks$Panel <- factor(marks$Key, levels = names(panel_lab), labels = panel_lab)
  marks$colour <- cols[marks$Key]
  # put the label on the left of the line when the target sits at the right of its panel
  pmax_panel <- tapply(long$Score, long$Panel, max)[as.character(marks$Panel)]
  marks$hj <- ifelse(marks$Target > 0.6 * pmax(pmax_panel, marks$Target, na.rm = TRUE), 1.06, -0.06)
  boot_obj$plot <- ggplot(long, aes(Score)) +
    geom_histogram(bins = 40, fill = "#c9c9c9", colour = "white", linewidth = 0.2) +
    geom_vline(data = marks, aes(xintercept = Bg), colour = "grey45",
               linetype = "dotted", linewidth = 0.5) +
    geom_vline(data = marks, aes(xintercept = Target), colour = marks$colour, linewidth = 0.9) +
    geom_text(data = marks, aes(x = Target, y = Inf, label = label, hjust = hj),
              colour = marks$colour, vjust = 1.3, size = 3, lineheight = 0.9) +
    facet_wrap(~Panel, ncol = 1, scales = "free") +
    labs(x = paste0("Distance-weighted ", st$scoring_col_name, " (methylation effect: cytosine-equivalents)"),
         y = "Background windows",
         title = paste0("Bootstrap: ", st$target_gene, " (", st$target_start, " to ", st$target_end, " bp)"),
         subtitle = paste0("Grey = ", st$nboots, " random same-width windows in other genes; ",
                           "dotted = background mean; solid = target")) +
    theme_minimal(base_size = 10) +
    theme(plot.background = element_rect(fill = "white", colour = NA)) +
    theme(panel.grid.minor = element_blank(), strip.text = element_text(face = "bold", hjust = 0),
          plot.title = element_text(face = "bold"))

  rp <- boot_obj$target_rs; rp$Context <- factor(rp$CX, levels = contexts)
  boot_obj$region_plot <- ggplot(rp) +
    annotate("rect", xmin = st$target_start, xmax = st$target_end, ymin = -Inf, ymax = Inf,
             fill = "#f2f2f2", colour = NA) +
    geom_hline(yintercept = 0, colour = "grey70", linewidth = 0.3) +
    geom_hline(yintercept = st$overall_cutoff, colour = "grey45", linetype = "dashed", linewidth = 0.3) +
    geom_segment(aes(x = Start, xend = Stop, y = adjusted_soundscore, yend = adjusted_soundscore,
                     colour = Context), linewidth = 1.6, lineend = "round") +
    scale_colour_manual(values = cols[contexts], drop = FALSE) +
    labs(x = paste0("Position relative to ", st$target_gene, " (bp); shaded = target window, ",
                    "dashed = cutoff ", st$overall_cutoff),
         y = "Adjusted score", colour = "Context",
         title = paste0(st$target_gene, ": distance-weighted region scores (", st$scoring_col_name, ")")) +
    theme_minimal(base_size = 10) +
    theme(plot.background = element_rect(fill = "white", colour = NA)) +
    theme(panel.grid.minor = element_blank(), plot.title = element_text(face = "bold"))
  boot_obj
}

#' Compare Target vs. Off-Target Treatments
#'
#' A function to calculate differences between target group and off-targets
#'
#' @param Target (str) - Name of the treatment group of interest
#' @param N_Treat_Groups (val) - Number of other groups
#' @param new_column_name (str) - Name of created column
#' @param ms (df) - Methylsummary file
#' @return ms (df) - MS file with new column
#' @export


Treatment_Compare<-function(Target="T1", N_Treat_Groups=8, new_column_name="on_v_off_T1", ms=methyl_summary){
  ms[new_column_name]<-(ms[Target]-ms$Treated)*(N_Treat_Groups/(N_Treat_Groups-1))
  return(ms)
}

#' Compare methylation in all groups at a changepot region
#'
#' Plotting function to compare methylation at a cpt of interest
#'
#' @param cpt_id (str) - Name of the cpt of interest
#' @param dmr_obj (list) - Name of dmr_obj
#' @export


cpt_compare<-function(cpt_id="LsAGL24_CHH_6", dmr_score_obj=DMR_score_AGL24_Z){
  OT<-dmr_score_obj$methyl_summary[dmr_score_obj$methyl_summary$cp_group==cpt_id,]
  stacked_data <- stack(OT[,str_ends(colnames(OT), "mean")])
  ggplot(stacked_data, aes(x=ind,y=values))+geom_boxplot(outlier.shape = NA)+ 
    stat_summary(fun = "mean",
                 geom = "point",
                 color = "red")+ylab("Percent Methylation")+xlab("Treatment Group")+ggtitle(as.character(OT$cp_group[1]))
}

#' Automatically plot and save all DMRs that passed a given threshold and save plot to Working Directory
#'
#' Plotting function to compare methylation at a cpt of interest
#'
#' @param sig_dmrs (df) - Name of the cpt of interest
#' @param dmr_score_file (list) - Name of dmr_obj
#' @param prefix (str) - Name of dmr_obj
#' @seealso [run_dmr_downstream()] and [plot_dmr_methylation()], which supersede
#' this function.
#' @export

treatment_plots<-function(sig_dmrs=DMR_boot_T7_sig, dmr_score_file=DMR_score_T7, prefix="T7_"){
for(i in 1:nrow(sig_dmrs)){
  cpt_compare(cpt_id = as.character(sig_dmrs[i,1]), dmr_score_obj = dmr_score_file)
  ggsave(paste(prefix,as.character(sig_dmrs[i,1]), ".pdf", sep=""), height = 5, width=7)
}
}

#' Automatically save stats for all DMRs that passed a given threshold and add RD to summary table
#' Plotting function to compare methylation at a cpt of interest
#'
#' @param combined_DMRs (df) - Name of combined_df
#' @param dmr_obj_file (list) - Name of dmr_obj
#' @seealso [run_dmr_downstream()], which supersedes this function and returns
#' plain numeric target / control read-depth columns.
#' @export

DMR_Info <- function(combined_DMRs = combined_df, dmr_obj_file=dmr_obj) {
  
  for (i in 1:nrow(combined_DMRs)){
    combined_DMRs[i,]->DMR_X
    dmr_obj_file$LongPercent[dmr_obj_file$LongPercent$Gene==DMR_X$Gene & dmr_obj_file$LongPercent$CX==DMR_X$CX & dmr_obj_file$LongPercent$Position >= DMR_X$Genome_Low & dmr_obj_file$LongPercent$Position<=DMR_X$Genome_High,]->dmr_obj_X  
    dmr_obj_X %>%
      group_by(Treatment) %>%
      summarise(across(c(Percent, total_RD), 
                       list(mean = ~mean(.x, na.rm = TRUE), 
                            iqr = ~IQR(.x, na.rm = TRUE)))) -> st_X
    write.csv(st_X, file=paste(DMR_X[1,1],DMR_X[1,2],"summary.csv", sep="_"), row.names = FALSE)
    
    combined_DMRs$RD_Target[i]<-st_X[st_X$Treatment==combined_DMRs$source_df[i],4]
  }
  return(combined_DMRs)
}


                                

