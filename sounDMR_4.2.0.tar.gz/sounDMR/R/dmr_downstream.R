#Copyright 2023 Sound Agriculture Company
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# -----------------------------------------------------------------------------
# Downstream summaries and figures for significant DMRs.
#
# Replaces the ad-hoc combine / datasummary / DMR_Info / treatment_plots steps:
#   * nothing is selected by column position - everything by name
#   * treatment-specific column names (Z_TreatmentT3_small_mean, T3_mean_dif_mean,
#     ...) are mapped to shared names so any number of treatments rbind cleanly
#   * any number of target genes per treatment (summaries by Treatment and by
#     Treatment x Gene)
#   * every output column is atomic (no list columns)
#   * treatments / contexts with zero significant DMRs still appear in summaries
#
# Note: reshape2 is also imported by this package and masks data.table's
# dcast()/melt(), so those are always called as data.table::dcast / data.table::melt.
# -----------------------------------------------------------------------------

CX_LEVELS <- c("CG", "CHG", "CHH")
CX_COLORS <- c(CG = "#2a78d6", CHG = "#eb6834", CHH = "#1baf7a")

utils::globalVariables(c(
  ".", "..need", "..by", "..join_by", ".score", "CX", "Chr", "Count", "Cyt",
  "DMR_ID", "Gene", "Genome_High", "Genome_Low", "Group_Label", "Label", "Max",
  "Mid", "N", "Percent", "Percent_Control", "Percent_Target", "Percent_Dif_vs_Control",
  "Percent_Off_Target", "Percent_Dif_vs_Off_Target", "Off_Group",
  "Dif_Vs_Control_mean", "Dif_Vs_Off_Target_mean", "Off_Target_Fraction", "Off_Target_Adjusted_Score",
  "Percent_mean", "Plant", "Position", "RD_iqr", "RD_mean", "Role", "Score", "Source",
  "Start", "Stop", "Total_DMRs", "Total_Score", "Treatment", "cp_group", "i.DMR_ID",
  "score", "total_RD", "x.Group_Label", "x.Percent", "x.Plant", "x.Position",
  "x.total_RD", "xend", "y", "yend", "Context", "Boot_Cutoff", "Boot_Summed_Score",
  "Bg_Mean_Total_Score", "Bg_95pct_Total_Score", "Excess_Total_Score", "Excess_Meth_Effect",
  "Bg_Mean_Meth_Effect", "Boot_Total", "Boot_ME", "DMR_Cutoff", "Total_Meth_Effect", "meth_effect",
  "ME", "Tot", "Bg", "Q95", "Ex", "P", "txt", "top", "What",
  "Label", "Test", "lab", "DMR_Rarity", "Bootstrap_Windows", "Best_DMR_Score", ".score", ".raw", "Direction", "Loss_DMRs", "Total", "N", "Dir", "sgn", "ypos", "Loss_Total_Score",
  "Excess_Total_Score", "P_Total_Score", "Evidence_Total_Score", "P_Strong_DMRs", "Excess_Meth_Effect",
  "Loss_Excess_Total_Score", "Loss_Excess_Meth_Effect", "V1"
))


# -----------------------------------------------------------------------------
# 1. Selecting and combining significant DMR tables
# -----------------------------------------------------------------------------

#' Get Significant DMRs from a boot_score Object
#'
#' Pull the changepoint regions around the target gene whose precision-adjusted
#' score passes a threshold.
#'
#' @param boot_obj (list) - output of `boot_score()`
#' @param min_score (num) - keep regions with `score_col` strictly greater than this
#' @param score_col (str) - column to threshold on
#' @return (df) - the passing rows of `boot_obj$target_rs`, ungrouped
#' @examples
#' # DMR_boot_T2_sig <- get_sig_dmrs(DMR_boot_T2, min_score = 6)
#' @export
get_sig_dmrs <- function(boot_obj, min_score = 6, score_col = "adjusted_soundscore") {
  rs <- as.data.frame(boot_obj$target_rs)
  if (!score_col %in% names(rs)) stop("`", score_col, "` not found in boot_obj$target_rs")
  rs[!is.na(rs[[score_col]]) & rs[[score_col]] > min_score, , drop = FALSE]
}

#' @noRd
treatment_from_name <- function(list_name, name_pattern = "^DMR_boot_(.+)_sig$") {
  if (is.null(list_name) || !nzchar(list_name) || !grepl(name_pattern, list_name)) {
    return(NA_character_)
  }
  sub(name_pattern, "\\1", list_name)
}

#' @noRd
treatment_from_z <- function(df, target_variable = "Treatment", z_suffix = "_small") {
  pat <- paste0("^Z_", target_variable, "(.+)", z_suffix, "_mean$")
  hits <- grep(pat, names(df), value = TRUE)
  if (length(hits) == 1) sub(pat, "\\1", hits) else NA_character_
}

#' Infer the treatment a sig-DMR table belongs to
#'
#' Primary source is the object name (`DMR_boot_<TX>_sig` -> `<TX>`). The Z column
#' written by `sound_score()` (e.g. `Z_TreatmentT3_small_mean` -> `T3`) is used as
#' a check: if the name has extra text after the Z treatment
#' (`DMR_boot_T3_geneB_sig`) the Z treatment is used; if they disagree otherwise
#' the name is used with a warning; with no usable name the Z column is used.
#' @noRd
infer_treatment <- function(df, list_name = NULL, target_variable = "Treatment",
                            z_suffix = "_small", name_pattern = "^DMR_boot_(.+)_sig$") {
  from_name <- treatment_from_name(list_name, name_pattern)
  from_z    <- treatment_from_z(df, target_variable, z_suffix)

  if (is.na(from_name) && is.na(from_z)) {
    stop("Could not get a treatment for '", list_name, "': name doesn't match ",
         name_pattern, " and no Z_", target_variable, "..._mean column. ",
         "Pass `treatments =` explicitly.")
  }
  if (is.na(from_name)) return(from_z)
  if (is.na(from_z) || from_name == from_z) return(from_name)
  if (startsWith(from_name, paste0(from_z, "_"))) return(from_z)
  warning("'", list_name, "': name says treatment '", from_name,
          "' but its Z column is for '", from_z, "'. Using '", from_name, "'.")
  from_name
}

#' Map treatment-specific column names to shared ones
#'   MethRegion_Z_TreatmentT3_small_mean -> MethRegion_Z_mean
#'   T3_mean_dif_mean                    -> Dif_Vs_Control_mean
#'   T3_off_mean                         -> Dif_Vs_Off_Target_mean
#' @noRd
standardize_sig_cols <- function(dt, treatment, target_variable = "Treatment",
                                 z_suffix = "_small",
                                 per_change_suffix = "_mean_dif",
                                 off_suffix = "_off") {
  nm <- names(dt)
  nm <- gsub(paste0("Z_", target_variable, treatment, z_suffix), "Z", nm, fixed = TRUE)
  swap_prefix <- function(x, old, new) {
    hit <- startsWith(x, old)
    x[hit] <- paste0(new, substring(x[hit], nchar(old) + 1))
    x
  }
  nm <- swap_prefix(nm, paste0(treatment, per_change_suffix), "Dif_Vs_Control")
  nm <- swap_prefix(nm, paste0(treatment, off_suffix), "Dif_Vs_Off_Target")
  data.table::setnames(dt, nm)
  dt
}

#' Combine Significant DMR Tables
#'
#' Combine any number of significant-DMR tables (one per treatment, or one per
#' treatment x target gene) into one flat table with shared column names.
#'
#' The treatment for each table comes from its name (`DMR_boot_<TX>_sig` ->
#' `<TX>`), cross-checked against its `Z_<target_variable><TX>_small_mean` column.
#' Target gene(s) come from each table's `Gene` column, so a table can hold one or
#' several genes, and several tables can share a treatment.
#'
#' @param sig_list (named list of df) - e.g. `mget(ls(pattern = "^DMR_boot_.*_sig$"))`
#' @param treatments (chr) *optional* - treatment for each element of `sig_list`;
#' overrides inference
#' @param target_variable (str) - the fixed effect used in `find_DMR()`
#' @param z_suffix,per_change_suffix,off_suffix (str) - naming used for the Z,
#' percent-change and off-target columns
#' @param name_pattern (regex) - pattern with one capture group for the treatment
#' @param verbose (bool) - print the table -> treatment -> gene mapping
#' @return (data.table) - one row per DMR with `Treatment`, `Source` and `DMR_ID`
#' first. `attr(, "treatments")` holds every treatment seen (including ones with 0
#' DMRs), `attr(, "mapping")` the mapping that was used, and `attr(, "pairs")` every
#' treatment x gene, including empty tables whose gene is given by their name
#' (`DMR_boot_<TX>_<gene>_sig`).
#' @import data.table
#' @export
combine_sig_dmrs <- function(sig_list, treatments = NULL,
                             target_variable = "Treatment", z_suffix = "_small",
                             per_change_suffix = "_mean_dif", off_suffix = "_off",
                             name_pattern = "^DMR_boot_(.+)_sig$", verbose = TRUE) {
  if (is.data.frame(sig_list)) sig_list <- list(sig_list)
  if (!is.null(treatments) && length(treatments) != length(sig_list)) {
    stop("`treatments` must be the same length as `sig_list`.")
  }
  nms <- names(sig_list)
  if (is.null(nms)) nms <- rep("", length(sig_list))
  nms[is.na(nms)] <- ""
  src <- ifelse(nzchar(nms), nms, paste0("table_", seq_along(sig_list)))

  mapping <- vector("list", length(sig_list))
  pairs   <- vector("list", length(sig_list))
  pieces <- lapply(seq_along(sig_list), function(i) {
    df <- sig_list[[i]]
    trt <- if (!is.null(treatments)) treatments[i] else
      infer_treatment(df, nms[i], target_variable, z_suffix, name_pattern)
    genes <- if (nrow(df) && "Gene" %in% names(df)) sort(unique(as.character(df$Gene))) else character(0)
    # An empty table has no Gene column values; if it is named
    # DMR_boot_<TX>_<gene>_sig, take the gene from the name so the
    # treatment x gene pair still shows up (as zeros) in the by-gene summary.
    name_gene <- NA_character_
    if (!length(genes)) {
      stem <- paste0("DMR_boot_", trt, "_")
      if (startsWith(nms[i], stem) && endsWith(nms[i], "_sig")) {
        name_gene <- sub("_sig$", "", substring(nms[i], nchar(stem) + 1))
      }
    }
    mapping[[i]] <<- data.table(
      Source = src[i], Treatment = trt,
      Genes = if (length(genes)) paste(genes, collapse = "; ") else
        if (!is.na(name_gene)) paste(name_gene, "(no DMRs)") else "(no DMRs)",
      N_DMRs = nrow(df))
    pairs[[i]] <<- data.table(Treatment = trt,
                              Gene = if (length(genes)) genes else name_gene)
    if (nrow(df) == 0) return(NULL)
    dt <- as.data.table(as.data.frame(df))          # drops dplyr grouping
    # rename columns using the treatment they were actually written with
    col_trt <- treatment_from_z(df, target_variable, z_suffix)
    if (is.na(col_trt)) col_trt <- trt
    dt <- standardize_sig_cols(dt, col_trt, target_variable, z_suffix,
                               per_change_suffix, off_suffix)
    dt[, `:=`(Treatment = trt, Source = src[i])]
    dt
  })
  mapping <- rbindlist(mapping)
  if (verbose) {
    message("Sig table -> treatment -> gene mapping:")
    message(paste(utils::capture.output(print(mapping, row.names = FALSE)), collapse = "\n"))
  }

  out <- rbindlist(pieces, use.names = TRUE, fill = TRUE)
  if (nrow(out) == 0) stop("All sig-DMR tables are empty.")
  out[, DMR_ID := paste(Treatment, cp_group, sep = "|")]
  dup <- duplicated(out$DMR_ID)
  if (any(dup)) {
    message(sum(dup), " duplicate DMR rows (same treatment + cp_group) dropped.")
    out <- out[!dup]
  }
  setcolorder(out, c("Treatment", "Source", "DMR_ID"))
  setattr(out, "treatments", unique(mapping$Treatment))
  setattr(out, "mapping", mapping)
  pairs <- unique(rbindlist(pairs))
  setattr(out, "pairs", pairs[!is.na(Gene)])
  out[]
}


# -----------------------------------------------------------------------------
# 2. Per-DMR, per-treatment methylation and read depth (replaces DMR_Info)
# -----------------------------------------------------------------------------

#' Extract Cytosine-Level Data Inside Each DMR
#'
#' Pull every cytosine x sample observation in `LongPercent` that falls inside
#' each DMR (same gene, same context, between `Genome_Low` and `Genome_High`),
#' using a single non-equi join.
#'
#' @param dmrs (data.table) - output of `combine_sig_dmrs()`
#' @param long_percent (df) - `dmr_obj$LongPercent`
#' @param treatment_col (str) - column in `long_percent` holding treatment labels
#' @return (data.table) - `DMR_ID, Treatment, Plant, Position, Percent, total_RD`
#' @export
dmr_cytosine_data <- function(dmrs, long_percent, treatment_col = "Treatment") {
  need <- c("Gene", "CX", "Position", "Plant", "Percent", "total_RD", treatment_col)
  miss <- setdiff(need, names(long_percent))
  if (length(miss)) stop("long_percent is missing: ", paste(miss, collapse = ", "))

  lp <- as.data.table(long_percent)[Gene %in% unique(dmrs$Gene), ..need]
  setnames(lp, treatment_col, "Group_Label")
  regions <- unique(as.data.table(dmrs)[, .(DMR_ID, Gene, CX, Genome_Low, Genome_High)])

  lp[regions,
     on = .(Gene, CX, Position >= Genome_Low, Position <= Genome_High),
     nomatch = NULL, allow.cartesian = TRUE,
     .(DMR_ID = i.DMR_ID, Treatment = x.Group_Label, Plant = x.Plant,
       Position = x.Position, Percent = x.Percent, total_RD = x.total_RD)]
}

#' Per-DMR Statistics for Every Treatment Group
#'
#' @param cyto (data.table) - output of `dmr_cytosine_data()`
#' @return (data.table) - one row per DMR x treatment group: number of cytosines
#' and samples, mean and IQR of percent methylation and of read depth
#' @export
dmr_group_stats <- function(cyto) {
  cyto[, .(n_cytosines  = uniqueN(Position),
           n_samples    = uniqueN(Plant),
           Percent_mean = mean(Percent, na.rm = TRUE),
           Percent_iqr  = stats::IQR(Percent, na.rm = TRUE),
           RD_mean      = mean(total_RD, na.rm = TRUE),
           RD_iqr       = stats::IQR(total_RD, na.rm = TRUE)),
       by = .(DMR_ID, Treatment)]
}

#' Add Target, Control and Off-Target Methylation / Read Depth to the DMR Table
#'
#' Adds plain numeric columns measured inside each DMR:
#' \itemize{
#'   \item `Percent_Target`, `RD_Target`, `RD_Target_IQR` - the DMR's own treatment
#'   \item `Percent_Control`, `RD_Control`, `RD_Control_IQR` - the control group
#'   \item `Percent_Dif_vs_Control` - target minus control
#'   \item with `off_targets`: `Off_Targets` (which treatments), `Percent_Off_Target`,
#'   `RD_Off_Target` (mean over those treatment groups, each weighted equally) and
#'   `Percent_Dif_vs_Off_Target` - target minus off-target
#' }
#'
#' @param dmrs (data.table) - output of `combine_sig_dmrs()`
#' @param stats (data.table) - output of `dmr_group_stats()`
#' @param control (str) - control level of the treatment column
#' @param off_targets (named list) *optional* - for each treatment, the treatments
#' that targeted a DIFFERENT gene, used as an off-target baseline, e.g.
#' `list(T2 = c("T5", "T6", "T7"), T5 = c("T2", "T3", "T4"))`. Treatments not
#' named get no off-target columns (NA).
#' @return (data.table) - `dmrs` with the added columns
#' @export
add_target_stats <- function(dmrs, stats, control, off_targets = NULL) {
  if (!control %in% stats$Treatment) {
    warning("Control group '", control, "' not found in LongPercent; control columns will be NA.")
  }
  tgt <- stats[, .(DMR_ID, Treatment, Percent_Target = Percent_mean, RD_Target = RD_mean,
                   RD_Target_IQR = RD_iqr)]
  ctl <- stats[Treatment == control,
               .(DMR_ID, Percent_Control = Percent_mean, RD_Control = RD_mean,
                 RD_Control_IQR = RD_iqr)]
  out <- merge(as.data.table(dmrs), tgt, by = c("DMR_ID", "Treatment"), all.x = TRUE, sort = FALSE)
  out <- merge(out, ctl, by = "DMR_ID", all.x = TRUE, sort = FALSE)
  out[, Percent_Dif_vs_Control := Percent_Target - Percent_Control]

  ot <- off_target_table(off_targets)
  if (nrow(ot)) {
    missing_groups <- setdiff(ot$Off_Group, stats$Treatment)
    if (length(missing_groups)) {
      warning("Off-target treatment(s) not found in LongPercent: ",
              paste(missing_groups, collapse = ", "))
    }
    x <- merge(unique(out[, .(DMR_ID, Treatment)]), ot, by = "Treatment", allow.cartesian = TRUE)
    x <- merge(x, stats[, .(DMR_ID, Off_Group = Treatment, Percent_mean, RD_mean)],
               by = c("DMR_ID", "Off_Group"))
    offs <- x[, .(Off_Targets        = paste(sort(unique(Off_Group)), collapse = "; "),
                  Percent_Off_Target = mean(Percent_mean, na.rm = TRUE),
                  RD_Off_Target      = mean(RD_mean, na.rm = TRUE)),
              by = DMR_ID]
    out <- merge(out, offs, by = "DMR_ID", all.x = TRUE, sort = FALSE)
    out[, Percent_Dif_vs_Off_Target := Percent_Target - Percent_Off_Target]
  }

  if (anyNA(out$RD_Target)) {
    warning(sum(is.na(out$RD_Target)), " DMR(s) had no matching rows in LongPercent ",
            "- check that treatment labels match.")
  }
  setcolorder(out, names(dmrs))
  out[]
}

#' Off-Target Fraction and Off-Target Adjusted Score
#'
#' For DMRs whose treatment has off-target treatments (so the region summary has
#' `Dif_Vs_Off_Target_mean`), adds:
#' \itemize{
#'   \item `Off_Target_Fraction` = (Dif_Vs_Control_mean - Dif_Vs_Off_Target_mean) /
#'   Dif_Vs_Control_mean, which equals (off-target - control) / (treatment - control):
#'   the share of the treatment's change that the off-target treatments also show.
#'   0 = fully specific to the targeting treatment; 1 = off-targets changed just as much;
#'   below 0 = off-targets moved the other way.
#'   \item `Off_Target_Adjusted_Score` = score x (1 + (1 - Off_Target_Fraction)):
#'   x2 for a fully specific DMR, x1 for a non-specific one.
#' }
#' DMRs without off-targets get NA in both.
#'
#' @param dmrs (data.table) - combined DMR table (from `combine_sig_dmrs()`)
#' @param score_col (str) - score to adjust, usually `adjusted_soundscore`
#' @return (data.table) - `dmrs` with the two columns added (if
#' `Dif_Vs_Off_Target_mean` is present; otherwise unchanged)
#' @export
add_off_target_scores <- function(dmrs, score_col = "adjusted_soundscore") {
  out <- as.data.table(dmrs)
  if (!all(c("Dif_Vs_Control_mean", "Dif_Vs_Off_Target_mean") %in% names(out))) return(out[])
  out[, Off_Target_Fraction := ifelse(is.na(Dif_Vs_Control_mean) | Dif_Vs_Control_mean == 0,
                                      NA_real_,
                                      (Dif_Vs_Control_mean - Dif_Vs_Off_Target_mean) / Dif_Vs_Control_mean)]
  out[, Off_Target_Adjusted_Score := get(score_col) * (1 + (1 - Off_Target_Fraction))]
  out[]
}

#' Long table of treatment -> off-target treatment pairs (self-references dropped)
#' @noRd
off_target_table <- function(off_targets) {
  if (is.null(off_targets) || !length(off_targets)) {
    return(data.table(Treatment = character(0), Off_Group = character(0)))
  }
  if (is.null(names(off_targets)) || any(!nzchar(names(off_targets)))) {
    stop("`off_targets` must be a named list: list(<treatment> = c(<off-target treatments>), ...)")
  }
  ot <- rbindlist(lapply(names(off_targets), function(t) {
    g <- setdiff(as.character(off_targets[[t]]), t)
    if (length(g)) data.table(Treatment = t, Off_Group = g) else NULL
  }))
  if (!nrow(ot)) ot <- data.table(Treatment = character(0), Off_Group = character(0))
  unique(ot)
}


# -----------------------------------------------------------------------------
# 3. Summary tables
# -----------------------------------------------------------------------------

#' Summarise DMR Scores by Treatment and Context
#'
#' Sum, count and max of the DMR score per cytosine context, for each treatment
#' (or treatment x gene). Every context always gets a column and every treatment in
#' `treatments` gets a row, even with no significant DMRs.
#'
#' @param dmrs (data.table) - combined DMR table
#' @param by (chr) - grouping columns, e.g. `"Treatment"` or `c("Treatment", "Gene")`
#' @param score_col (str) - score to sum / max
#' @param treatments (chr) - every treatment that should appear
#' @param cx_levels (chr) - cytosine contexts
#' @param design (df) *optional* - `Treatment` (and optionally `Gene`) plus
#' annotation columns (e.g. `Description`, `Oligo_Duplexes`) to merge in
#' @param required_keys (df) *optional* - combinations of the `by` columns that must
#' appear even with no significant DMRs, e.g. `attr(dmrs, "pairs")` for
#' treatment x gene summaries
#' @return (data.table) - summary table
#' @export
summarise_dmrs <- function(dmrs, by = "Treatment", score_col = "adjusted_soundscore",
                           treatments = attr(dmrs, "treatments"),
                           cx_levels = CX_LEVELS, design = NULL, required_keys = NULL) {
  dt <- copy(as.data.table(dmrs))
  dt[, .score := get(score_col)]

  has_me <- "meth_effect" %in% names(dt)
  if (!has_me) dt[, meth_effect := NA_real_]
  long <- dt[, .(Score = sum(.score, na.rm = TRUE), N = .N,
                 Max = max(.score, na.rm = TRUE), Cyt = sum(Count, na.rm = TRUE),
                 ME = sum(meth_effect, na.rm = TRUE)),
             by = c(by, "CX")]

  # full grid so empty contexts / treatments are explicit zeros, not missing columns
  keys <- unique(dt[, ..by])
  if (!is.null(treatments) && "Treatment" %in% by) {
    extra <- setdiff(treatments, keys$Treatment)
    if (length(extra)) keys <- rbind(keys, data.table(Treatment = extra), fill = TRUE)
  }
  if (!is.null(required_keys) && all(by %in% names(required_keys))) {
    keys <- unique(rbind(keys, unique(as.data.table(required_keys)[, by, with = FALSE])))
  }
  grid <- keys[, .(CX = cx_levels), by = by]
  long <- merge(grid, long, by = c(by, "CX"), all.x = TRUE)
  long[is.na(Score), `:=`(Score = 0, N = 0L, Cyt = 0L, ME = 0)]
  long[, CX := factor(CX, levels = cx_levels)]

  setnames(long, "ME", "Meth_Effect")
  wide <- data.table::dcast(long, stats::as.formula(paste(paste(by, collapse = " + "), "~ CX")),
                            value.var = c("Score", "N", "Max", if (has_me) "Meth_Effect"), sep = "_")
  totals <- long[, .(Total_Score = sum(Score), Total_DMRs = sum(N),
                     Cytosines_Covered = sum(Cyt), Total_Meth_Effect = sum(Meth_Effect)), by = by]
  if (!has_me) totals[, Total_Meth_Effect := NULL]
  out <- merge(wide, totals, by = by)

  # per-treatment summaries: list the target gene(s) each treatment's DMRs came from
  if (!"Gene" %in% by && "Gene" %in% names(dt)) {
    genes <- dt[, .(Genes = paste(sort(unique(Gene)), collapse = "; ")), by = by]
    out <- merge(out, genes, by = by, all.x = TRUE)
  }

  if (!is.null(design)) {
    design <- as.data.table(design)
    join_by <- intersect(by, names(design))
    if (!"Treatment" %in% join_by) stop("`design` needs a Treatment column.")
    unmatched <- setdiff(design$Treatment, out$Treatment)
    if (length(unmatched)) {
      warning("design Treatment(s) not found in the DMR tables: ",
              paste(unmatched, collapse = ", "),
              " - check spelling against LongPercent$Treatment.")
    }
    # design may be finer than this summary (e.g. per gene while summarising per
    # treatment): collapse to one row per key so rows are never duplicated
    extra_keys <- setdiff(intersect(names(design), c("Treatment", "Gene")), join_by)
    if (length(extra_keys) || anyDuplicated(design[, ..join_by])) {
      ann <- setdiff(names(design), c(join_by, extra_keys))
      design <- design[, lapply(.SD, function(x) {
        x <- unique(stats::na.omit(as.character(x)))
        if (length(x)) paste(x, collapse = "; ") else NA_character_
      }), by = join_by, .SDcols = ann]
    }
    out <- merge(out, design, by = join_by, all.x = TRUE)
  } else {
    out[, `:=`(Description = NA_character_, Oligo_Duplexes = NA_character_)]
  }

  col_order <- c(by, "Genes",
                 paste0("Score_", cx_levels), paste0("N_", cx_levels),
                 paste0("Max_", cx_levels),
                 "Total_Score", "Total_DMRs", "Cytosines_Covered",
                 paste0("Meth_Effect_", cx_levels), "Total_Meth_Effect")
  setcolorder(out, intersect(col_order, names(out)))
  num <- names(out)[vapply(out, is.numeric, logical(1))]
  out[, (num) := lapply(.SD, round, 2), .SDcols = num]
  setorderv(out, by)
  out[]
}

#' Rarity of Region Scores in the Bootstrap Background
#'
#' Share of all regions in the background windows of a `boot_score()` result whose
#' distance-weighted score is at least as high as each score.
#'
#' @param scores (num) - adjusted (distance-weighted) region scores
#' @param boot (list) - a `boot_score()` result
#' @return (num) rarity per score, e.g. 0.007 = top 0.7\% of background regions
#' @export
region_rarity <- function(scores, boot) {
  pool <- sort(unlist(boot$background_region_scores))
  if (!length(pool)) return(rep(NA_real_, length(scores)))
  n <- length(pool)
  (n - findInterval(scores, pool, left.open = TRUE) + 1) / (n + 1)
}

#' Strong-DMR and Best-DMR Tests for one boot_score() Result
#'
#' * **Strong DMRs** (harmonic-mean test): window statistic = sum over the target-gene
#'   regions with a positive distance-weighted score of 1 / rarity (`region_rarity()`),
#'   compared with the same statistic in every background window. Dominated by the 1-2
#'   rarest DMRs, so many weak DMRs add little (cf. the total-score test, which rewards
#'   many DMRs).
#' * **Best DMR per context** and **CG + CHG combined**: the CG and CHG best-DMR p-values
#'   combined with Fisher's method, calibrated on the same background windows.
#'
#' @param boot (list) - a `boot_score()` result
#' @return one-row data.table: `P_Strong_DMRs`, `Evidence_Strong_DMRs`, `Best_DMR_Score`,
#' `Best_DMR_Rarity`, `P_Best_DMRs_CG_CHG`, `Bootstrap_Windows`
#' @export
strong_dmr_tests <- function(boot) {
  bo <- boot$bootstrap_scores; nb <- nrow(bo) - 1
  tgt <- boot$target_rs$adjusted_soundscore
  best <- if (any(tgt > 0, na.rm = TRUE)) max(tgt, na.rm = TRUE) else 0
  if (length(boot$background_region_scores)) {
    stat <- function(s) { s <- s[!is.na(s) & s > 0]; if (length(s)) sum(1 / region_rarity(s, boot)) else 0 }
    t0 <- stat(tgt)
    bg <- vapply(boot$background_region_scores, stat, numeric(1))
    p_strong <- (sum(bg >= t0) + 1) / (length(bg) + 1)
    rar <- if (best > 0) region_rarity(best, boot) else 1
  } else { p_strong <- NA_real_; rar <- NA_real_ }
  p_of <- function(cx) { x <- bo[[paste0(cx, "_Score")]]; (sum(x[-1] >= x[1]) + 1) / (nb + 1) }
  p_bg <- function(cx) { b <- bo[[paste0(cx, "_Score")]][-1]; (rank(-b, ties.method = "max") + 1) / (nb + 1) }
  F_t <- -2 * (log(p_of("CG")) + log(p_of("CHG")))
  F_b <- -2 * (log(p_bg("CG")) + log(p_bg("CHG")))
  data.table(P_Strong_DMRs = signif(p_strong, 3), Evidence_Strong_DMRs = boot_evidence(p_strong),
             Best_DMR_Score = round(best, 2), Best_DMR_Rarity = signif(rar, 3),
             P_Best_DMRs_CG_CHG = signif((sum(F_b >= F_t) + 1) / (nb + 1), 3), Bootstrap_Windows = nb)
}

#' Bootstrap Results per Treatment x Gene
#'
#' Collects the results of `boot_score()` objects into one row per treatment x gene,
#' for merging into the downstream summaries.
#'
#' Columns: `DMR_Cutoff`; the **total-of-DMRs** test (`Total_Score`, `P_Total_Score`,
#' `Evidence_Total_Score`, `Z_Total_Score`, `Bg_Mean_Total_Score`, `Bg_95pct_Total_Score`,
#' `Excess_Total_Score` = total - background mean); the **methylation effect**
#' (`Total_Meth_Effect`, `Bg_Mean_Meth_Effect`, `Bg_95pct_Meth_Effect`,
#' `Excess_Meth_Effect`, in cytosine-equivalents); the **strong-DMR** test
#' (`P_Strong_DMRs`, `Evidence_Strong_DMRs`, `Best_DMR_Score`, `Best_DMR_Rarity`); and
#' the **best-DMR** tests (`P_Best_DMR_CG`, `P_Best_DMR_CHG`, `P_Best_DMR_CHH`, CG + CHG
#' combined `P_Best_DMRs_CG_CHG` and all three combined `P_Best_DMRs_Combined`), plus
#' `Bootstrap_Windows`. See `boot_score()` and `strong_dmr_tests()`.
#'
#' @param boots (named list) - `boot_score()` results, named like the sig tables
#' without `_sig` (e.g. `DMR_boot_T2` for `DMR_boot_T2_sig`)
#' @param mapping (data.table) - `attr(dmrs, "mapping")` from `combine_sig_dmrs()`
#' @return (data.table), or NULL if no boot object matches
#' @export
boot_results_table <- function(boots, mapping) {
  if (is.null(boots) || !length(boots)) return(NULL)
  keys <- sub("_sig$", "", mapping$Source)
  miss <- keys[!keys %in% names(boots)]
  if (length(miss)) message("No boot_score object for: ", paste(miss, collapse = ", "),
                            " - bootstrap columns left empty for these.")
  rows <- lapply(seq_len(nrow(mapping)), function(i) {
    b <- boots[[keys[i]]]
    if (is.null(b) || is.null(b$summary)) return(NULL)
    if (!"Overall" %in% b$summary$Context || !"Excess_Meth_Effect" %in% names(b$summary)) {
      b <- boot_overall(b, if (is.null(b$settings$overall_cutoff)) 8 else b$settings$overall_cutoff)
    }
    s <- as.data.table(b$summary); o <- s[Context == "Overall"]
    pc <- stats::setNames(s$P_Value, s$Context)
    st <- strong_dmr_tests(b)
    data.table(Treatment = mapping$Treatment[i], Gene = b$settings$target_gene,
               Direction = if (is.null(b$settings$direction_DMR)) "positive" else b$settings$direction_DMR,
               DMR_Cutoff = b$settings$overall_cutoff, Bootstrap_Windows = st$Bootstrap_Windows,
               Total_Score = o$Target_Score, P_Total_Score = o$P_Value,
               Evidence_Total_Score = o$Evidence,
               P_Strong_DMRs = st$P_Strong_DMRs, Evidence_Strong_DMRs = st$Evidence_Strong_DMRs,
               Best_DMR_Score = st$Best_DMR_Score, Best_DMR_Rarity = st$Best_DMR_Rarity,
               Z_Total_Score = o$Background_Z,
               Bg_Mean_Total_Score = o$Background_Mean, Bg_95pct_Total_Score = o$Background_95pct,
               Excess_Total_Score = o$Excess_Score,
               Total_Meth_Effect = o$Meth_Effect, Bg_Mean_Meth_Effect = o$Bg_Mean_Meth_Effect,
               Bg_95pct_Meth_Effect = o$Bg_95pct_Meth_Effect, Excess_Meth_Effect = o$Excess_Meth_Effect,
               P_Best_DMR_CG = pc[["CG"]], P_Best_DMR_CHG = pc[["CHG"]], P_Best_DMR_CHH = pc[["CHH"]],
               P_Best_DMRs_CG_CHG = st$P_Best_DMRs_CG_CHG, P_Best_DMRs_Combined = o$P_Best_DMRs_Combined)
  })
  out <- rbindlist(rows)
  if (!nrow(out)) return(NULL)
  unique(out, by = c("Treatment", "Gene"))
}

#' Merge bootstrap results into a summary table
#' @noRd
add_boot_results <- function(summ, bt, by) {
  if (is.null(bt)) return(summ)
  boot_cols <- setdiff(names(bt), c("Treatment", "Gene", "Total_Score", "Total_Meth_Effect"))
  chk <- copy(bt)
  setnames(chk, c("Total_Score", "Total_Meth_Effect"), c("Boot_Total", "Boot_ME"))
  if ("Gene" %in% by) {
    out <- merge(summ, chk, by = c("Treatment", "Gene"), all.x = TRUE, sort = FALSE)
  } else {
    # per treatment: p-values / z / 95th percentiles only when the treatment has a single
    # target gene; totals, background means and excesses are additive across genes
    agg <- chk[, if (.N == 1) .SD else
      .(Direction = paste(unique(Direction), collapse = "/"),
        DMR_Cutoff = if (uniqueN(DMR_Cutoff) == 1) DMR_Cutoff[1] else NA_real_,
        Bootstrap_Windows = Bootstrap_Windows[1],
        Boot_Total = sum(Boot_Total), P_Total_Score = NA_real_,
        Evidence_Total_Score = "see by-gene summary",
        P_Strong_DMRs = NA_real_, Evidence_Strong_DMRs = "see by-gene summary",
        Best_DMR_Score = max(Best_DMR_Score), Best_DMR_Rarity = NA_real_,
        Z_Total_Score = NA_real_,
        Bg_Mean_Total_Score = sum(Bg_Mean_Total_Score), Bg_95pct_Total_Score = NA_real_,
        Excess_Total_Score = sum(Excess_Total_Score),
        Boot_ME = sum(Boot_ME), Bg_Mean_Meth_Effect = sum(Bg_Mean_Meth_Effect),
        Bg_95pct_Meth_Effect = NA_real_, Excess_Meth_Effect = sum(Excess_Meth_Effect),
        P_Best_DMR_CG = NA_real_, P_Best_DMR_CHG = NA_real_, P_Best_DMR_CHH = NA_real_,
        P_Best_DMRs_CG_CHG = NA_real_, P_Best_DMRs_Combined = NA_real_),
      by = Treatment, .SDcols = setdiff(names(chk), c("Treatment", "Gene"))]
    out <- merge(summ, agg, by = "Treatment", all.x = TRUE, sort = FALSE)
  }
  # the bootstrap totals must equal the summed DMR table (same cutoff, same DMRs)
  bad <- out[!is.na(Boot_Total) & abs(Boot_Total - Total_Score) > 0.05]
  if (nrow(bad)) warning("Bootstrap total score differs from the summed DMR score for ",
                         paste(bad$Treatment, if ("Gene" %in% by) bad$Gene, collapse = ", "),
                         " - the significance cutoff and the boot_score cutoff differ. ",
                         "Run boot_overall(boot, cutoff) with the cutoff used in get_sig_dmrs().")
  if ("Total_Meth_Effect" %in% names(out)) {
    bad <- out[!is.na(Boot_ME) & abs(Boot_ME - Total_Meth_Effect) > 0.05]
    if (nrow(bad)) warning("Bootstrap methylation effect differs from the DMR table for ",
                           paste(bad$Treatment, collapse = ", "), ".")
  } else {
    out[, Total_Meth_Effect := Boot_ME]                       # sig tables from an older boot_score()
  }
  out[, c("Boot_Total", "Boot_ME") := NULL]
  lead <- setdiff(names(summ), c("Description", "Oligo_Duplexes"))
  setcolorder(out, c(intersect(c(lead, "Total_Meth_Effect"), names(out)), boot_cols))
  setorderv(out, by)
  out[]
}

#' Compact Summary Table for Sharing
#'
#' A short version of the `run_dmr_downstream()` summary: one row per treatment (x gene)
#' with the DMR counts, scores, the main bootstrap tests and the comparable
#' methylation effect. Columns without data (e.g. no bootstrap results) are dropped.
#'
#' @param summ (data.table) - `res$summary` or `res$summary_by_gene` (raw column names)
#' @return data.table with human-readable column names
#' @export
brief_summary <- function(summ) {
  s <- as.data.table(summ)
  g <- function(x) if (x %in% names(s)) s[[x]] else rep(NA, nrow(s))
  trio <- function(a, b, c, f = identity) ifelse(is.na(g(a)) & is.na(g(b)) & is.na(g(c)), NA_character_,
                                                 paste(f(g(a)), f(g(b)), f(g(c)), sep = " / "))
  fp <- function(p) ifelse(is.na(p), "-", trimws(formatC(signif(p, 2), format = "fg", digits = 2)))
  ev <- function(p, e) ifelse(is.na(p), NA_character_, paste0(fp(p), " (", e, ")"))
  out <- data.table(
    Treatment = s$Treatment,
    Gene = if ("Gene" %in% names(s)) s$Gene else g("Genes"),
    Direction = g("Direction"),
    `DMRs` = g("Total_DMRs"),
    `DMRs CG / CHG / CHH` = trio("N_CG", "N_CHG", "N_CHH"),
    `Total adjusted score` = round(g("Total_Score"), 1),
    `Excess adjusted score (vs. background)` = round(g("Excess_Total_Score"), 1),
    `p total score (many DMRs)` = ev(g("P_Total_Score"), g("Evidence_Total_Score")),
    `p strong DMRs` = ev(g("P_Strong_DMRs"), g("Evidence_Strong_DMRs")),
    `Best DMR adjusted score` = round(g("Best_DMR_Score"), 1),
    `Best DMR rarity` = signif(g("Best_DMR_Rarity"), 2),
    `p best DMR CG / CHG / CHH` = trio("P_Best_DMR_CG", "P_Best_DMR_CHG", "P_Best_DMR_CHH", fp),
    `p best CG + CHG` = signif(g("P_Best_DMRs_CG_CHG"), 2),
    `Meth effect (C-equiv.)` = round(g("Total_Meth_Effect"), 1),
    `Excess meth effect` = round(g("Excess_Meth_Effect"), 1),
    `Loss DMRs` = g("Loss_DMRs"),
    `Loss total adjusted score` = round(g("Loss_Total_Score"), 1),
    `p loss total score` = ev(g("Loss_P_Total_Score"), g("Loss_Evidence_Total_Score")),
    `p loss strong DMRs` = fp(g("Loss_P_Strong_DMRs")),
    Description = g("Description"))
  keep <- vapply(out, function(x) !all(is.na(x) | (is.character(x) & x %in% c("", "-"))), logical(1))
  out[, names(out)[keep], with = FALSE]
}

#' Compact DMR Table for Sharing
#'
#' A short version of `_dmrs.csv`: one row per DMR with its location, strength, rarity
#' and observed methylation in the target treatment, the control and (if set) the
#' off-target treatments. Sorted by treatment, then score.
#'
#' @param dmrs (data.table) - `res$dmrs` (raw column names)
#' @param score_col (str) - distance-adjusted DMR score column
#' @param raw_score_col (str) - the region score before distance adjustment; default the
#' first of `dmr_score4`, `dmr_score3` found
#' @return data.table with human-readable column names
#' @export
brief_dmrs <- function(dmrs, score_col = "adjusted_soundscore", raw_score_col = NULL) {
  d <- as.data.table(dmrs)
  if (is.null(raw_score_col)) raw_score_col <- intersect(c("dmr_score4", "dmr_score3"), names(d))[1]
  raw_lab <- paste0("DMR score (", if (is.na(raw_score_col)) "raw" else raw_score_col, ")")
  g <- function(x) if (x %in% names(d)) d[[x]] else rep(NA, nrow(d))
  r1 <- function(x) round(x, 1)
  out <- data.table(
    Treatment = d$Treatment, Gene = d$Gene, Context = d$CX,
    `Region (bp from gene start)` = ifelse(g("Start") == g("Stop"), as.character(g("Start")),
                                          paste0(g("Start"), " to ", g("Stop"))),
    `Genome position` = ifelse(g("Genome_Low") == g("Genome_High"), paste0(g("Chr"), ":", g("Genome_Low")),
                               paste0(g("Chr"), ":", g("Genome_Low"), "-", g("Genome_High"))),
    `Distance to target (bp)` = g("distance_from_target"),
    Cytosines = g("Count"),
    .raw = r1(g(raw_score_col)),
    `Adjusted score (distance-weighted)` = r1(g(score_col)),
    `Off-target adjusted score` = r1(g("Off_Target_Adjusted_Score")),
    Rarity = signif(g("DMR_Rarity"), 2),
    `Mean Z` = round(g("Z_mean"), 2),
    `Target %` = r1(g("Percent_Target")),
    `Control %` = r1(g("Percent_Control")),
    `Change vs. control (pts)` = r1(g("Percent_Dif_vs_Control")),
    `Off-target %` = r1(g("Percent_Off_Target")),
    `Change vs. off-target (pts)` = r1(g("Percent_Dif_vs_Off_Target")),
    `Off-target fraction` = round(g("Off_Target_Fraction"), 2),
    `Read depth target / control` = ifelse(is.na(g("RD_Target")), NA_character_,
                                           paste(r1(g("RD_Target")), r1(g("RD_Control")), sep = " / ")),
    .score = g(score_col))
  setorder(out, Treatment, -.score)
  out[, .score := NULL]
  setnames(out, ".raw", raw_lab)
  keep <- vapply(out, function(x) !all(is.na(x)), logical(1))
  out[, names(out)[keep], with = FALSE]
}

#' Human-Readable Summary Column Names
#'
#' `Score_CG` -> `CG Score`, `N_CG` -> `# CG DMRs`, `Max_CG` -> `Max CG Score`,
#' underscores -> spaces.
#'
#' @param summ (data.table) - output of `summarise_dmrs()`
#' @return (data.table) - renamed copy
#' @export
prettify_summary <- function(summ) {
  s <- copy(as.data.table(summ))
  nm <- names(s)
  nm <- sub("^Score_(.+)$", "\\1 Score", nm)
  nm <- sub("^N_(.+)$", "# \\1 DMRs", nm)
  nm <- sub("^Max_(.+)$", "Max \\1 Score", nm)
  nm <- gsub("_", " ", nm)
  setnames(s, nm)
  s[]
}


# -----------------------------------------------------------------------------
# 4. BED export
# -----------------------------------------------------------------------------

#' Write Significant DMRs as a BED File
#'
#' Writes a valid BED4 (tab-separated, no header, 0-based half-open). Positions in
#' sounDMR come from methyl-bed column 2 (0-based start), so by default
#' start = `Genome_Low` and end = `Genome_High + 1`.
#'
#' @param dmrs (data.table) - combined DMR table
#' @param file (str) - output path
#' @param score_col (str) - score included in the feature name
#' @param positions_0based (bool) - set FALSE if `Position` is 1-based
#' @return (data.table) - the BED table, invisibly
#' @export
write_dmr_bed <- function(dmrs, file, score_col = "adjusted_soundscore",
                          positions_0based = TRUE) {
  dt <- as.data.table(dmrs)
  multi_gene <- dt[, uniqueN(Gene) > 1]
  label <- if (multi_gene) paste(dt$Treatment, dt$Gene, dt$CX, sep = "_") else
    paste(dt$Treatment, dt$CX, sep = "_")
  bed <- data.table(
    chrom = dt$Chr,
    start = if (positions_0based) dt$Genome_Low else dt$Genome_Low - 1L,
    end   = if (positions_0based) dt$Genome_High + 1L else dt$Genome_High,
    name  = paste(label, round(dt[[score_col]], 2), sep = "_")
  )
  setorderv(bed, c("chrom", "start"))
  fwrite(bed, file, sep = "\t", col.names = FALSE, quote = FALSE)
  invisible(bed)
}


# -----------------------------------------------------------------------------
# 5. Figures
# -----------------------------------------------------------------------------

#' @noRd
theme_dmr <- function() {
  theme_minimal(base_size = 11) +
    theme(plot.background = element_rect(fill = "white", colour = NA)) +
    theme(panel.grid.minor = element_blank(),
          panel.grid.major.x = element_blank(),
          plot.title = element_text(face = "bold", size = 11),
          plot.subtitle = element_text(colour = "grey35", size = 9),
          axis.text = element_text(colour = "grey30"),
          strip.text = element_text(face = "bold"))
}

#' Plot Methylation in One DMR Across Treatment Groups
#'
#' Boxes are per-cytosine group means; dots are each plant's mean over the DMR.
#' The DMR's own treatment is blue, the control grey, and its off-target
#' treatments (the `Off_Targets` column added by `add_target_stats()`) orange.
#' Replaces `cpt_compare()` / `treatment_plots()`.
#'
#' @param dmr_id (str) - a `DMR_ID` from the combined table
#' @param cyto (data.table) - output of `dmr_cytosine_data()`
#' @param dmrs (data.table) - combined DMR table
#' @param control (str) - control level
#' @param treatment_levels (chr) *optional* - x-axis order
#' @return ggplot object
#' @import ggplot2
#' @export
plot_dmr_methylation <- function(dmr_id, cyto, dmrs, control, treatment_levels = NULL) {
  d <- cyto[DMR_ID == dmr_id]
  info <- as.data.table(dmrs)[DMR_ID == dmr_id][1]
  if (is.null(treatment_levels)) {
    treatment_levels <- c(control, sort(setdiff(unique(d$Treatment), control)))
  }
  d[, Treatment := factor(Treatment, levels = treatment_levels)]
  per_cyt   <- d[, .(Percent = mean(Percent, na.rm = TRUE)), by = .(Treatment, Position)]
  per_plant <- d[, .(Percent = mean(Percent, na.rm = TRUE)), by = .(Treatment, Plant)]
  off_trts <- if ("Off_Targets" %in% names(info) && !is.na(info$Off_Targets)) {
    strsplit(info$Off_Targets, "; ", fixed = TRUE)[[1]]
  } else character(0)
  role_levels <- c("Target treatment", "Control", "Off-target treatments", "Other treatments")
  role <- function(t) factor(ifelse(t == info$Treatment, role_levels[1],
                             ifelse(t == control, role_levels[2],
                             ifelse(t %in% off_trts, role_levels[3], role_levels[4]))),
                             levels = role_levels)
  per_cyt[, Role := role(Treatment)]
  per_plant[, Role := role(Treatment)]
  fills <- stats::setNames(c("#2a78d6", "#8c8c8c", "#f2a07b", "#e3e3e3"), role_levels)

  ggplot(per_cyt, aes(Treatment, Percent)) +
    geom_boxplot(aes(fill = Role), outlier.shape = NA, width = 0.6,
                 colour = "grey30", linewidth = 0.3, na.rm = TRUE) +
    geom_point(data = per_plant, size = 2.2, shape = 21, fill = "white",
               colour = "grey15", stroke = 0.6, na.rm = TRUE) +
    scale_fill_manual(values = fills, drop = TRUE, name = NULL) +
    scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.02))) +
    labs(title = paste0(info$Treatment, "  ", info$cp_group),
         subtitle = sprintf("%s  %s:%s-%s  |  %d cytosines  |  adj. score %.2f  |  box = per-cytosine group mean, dots = per-plant mean",
                            info$CX, info$Chr, format(info$Genome_Low, big.mark = ","),
                            format(info$Genome_High, big.mark = ","), info$Count,
                            info$adjusted_soundscore),
         x = NULL, y = "% methylation") +
    theme_dmr() +
    theme(legend.position = "bottom")
}

#' Map of Significant DMRs Relative to the Target
#'
#' One panel per gene x context; line = DMR extent, point size = score; dashed
#' line at position 0.
#'
#' @param dmrs (data.table) - combined DMR table
#' @param score_col (str) - score used for point size
#' @param treatment_levels (chr) *optional* - y-axis order
#' @return ggplot object
#' @export
plot_dmr_map <- function(dmrs, score_col = "adjusted_soundscore",
                         treatment_levels = NULL) {
  d <- copy(as.data.table(dmrs))
  d[, score := get(score_col)]
  d[, Mid := (Start + Stop) / 2]
  if (is.null(treatment_levels)) treatment_levels <- sort(unique(d$Treatment))
  d[, Treatment := factor(Treatment, levels = rev(treatment_levels))]
  d[, CX := factor(CX, levels = CX_LEVELS)]

  ggplot(d, aes(y = Treatment, colour = CX)) +
    geom_vline(xintercept = 0, colour = "grey60", linetype = "dashed", linewidth = 0.4) +
    geom_segment(aes(x = Start, xend = Stop, yend = Treatment), linewidth = 2,
                 lineend = "round", alpha = 0.6) +
    geom_point(aes(x = Mid, size = score), alpha = 0.9) +
    scale_colour_manual(values = CX_COLORS, drop = FALSE, guide = "none") +
    scale_size_area(max_size = 6, name = "Adj. score") +
    facet_grid(CX ~ Gene, scales = "free_x", drop = FALSE) +
    labs(x = "Position relative to target (bp)", y = NULL,
         title = "Significant DMRs by treatment") +
    theme_dmr() +
    theme(panel.grid.major.y = element_line(colour = "grey92"),
          panel.border = element_rect(fill = NA, colour = "grey85"))
}

#' Bar Chart of Summed DMR Score (or Methylation Effect) per Treatment
#'
#' Stacked bars by context of the summed adjusted score (`measure = "score"`) or the
#' methylation effect in cytosine-equivalents (`measure = "meth_effect"`) of the
#' significant DMRs. If the summary carries bootstrap results
#' (`run_dmr_downstream(..., boots = )`), each bar also shows the background: the mean
#' (solid tick) and 95th percentile (dashed tick) of the same total in random same-width
#' windows in other genes, and the label adds the excess (bar minus background mean) and,
#' for the score, the p-value of the total.
#'
#' @param summ (data.table) - output of `summarise_dmrs()` (optionally with bootstrap
#' columns added by `run_dmr_downstream()`)
#' @param by (chr) - the grouping used to build `summ`
#' @param measure (str) - "score" or "meth_effect"
#' @return ggplot object
#' @export
plot_score_summary <- function(summ, by = "Treatment", measure = c("score", "meth_effect")) {
  measure <- match.arg(measure)
  s <- copy(as.data.table(summ))
  m <- if (measure == "score") list(cx = "Score_", tot = "Total_Score", bg = "Bg_Mean_Total_Score",
                                    q95 = "Bg_95pct_Total_Score", ex = "Excess_Total_Score",
                                    p = "P_Total_Score", y = "Summed adjusted score",
                                    title = "DMR score by treatment", what = "summed adjusted score")
       else list(cx = "Meth_Effect_", tot = "Total_Meth_Effect", bg = "Bg_Mean_Meth_Effect",
                 q95 = "Bg_95pct_Meth_Effect", ex = "Excess_Meth_Effect", p = NA,
                 y = "Methylation effect (cytosine-equivalents)",
                 title = "Methylation effect by treatment",
                 what = "weight x cytosines x mean change / 100")
  if (!all(paste0(m$cx, CX_LEVELS) %in% names(s))) stop("summary has no ", m$cx, "<CX> columns")
  long <- data.table::melt(s, id.vars = by, measure.vars = paste0(m$cx, CX_LEVELS),
                           variable.name = "CX", value.name = "Score")
  long[, CX := factor(sub(m$cx, "", CX, fixed = TRUE), levels = rev(CX_LEVELS))]
  has_boot <- all(c(m$bg, m$ex) %in% names(s)) && any(!is.na(s[[m$bg]]))
  tot <- s[, c(by, "Total_DMRs"), with = FALSE]
  tot[, Tot := s[[m$tot]]]
  if (length(by) > 1) {
    long[, Label := do.call(paste, c(.SD, sep = "\n")), .SDcols = by]
    tot[, Label := do.call(paste, c(.SD, sep = "\n")), .SDcols = by]
  } else {
    long[, Label := get(by)]
    tot[, Label := get(by)]
  }
  tot[, txt := sprintf("%.1f  (%d DMRs)", Tot, Total_DMRs)]
  if (has_boot) {
    tot[, `:=`(Bg = s[[m$bg]], Q95 = if (m$q95 %in% names(s)) s[[m$q95]] else NA_real_, Ex = s[[m$ex]],
               P = if (!is.na(m$p) && m$p %in% names(s)) s[[m$p]] else NA_real_)]
    tot[!is.na(Ex), txt := paste0(txt, sprintf("\nexcess %.1f", Ex),
        ifelse(is.na(P), "", paste0(", p = ", format(P, digits = 2))))]
    tot[, top := pmax(Tot, Q95, Bg, na.rm = TRUE)]
  } else tot[, top := Tot]

  p <- ggplot(long, aes(Label, Score)) +
    geom_col(aes(fill = CX), width = 0.65, colour = "white", linewidth = 0.5) +
    scale_fill_manual(values = CX_COLORS, breaks = CX_LEVELS, name = "Context")
  if (has_boot) {
    bg <- rbind(tot[!is.na(Bg), .(Label, y = Bg, What = "Background mean")],
                tot[!is.na(Q95), .(Label, y = Q95, What = "Background 95th percentile")])
    bg[, What := factor(What, levels = c("Background mean", "Background 95th percentile"))]
    p <- p + geom_errorbar(data = bg, aes(Label, ymin = y, ymax = y, linetype = What),
                           inherit.aes = FALSE, width = 0.85, linewidth = 0.6, colour = "grey15") +
      scale_linetype_manual(values = c("Background mean" = "solid",
                                       "Background 95th percentile" = "22"), name = NULL)
  }
  p + geom_text(data = tot, aes(Label, top, label = txt), inherit.aes = FALSE,
                vjust = -0.4, size = 3, colour = "grey25", lineheight = 0.9) +
    scale_y_continuous(expand = expansion(mult = c(0, if (has_boot) 0.2 else 0.12))) +
    labs(x = NULL, y = m$y, title = m$title,
         subtitle = if (has_boot) paste0("Bars = ", m$what, " of significant DMRs.\n",
           "Ticks = the same total in random same-width windows in other genes.\n",
           "Excess = bar - background mean",
           if (!is.na(m$p)) "; p = share of windows with a total at least as high." else ".")) +
    theme_dmr() +
    theme(legend.position = "right")
}


#' Evidence Plot: -log10 Bootstrap p per Treatment
#'
#' Lollipop plot of bootstrap p-values (as -log10 p) for chosen tests, one group per
#' treatment (x gene). The y-axis follows the data; the p = 0.05 line is always shown,
#' p = 0.01 only when reached; p-values at the bootstrap limit (1 / (Bootstrap_Windows + 1))
#' are labelled "<=".
#'
#' @param summ (data.table) - `_summary` / `_summary_by_gene` from `run_dmr_downstream()`
#' (with `boots`)
#' @param by (chr) - grouping columns of `summ`
#' @param tests (named chr) - p-value column -> legend label
#' @param colours,shapes (named) - per legend label
#' @param title,subtitle (str)
#' @return ggplot object
#' @export
plot_evidence <- function(summ, by, tests, colours, shapes, title = NULL, subtitle = NULL) {
  s <- copy(as.data.table(summ))
  s[, Label := do.call(paste, c(.SD, sep = "\n")), .SDcols = by]
  s[, Label := factor(Label, levels = unique(Label))]
  tests <- tests[names(tests) %in% names(s)]
  long <- rbindlist(lapply(names(tests), function(cl) s[, .(Label, Test = tests[[cl]], p = get(cl))]))
  long <- long[!is.na(p)]
  if (!nrow(long)) stop("No p-values to plot - pass boots to run_dmr_downstream()")
  long[, Test := factor(Test, levels = unname(tests))]
  long[, y := -log10(p)]
  floor_p <- if ("Bootstrap_Windows" %in% names(s)) 1 / (max(s$Bootstrap_Windows, na.rm = TRUE) + 1) else NA_real_
  at_floor <- !is.na(floor_p) & long$p <= floor_p * 1.0001
  long[, lab := ifelse(at_floor, paste0("<=", format(p, digits = 2)), format(p, digits = 2))]
  top <- max(c(long$y, -log10(0.05) * 1.1), na.rm = TRUE)
  ref <- data.table(y = -log10(c(0.05, 0.01)), lab = c("p = 0.05", "p = 0.01"), lt = c("dashed", "dotted"))
  ref <- ref[y <= top * 1.02]
  dodge <- position_dodge(width = 0.12 * length(tests) + 0.2)
  ggplot(long, aes(Label, y, colour = Test, shape = Test)) +
    geom_hline(data = ref, aes(yintercept = y), linetype = ref$lt, colour = "grey55", linewidth = 0.4) +
    geom_text(data = ref, aes(x = Inf, y = y, label = lab), inherit.aes = FALSE,
              hjust = 1.05, vjust = -0.4, size = 2.8, colour = "grey45") +
    geom_linerange(aes(ymin = 0, ymax = y), position = dodge, linewidth = 0.6, show.legend = FALSE) +
    geom_point(position = dodge, size = 3.2) +
    geom_text(aes(label = lab), position = dodge, vjust = -1.1, size = 2.6, show.legend = FALSE) +
    scale_colour_manual(values = colours, name = NULL) +
    scale_shape_manual(values = shapes, name = NULL) +
    scale_y_continuous(limits = c(0, NA), expand = expansion(mult = c(0, 0.15))) +
    labs(x = NULL, y = expression(-log[10]~bootstrap~p), title = title,
         subtitle = paste0(subtitle, if (any(at_floor))
           paste0("\n<= marks the smallest p the bootstrap can give (", format(floor_p, digits = 2), ").") else "")) +
    theme_dmr() +
    theme(panel.grid.major.x = element_blank(), legend.position = "top", legend.justification = "left",
          plot.subtitle = element_text(colour = "grey35", size = 8.5))
}

#' Evidence Plot: Total Score vs. Strong DMRs
#'
#' Page 1 of `_dmr_evidence.pdf`: the total-score test (rewards many DMRs) and the
#' strong-DMR test (dominated by the 1-2 rarest DMRs) per treatment. Both significant:
#' clear effect with a standout DMR; total only: spread-out effect of many moderate DMRs;
#' strong only: one or two sharp DMRs.
#' @inheritParams plot_evidence
#' @return ggplot object
#' @export
plot_dmr_evidence <- function(summ, by = "Treatment") {
  tests <- c(P_Total_Score = "Total score (many DMRs)", P_Strong_DMRs = "Strong DMRs (harmonic mean)")
  plot_evidence(summ, by, tests,
                colours = stats::setNames(c("#3d3d3d", "#c2185b"), tests), shapes = stats::setNames(c(16, 17), tests),
                title = "Evidence for DMRs at the target, by treatment",
                subtitle = paste0("Both tests vs. random same-width windows in other genes. Total score: summed score of DMRs\n",
                                  "above the cutoff. Strong DMRs: dominated by the 1-2 rarest DMRs."))
}

#' Evidence Plot: Best DMR per Context
#'
#' Page 2 of `_dmr_evidence.pdf`: best DMR in each context (no cutoff - the strongest
#' region near the target, however weak) and CG + CHG combined, per treatment. A p of 1
#' means no region near the target scored above 0 in that context.
#' @inheritParams plot_evidence
#' @return ggplot object
#' @export
plot_context_evidence <- function(summ, by = "Treatment") {
  tests <- c(P_Best_DMR_CG = "Best CG DMR", P_Best_DMR_CHG = "Best CHG DMR", P_Best_DMR_CHH = "Best CHH DMR",
             P_Best_DMRs_CG_CHG = "CG + CHG combined")
  plot_evidence(summ, by, tests,
                colours = stats::setNames(c(unname(CX_COLORS[c("CG", "CHG", "CHH")]), "#3d3d3d"), tests),
                shapes = stats::setNames(c(16, 16, 16, 18), tests),
                title = "Best DMR in each context, by treatment",
                subtitle = paste0("Strongest distance-weighted region near the target (no cutoff) vs. the best in random\n",
                                  "same-width windows. CG + CHG combined: Fisher combination, calibrated on the same windows."))
}


# -----------------------------------------------------------------------------
# 6. One-call wrapper
# -----------------------------------------------------------------------------

#' Run the Downstream DMR Summary Pipeline
#'
#' Combines significant-DMR tables, adds per-treatment methylation and read depth
#' for every DMR, builds summary tables, and writes CSVs, a BED file and figures.
#' Supersedes the manual combine / `datasummary()` / `DMR_Info()` /
#' `treatment_plots()` steps.
#'
#' Files written to `out_dir`, each starting with `prefix`:
#' \itemize{
#'   \item `_sig_table_mapping.csv` - which sig table -> treatment -> gene(s)
#'   \item `_dmrs.csv` - one row per DMR, with target / control (/ off-target) read
#'   depth and \% methylation
#'   \item `_dmr_group_stats.csv` - one row per DMR x treatment group
#'   \item `_summary.csv` - per-treatment summary
#'   \item `_summary_by_gene.csv` - per-treatment x gene summary
#'   \item `_summary_brief.csv`, `_dmrs_brief.csv` - compact versions for sharing
#'   (`brief_summary()`, `brief_dmrs()`)
#'   \item `_bootstrap.csv` - bootstrap results per treatment x gene (if `boots` given)
#'   \item `_dmr_evidence.pdf` - evidence plots (if `boots` given): total score vs. strong
#'   DMRs, and best DMR per context (`plot_dmr_evidence()`, `plot_context_evidence()`)
#'   \item `_dmrs.bed` - BED4 of significant DMRs
#'   \item `_score_summary.pdf`, `_dmr_map.pdf`, `_dmr_methylation.pdf` (one page per DMR)
#' }
#'
#' @param sig_list (named list of df) - significant DMR tables, see `combine_sig_dmrs()`
#' @param dmr_obj (list) - output of `create_dmr_obj()`
#' @param control (str) - control level of `target_variable` in `dmr_obj$LongPercent`
#' @param out_dir (str) - output directory (created if needed)
#' @param prefix (str) - file name prefix, e.g. the experiment ID
#' @param treatments (chr) *optional* - treatment for each element of `sig_list`
#' @param design (df) *optional* - annotation merged into the summaries, see
#' `summarise_dmrs()`
#' @param off_targets (named list) *optional* - for each treatment, the treatments
#' that targeted a different gene (off-target baseline), e.g.
#' `list(T2 = c("T5", "T6", "T7"))`. Adds off-target % methylation and
#' difference columns to `_dmrs.csv`, plus `Off_Target_Fraction` and
#' `Off_Target_Adjusted_Score` (see `add_off_target_scores()`), and colours the
#' off-target treatments in the methylation plots.
#' See `add_target_stats()`.
#' @param boots (named list) *optional* - the `boot_score()` results, named like the
#' sig tables without `_sig` (e.g. `dmr_boots` from the example workflows, or
#' `mget(ls(pattern = "^DMR_boot_[^_]+$"))`). Adds the bootstrap results to the
#' summaries (total-of-DMRs p, z, background and excess; methylation-effect background
#' and excess; best-DMR p-values per context - see `boot_results_table()`) and
#' background markers to the summary figures; also written as `_bootstrap.csv`. Run `boot_overall(boot, cutoff)` first if the significance
#' cutoff changed after `boot_score()`. See `boot_results_table()`.
#' @param target_variable (str) - the fixed effect used in `find_DMR()`
#' @param score_col (str) - DMR score column
#' @param positions_0based (bool) - see `write_dmr_bed()`
#' @param make_plots (bool) - write the PDF figures
#' @param per_dmr_pdfs (bool) - also write one PDF per DMR
#' @return (list), invisibly: `mapping`, `dmrs`, `group_stats`, `cytosines`,
#' `summary`, `summary_by_gene`
#' @examples
#' # sig_list <- mget(ls(pattern = "^DMR_boot_.*_sig$"))
#' # res <- run_dmr_downstream(sig_list, dmr_obj, control = "Water",
#' #                           out_dir = "db210_downstream", prefix = "db210")
#' @export
run_dmr_downstream <- function(sig_list, dmr_obj, control, out_dir = ".", prefix = "dmr",
                               treatments = NULL, design = NULL, off_targets = NULL,
                               boots = NULL, target_variable = "Treatment",
                               score_col = "adjusted_soundscore",
                               positions_0based = TRUE, make_plots = TRUE,
                               per_dmr_pdfs = FALSE) {
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  f <- function(x) file.path(out_dir, paste0(prefix, x))

  message("Combining sig-DMR tables")
  dmrs <- combine_sig_dmrs(sig_list, treatments, target_variable)
  all_trt <- attr(dmrs, "treatments")
  mapping <- attr(dmrs, "mapping")
  pairs   <- attr(dmrs, "pairs")

  message("Extracting per-cytosine data for ", nrow(dmrs), " DMRs")
  lp <- dmr_obj$LongPercent
  if (!target_variable %in% names(lp)) {
    # e.g. a grouping column added to the design after create_dmr_obj(): take it from the design
    ed <- dmr_obj$experimental_design_df
    if (!is.null(ed) && all(c(target_variable, "ID") %in% names(ed)) && "Individual" %in% names(lp)) {
      lp[[target_variable]] <- ed[[target_variable]][match(lp$Individual, ed$ID)]
      message("Taking '", target_variable, "' from dmr_obj$experimental_design_df (not in LongPercent).")
    }
  }
  cyto  <- dmr_cytosine_data(dmrs, lp, treatment_col = target_variable)
  stats <- dmr_group_stats(cyto)
  dmrs  <- add_target_stats(dmrs, stats, control, off_targets)
  dmrs  <- add_off_target_scores(dmrs, score_col)   # no-op when no off-targets
  setattr(dmrs, "treatments", all_trt)
  setattr(dmrs, "mapping", mapping)

  message("Building summaries")
  summ_trt  <- summarise_dmrs(dmrs, by = "Treatment", score_col = score_col,
                              treatments = all_trt, design = design)
  summ_gene <- summarise_dmrs(dmrs, by = c("Treatment", "Gene"), score_col = score_col,
                              treatments = NULL, design = design, required_keys = pairs)
  boot_tab <- boot_results_table(boots, mapping)
  summ_trt  <- add_boot_results(summ_trt, boot_tab, "Treatment")
  summ_gene <- add_boot_results(summ_gene, boot_tab, c("Treatment", "Gene"))
  if (!is.null(boot_tab)) {
    fwrite(boot_tab, f("_bootstrap.csv"))
    # rarity of each DMR against its own treatment x gene background
    dmrs[, DMR_Rarity := NA_real_]
    for (k in seq_len(nrow(mapping))) {
      b <- boots[[sub("_sig$", "", mapping$Source[k])]]
      if (is.null(b)) next
      hit <- dmrs$Source == mapping$Source[k]
      sc <- if ("adjusted_soundscore" %in% names(dmrs)) "adjusted_soundscore" else score_col
      if (any(hit)) dmrs[hit, DMR_Rarity := signif(region_rarity(get(sc), b), 3)]
    }
  }

  fwrite(mapping, f("_sig_table_mapping.csv"))
  fwrite(dmrs, f("_dmrs.csv"))
  fwrite(brief_dmrs(dmrs, score_col), f("_dmrs_brief.csv"))
  fwrite(stats, f("_dmr_group_stats.csv"))
  fwrite(prettify_summary(summ_trt), f("_summary.csv"))
  fwrite(prettify_summary(summ_gene), f("_summary_by_gene.csv"))
  # compact tables for sharing: per treatment x gene if a treatment hit several genes
  fwrite(brief_summary(if (nrow(summ_gene) > nrow(summ_trt)) summ_gene else summ_trt), f("_summary_brief.csv"))
  write_dmr_bed(dmrs, f("_dmrs.bed"), score_col, positions_0based)

  if (make_plots) {
    message("Drawing figures")
    n_genes <- uniqueN(dmrs$Gene)
    by_gene <- nrow(summ_gene) > nrow(summ_trt)      # a treatment hit several genes
    ss <- if (by_gene) summ_gene else summ_trt
    ss_by <- if (by_gene) c("Treatment", "Gene") else "Treatment"
    ss_w <- max(6.5, 1.1 * nrow(ss) + 3.5)
    ggsave(f("_score_summary.pdf"), plot_score_summary(ss, by = ss_by), width = ss_w, height = 5)
    if (!is.null(boot_tab) && "P_Strong_DMRs" %in% names(ss)) {
      grDevices::pdf(f("_dmr_evidence.pdf"), width = max(6.5, 1.1 * nrow(ss) + 4), height = 4.8)
      print(plot_dmr_evidence(ss, by = ss_by)); print(plot_context_evidence(ss, by = ss_by))
      grDevices::dev.off()
    }
    ggsave(f("_dmr_map.pdf"), plot_dmr_map(dmrs, score_col),
           width = max(7, 4 * n_genes + 2), height = 2 + 0.35 * length(all_trt) * 3)

    trt_levels <- c(control, sort(setdiff(unique(cyto$Treatment), control)))
    ord <- dmrs[order(Treatment, Gene, CX, Start), DMR_ID]
    grDevices::pdf(f("_dmr_methylation.pdf"), width = 8, height = 4.5)
    for (id in ord) print(plot_dmr_methylation(id, cyto, dmrs, control, trt_levels))
    grDevices::dev.off()
    if (per_dmr_pdfs) {
      for (id in ord) {
        ggsave(f(paste0("_", gsub("[|:]", "_", id), ".pdf")),
               plot_dmr_methylation(id, cyto, dmrs, control, trt_levels),
               width = 8, height = 4.5)
      }
    }
  }

  message("Done: outputs in ", normalizePath(out_dir))
  invisible(list(mapping = mapping, dmrs = dmrs, group_stats = stats, cytosines = cyto,
                 summary = summ_trt, summary_by_gene = summ_gene))
}


# -----------------------------------------------------------------------------
# 7. Gains and losses together (direction = "all" in the example workflows)
# -----------------------------------------------------------------------------

#' Rerun a boot_score() Result in Another Direction
#'
#' Calls `boot_score()` again with the same settings (target gene and window, score
#' column, background exclusions, number of bootstraps, cutoff) but another
#' `direction_DMR`, e.g. to score losses of methylation next to gains.
#'
#' @param boot (list) - a `boot_score()` result
#' @param sound_score_obj (list) - the `sound_score()` result `boot` was made from
#' @param direction (str) - "positive", "negative" or "absolute"
#' @param verbose,make_plot (bool) - passed to `boot_score()`
#' @return a `boot_score()` result
#' @export
boot_score_direction <- function(boot, sound_score_obj, direction = "negative", verbose = TRUE, make_plot = FALSE) {
  st <- boot$settings
  args <- list(sound_score_obj = sound_score_obj, target_gene = st$target_gene,
               target_start = st$target_start, target_end = st$target_end, nboots = st$nboots,
               scoring_col_name = st$scoring_col_name, direction_DMR = direction,
               exclude_genes = st$exclude_genes, overall_cutoff = st$overall_cutoff,
               verbose = verbose, make_plot = make_plot)
  if (!is.null(st$change_col) && !is.na(st$change_col)) args$change_col <- st$change_col
  do.call(boot_score, args)
}

#' Gain / Loss Bar Chart
#'
#' Summed distance-weighted score of the significant DMRs per treatment (x gene), by
#' context: gains of methylation as bars going up, losses going down. Each direction
#' has its own background ticks (mean = solid, 95th percentile = dashed) and is labelled
#' with its total, number of DMRs and total-score p.
#'
#' @param boots,boots_neg (named lists) - `boot_score()` results scored "positive" and
#' "negative", with the same names
#' @param mapping (data.table) - `res$mapping` (sig table -> treatment)
#' @return ggplot object
#' @export
plot_gain_loss <- function(boots, boots_neg, mapping) {
  map <- as.data.table(mapping)
  keys <- sub("_sig$", "", map$Source)
  rows <- rbindlist(lapply(seq_along(keys), function(i) {
    rbindlist(lapply(c("Gain", "Loss"), function(dir) {
      b <- (if (dir == "Gain") boots else boots_neg)[[keys[i]]]
      if (is.null(b)) return(NULL)
      cut <- b$settings$overall_cutoff
      r <- as.data.table(b$target_rs)[!is.na(adjusted_soundscore) & adjusted_soundscore > cut]
      o <- as.data.table(b$summary)[Context == "Overall"]
      sc <- r[, .(Score = sum(adjusted_soundscore)), by = CX]
      sc <- merge(data.table(CX = CX_LEVELS), sc, by = "CX", all.x = TRUE)[is.na(Score), Score := 0]
      sc[, `:=`(Treatment = map$Treatment[i], Gene = b$settings$target_gene, Dir = dir,
                Total = o$Target_Score, N = o$N_Regions, Bg = o$Background_Mean,
                Q95 = o$Background_95pct, P = o$P_Value)]
    }))
  }))
  if (!nrow(rows)) stop("No boot objects matched the mapping")
  multi <- rows[, uniqueN(Gene), by = Treatment][, any(V1 > 1)]
  rows[, Label := if (multi) paste(Treatment, Gene, sep = "\n") else Treatment]
  rows[, Label := factor(Label, levels = unique(Label))]
  rows[, sgn := ifelse(Dir == "Gain", 1, -1)]
  rows[, CX := factor(CX, levels = rev(CX_LEVELS))]
  tot <- unique(rows[, .(Label, Dir, sgn, Total, N, Bg, Q95, P)])
  tot[, txt := sprintf("%.1f (%d)\np = %s", Total, N, format(P, digits = 2))]
  tot[, ypos := sgn * pmax(Total, Q95, Bg, na.rm = TRUE)]
  ticks <- rbind(tot[, .(Label, y = sgn * Bg, What = "Background mean")],
                 tot[, .(Label, y = sgn * Q95, What = "Background 95th percentile")])
  ticks[, What := factor(What, levels = c("Background mean", "Background 95th percentile"))]
  lim <- max(abs(tot$ypos), na.rm = TRUE) * 1.3
  ggplot(rows, aes(Label, sgn * Score)) +
    geom_col(aes(fill = CX, alpha = Dir), width = 0.65, colour = "white", linewidth = 0.4) +
    geom_hline(yintercept = 0, colour = "grey30", linewidth = 0.4) +
    geom_errorbar(data = ticks, aes(Label, ymin = y, ymax = y, linetype = What), inherit.aes = FALSE,
                  width = 0.85, linewidth = 0.55, colour = "grey15") +
    geom_text(data = tot, aes(Label, ypos, label = txt, vjust = ifelse(sgn > 0, -0.25, 1.15)),
              inherit.aes = FALSE, size = 2.8, colour = "grey25", lineheight = 0.9) +
    annotate("text", x = 0.45, y = c(lim, -lim) * 0.95, label = c("Gain of methylation", "Loss of methylation"),
             hjust = 0, vjust = c(1, 0), size = 3, fontface = "bold", colour = "grey35") +
    scale_fill_manual(values = CX_COLORS, breaks = CX_LEVELS, name = "Context") +
    scale_alpha_manual(values = c(Gain = 1, Loss = 0.6), guide = "none") +
    scale_linetype_manual(values = c("Background mean" = "solid", "Background 95th percentile" = "22"), name = NULL) +
    scale_y_continuous(limits = c(-lim, lim), labels = abs) +
    labs(x = NULL, y = "Summed adjusted score", title = "DMR score by treatment: gains and losses",
         subtitle = paste0("Bars = summed adjusted score of significant DMRs (n in brackets); up = gain, down = loss.\n",
                           "Ticks = the same total in random same-width windows; p = total-score test per direction.")) +
    theme_dmr() + theme(legend.position = "right", plot.subtitle = element_text(colour = "grey35", size = 8.5))
}

#' Add Loss-of-Methylation Results to a run_dmr_downstream() Result
#'
#' For `direction = "all"` in the example workflows: the main outputs stay the gains of
#' methylation (`res`, scored "positive"), and the losses (`boots_neg`, scored "negative")
#' are added:
#' \itemize{
#'   \item the full downstream outputs for the losses in `<out_dir>/negative/`
#'   (`<prefix>_negative_*`), including their bootstrap summary and plots
#'   \item loss columns in the main `_summary.csv`, `_summary_by_gene.csv` and
#'   `_summary_brief.csv`: `Loss_DMRs`, `Loss_Total_Score`, `Loss_Excess_Total_Score`,
#'   `Loss_P_Total_Score`, `Loss_Evidence_Total_Score`, `Loss_P_Strong_DMRs`,
#'   `Loss_Excess_Meth_Effect`
#'   \item `_score_summary_gain_loss.pdf` (`plot_gain_loss()`)
#' }
#' Losses use the same cutoff as the gains of the same treatment (`overall_cutoff` of the
#' positive boot object, as set by `boot_overall()` in step 4.0).
#'
#' @param res - `run_dmr_downstream()` result for the gains
#' @param boots,boots_neg (named lists) - positive and negative `boot_score()` results,
#' same names (see `boot_score_direction()`)
#' @param dmr_obj,control,off_targets,target_variable,design - as for `run_dmr_downstream()`
#' @param out_dir,prefix - as used for `res`
#' @param make_plots (bool) - figures for the losses as well
#' @return `res` with loss columns in `summary` / `summary_by_gene`, `negative` (the
#' downstream result for the losses, or NULL if there are none) and `boots_negative` (the
#' negative boot objects at the gains' cutoffs)
#' @export
add_loss_direction <- function(res, boots, boots_neg, dmr_obj, control, out_dir = ".", prefix = "dmr",
                               off_targets = NULL, target_variable = "Treatment", design = NULL,
                               make_plots = TRUE) {
  map <- as.data.table(res$mapping)
  keys <- sub("_sig$", "", map$Source)
  keys <- keys[keys %in% names(boots_neg)]
  # same cutoff as the gains of that treatment
  for (k in keys) {
    cut <- boots[[k]]$settings$overall_cutoff
    if (!identical(boots_neg[[k]]$settings$overall_cutoff, cut)) boots_neg[[k]] <- boot_overall(boots_neg[[k]], cut)
  }
  sig_neg <- lapply(keys, function(k) get_sig_dmrs(boots_neg[[k]], min_score = boots_neg[[k]]$settings$overall_cutoff))
  names(sig_neg) <- paste0(keys, "_sig")
  trts <- map$Treatment[match(names(sig_neg), map$Source)]
  neg_dir <- file.path(out_dir, "negative"); neg_prefix <- paste0(prefix, "_negative")
  n_neg <- sum(vapply(sig_neg, nrow, integer(1)))
  res_neg <- NULL
  if (n_neg > 0) {
    res_neg <- run_dmr_downstream(sig_neg, dmr_obj, control = control, out_dir = neg_dir, prefix = neg_prefix,
                                  treatments = trts, design = design, off_targets = off_targets,
                                  boots = boots_neg[keys], target_variable = target_variable, make_plots = make_plots)
  } else message("No loss-of-methylation DMRs above the cutoff - only the loss columns are added.")
  dir.create(neg_dir, showWarnings = FALSE, recursive = TRUE)
  bs <- do.call(rbind, lapply(keys, function(k) cbind(Boot = k, boots_neg[[k]]$summary)))
  utils::write.csv(bs, file.path(neg_dir, paste0(neg_prefix, "_bootstrap_summary.csv")), row.names = FALSE)
  if (make_plots) {
    grDevices::pdf(file.path(neg_dir, paste0(neg_prefix, "_bootstrap_plots.pdf")), width = 7.5, height = 11)
    for (k in keys) { print(boots_neg[[k]]$plot + labs(title = paste0(k, " (loss): bootstrap")))
                      print(boots_neg[[k]]$region_plot + labs(title = paste0(k, " (loss): region scores"))) }
    grDevices::dev.off()
  }

  # loss columns for the main summaries
  bt <- boot_results_table(boots_neg[keys], map[match(paste0(keys, "_sig"), Source)])
  n_by <- data.table(Treatment = trts, Gene = vapply(keys, function(k) boots_neg[[k]]$settings$target_gene, ""),
                     Loss_DMRs = vapply(sig_neg, nrow, integer(1)))
  bt <- merge(bt, unique(n_by, by = c("Treatment", "Gene")), by = c("Treatment", "Gene"), sort = FALSE)
  loss <- bt[, .(Treatment, Gene, Loss_DMRs, Loss_Total_Score = Total_Score, Loss_Excess_Total_Score = Excess_Total_Score,
                 Loss_P_Total_Score = P_Total_Score, Loss_Evidence_Total_Score = Evidence_Total_Score,
                 Loss_P_Strong_DMRs = P_Strong_DMRs, Loss_Excess_Meth_Effect = Excess_Meth_Effect)]
  by_gene <- merge(as.data.table(res$summary_by_gene), loss, by = c("Treatment", "Gene"), all.x = TRUE, sort = FALSE)
  agg <- loss[, if (.N == 1) .SD else .(Loss_DMRs = sum(Loss_DMRs), Loss_Total_Score = sum(Loss_Total_Score),
                                       Loss_Excess_Total_Score = sum(Loss_Excess_Total_Score), Loss_P_Total_Score = NA_real_,
                                       Loss_Evidence_Total_Score = "see by-gene summary", Loss_P_Strong_DMRs = NA_real_,
                                       Loss_Excess_Meth_Effect = sum(Loss_Excess_Meth_Effect)),
              by = Treatment, .SDcols = setdiff(names(loss), c("Treatment", "Gene"))]
  by_trt <- merge(as.data.table(res$summary), agg, by = "Treatment", all.x = TRUE, sort = FALSE)
  setorder(by_gene, Treatment, Gene); setorder(by_trt, Treatment)
  res$summary <- by_trt[]; res$summary_by_gene <- by_gene[]; res$negative <- res_neg
  res$boots_negative <- boots_neg                            # at the gains' cutoffs
  f <- function(x) file.path(out_dir, paste0(prefix, x))
  fwrite(prettify_summary(by_trt), f("_summary.csv"))
  fwrite(prettify_summary(by_gene), f("_summary_by_gene.csv"))
  fwrite(brief_summary(if (nrow(by_gene) > nrow(by_trt)) by_gene else by_trt), f("_summary_brief.csv"))
  if (make_plots) {
    n_lab <- nrow(by_gene)
    ggsave(f("_score_summary_gain_loss.pdf"), plot_gain_loss(boots, boots_neg, map),
           width = max(6.5, 1.1 * n_lab + 3.5), height = 6.5)
  }
  message("Losses: ", n_neg, " DMRs -> ", neg_dir, "; loss columns added to the main summaries; wrote ",
          f("_score_summary_gain_loss.pdf"))
  invisible(res)
}
