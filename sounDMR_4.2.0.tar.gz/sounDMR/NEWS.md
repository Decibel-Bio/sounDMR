# sounDMR 4.2.0

* **Gains and losses together.** `direction <- "all"` in the example workflows (`DMR_workflow.R`,
  `DMR_workflow_multi_gene.R`, `DMR_workflow_treatment_specific_genes.R`): gains of methylation are
  the main results as before, and losses are scored with the same settings and cutoffs and added:
  * loss columns in the main `_summary.csv`, `_summary_by_gene.csv` and `_summary_brief.csv`
    (`Loss_DMRs`, `Loss_Total_Score`, `Loss_Excess_Total_Score`, `Loss_P_Total_Score`,
    `Loss_Evidence_Total_Score`, `Loss_P_Strong_DMRs`, `Loss_Excess_Meth_Effect`)
  * the full loss results (DMR tables, summaries, bootstrap summary and plots, figures) in
    `<out_dir>/negative/`
  * `_score_summary_gain_loss.pdf`: gains as bars going up, losses going down, each with its own
    background ticks and p.
* New `boot_score_direction()` (rerun a `boot_score()` result in another direction with the same
  settings), `add_loss_direction()` and `plot_gain_loss()`.

# sounDMR 4.1.2

* Example workflows `DMR_workflow.R`, `DMR_workflow_multi_gene.R` and
  `DMR_workflow_treatment_specific_genes.R` get a `direction` setting ("positive", "negative" or
  "absolute"; one for all treatments or per treatment) passed to `boot_score(direction_DMR = )`.
  Before, these scripts always scored gains of methylation, so running them after a negative
  `boot_score()` replaced it with positive results. (`DMR_workflow_stepwise.R` already had it.)
* `_bootstrap.csv`, the summaries and `_summary_brief.csv` record the `Direction` each treatment
  was scored in.

# sounDMR 4.1.1

* `run_dmr_downstream()` also writes compact tables for sharing: `_summary_brief.csv` (one row per
  treatment (x gene): DMR counts, total and excess score, total-score and strong-DMR p with evidence,
  best DMR adjusted score and rarity, best-DMR p per context, CG + CHG combined, methylation effect and its
  excess) and `_dmrs_brief.csv` (one row per DMR: location, cytosines, DMR score (`dmr_score4`),
  distance-adjusted score, off-target adjusted score, rarity, mean Z, observed
  % methylation in target / control / off-target, change, read depth). New `brief_summary()`,
  `brief_dmrs()`.

# sounDMR 4.1.0

* **Strong-DMR test** (`strong_dmr_tests()`, `region_rarity()`): each target-gene region gets a rarity
  (share of background-window regions scoring at least as high) and the window statistic is the sum of
  1 / rarity (harmonic-mean p), compared with every background window. Dominated by the 1-2 rarest DMRs,
  so - unlike the total-score test - many weak DMRs add little. Summaries gain `P_Strong_DMRs`,
  `Evidence_Strong_DMRs`, `Best_DMR_Score`, `Best_DMR_Rarity` and `Bootstrap_Windows`; `_dmrs.csv` gains
  `DMR_Rarity`.
* **CG + CHG combined** best-DMR test (`P_Best_DMRs_CG_CHG`): Fisher combination of the CG and CHG
  best-DMR p-values, calibrated on the background windows.
* `run_dmr_downstream(boots = )` writes `_dmr_evidence.pdf`: page 1 total score vs. strong DMRs, page 2
  best DMR per context and CG + CHG combined, as -log10 p per treatment (`plot_dmr_evidence()`,
  `plot_context_evidence()`, `plot_evidence()`). Replaces the test add-on script `dmr_evidence_addon.R`.

# sounDMR 4.0.3

* **Fix:** `find_DMR()` paired `methyl_summary` row i with `dmr_obj$ZoomFrame_filtered` row i by
  position. Run on a `methyl_summary` in another row order (e.g. after `changepoint_analysis()`,
  which groups rows by context), each model was fitted on one cytosine and saved to another. It now
  matches rows by Chromosome, Gene, Position, Strand and CX (new `align_zoomframe()`), and stops if
  a cytosine is missing. Runs on a freshly created methyl summary are unchanged.
* **Fix:** `group_DMR()` replaced NAs with 0 from the last existing column onwards, not only in the
  new model columns; after changepoints that turned blank region numbers into region 0.
* `run_dmr_downstream()`: if `target_variable` is not in `dmr_obj$LongPercent` (e.g. a grouping column
  added to `dmr_obj$experimental_design_df` after `create_dmr_obj()`), it is taken from the design.

# sounDMR 4.0.2

* `changepoint_analysis(drop_zero_z = )`: leave cytosines with Z = 0 (not modelled by `find_DMR()`,
  too few reads) out of the changepoint analysis. They stay in the returned table, in their original
  order, with NA region columns, and `sound_score()` doesn't make them a region. Default FALSE (same
  results as before); the example workflows set `drop_zero_z <- TRUE`. On db210 (EAB_chr6B, T5) this
  gives 11 instead of 7 CHH regions and 58 instead of 56 CHG regions; CG is unchanged.
* `changepoint_analysis()`: cytosines with an NA Z score are now set aside before the changepoints are
  placed. Before, they were dropped inside `find_cpt_mean()` but not from the table the changepoint
  positions were applied to, so regions after an NA were shifted.
* `sound_score()`: cytosines without a region (NA MethGroup) no longer form a pseudo-region
  `<gene>_<CX>_NA`; the methyl_summary it returns still has every row.

# sounDMR 4.0.1

* `generate_methylframe()` / `generate_zoomframe()`: genes with no cytosines in their window (or whose
  chromosome is not in the bed files) are skipped with one warning listing them, instead of stopping
  with "replacement has 1 row, data has 0". It only stops if no gene has data.
* `add_zoom_coords()` used a global object named `Geneco` instead of the gene coordinates passed
  in; it now uses `gene_cord_df` (and is vectorised, so building the ZoomFrame is faster).

# sounDMR 4.0.0

Major release collecting the 3.1.x development series (the code is 3.1.9). Highlights since 2.3.2:

* **Downstream pipeline** (`run_dmr_downstream()`): combines sig-DMR tables for any design (one gene
  for all treatments, one treatment with several genes, different genes per treatment), adds
  per-treatment methylation and read depth for every DMR, and writes the summary tables, a BED file
  and figures. Replaces the manual combine / `datasummary()` / `DMR_Info()` / `treatment_plots()` steps.
* **Off-target treatments**: `<TX>_off` differences, observed off-target methylation per DMR,
  `Off_Target_Fraction` and `Off_Target_Adjusted_Score`.
* **`dmr_score4`** (default in the workflows): rewards larger regions (count exponent 0.5), with a
  signal gate (|mean Z| >= 0.175, |mean change| >= 2) and a scale (0.7) that keeps it in line with `dmr_score3`.
* **Revised `boot_score()`**: correct region-to-window distance, same-width background windows,
  p-value-based evidence, console table and plots; best-DMR tests per context, their calibrated Fisher
  combination, and a total-of-DMRs test (`Excess_Total_Score`); `boot_overall()` to recompute at a new cutoff.
* **Methylation effect** (cytosine-equivalents) and `Excess_Meth_Effect`: the measure to compare
  treatments between experiments.
* Bootstrap results merged into `_summary.csv` / `_summary_by_gene.csv`; background markers on the
  score summary figure; white figure backgrounds.
* `changepoint_analysis()` `plot_prefix` / `plot_dir` and filename-safe gene names.
* Example workflows for cases 1-3, a step-through (stepwise) version and a per-individual analysis,
  set up for db210; sessions saved as `<id>.RData` and `<id>_ms.csv`.

See the 3.1.x entries below for details.

# sounDMR 3.1.9

* `run_dmr_downstream()` no longer writes `_meth_effect_summary.pdf`; the methylation effect is in
  the summary tables only.

# sounDMR 3.1.8

* **Methylation effect**: `boot_score()` adds `meth_effect` to every target region (distance
  weight x cytosines x mean change / 100, in cytosine-equivalents; new argument `change_col`,
  found automatically). It's summed for the DMRs above the cutoff and compared with the
  background windows (`Meth_Effect`, `Bg_Mean_Meth_Effect`, `Bg_95pct_Meth_Effect`,
  `Excess_Meth_Effect`). Unlike the score it doesn't depend on read depth (beyond DMR
  selection), changepoint penalties or the scoring function, so `Excess_Meth_Effect` is the
  measure to compare between experiments. The summaries get `Meth_Effect_<CX>` and
  `Total_Meth_Effect` (`plot_score_summary(measure = "meth_effect")` can draw it; not written
  by default).
* Clearer names for the bootstrap columns in the summaries: `P_Total_Score`,
  `Evidence_Total_Score`, `Z_Total_Score`, `Bg_Mean_Total_Score`, `Bg_95pct_Total_Score`,
  `Excess_Total_Score`, `P_Best_DMR_<CX>`, `P_Best_DMRs_Combined`, `DMR_Cutoff`. The
  `boot_score()` summary has a `Test` column ("Best DMR" / "Total of DMRs > cutoff"), and
  `P_Fisher` is renamed `P_Best_DMRs_Combined`.
* The bootstrap plot gains a methylation-effect panel and clearer panel names.
* Figures (score summary, DMR map, DMR methylation, bootstrap and region plots, and the
  individual-analysis heatmap) have a white background instead of a transparent one.

# sounDMR 3.1.7

* `boot_score()` adds an **Overall** row to `summary`: the summed distance-weighted score of all
  target-gene regions above `overall_cutoff` (new argument, default 8; all contexts) compared with
  the same sum in every background window. Reports `N_Regions`, `Target_Score` (= the bar total in
  the score summary figure when the cutoffs match), background mean / SD / 95th percentile, z,
  `P_Value`, `P_Fisher` (Fisher combination of the CG/CHG/CHH p-values, calibrated on the same
  background windows so correlation between contexts is accounted for) and **`Excess_Score`** =
  summed score - background mean.
* New `boot_overall(boot, cutoff)` recomputes the Overall row at another cutoff (use after changing
  the significance cutoff, e.g. step 4.0 of the workflows).
* The bootstrap plot gains an Overall panel and background-mean markers; the console table prints
  the overall result.
* `run_dmr_downstream(..., boots = )` merges the bootstrap results into `_summary.csv` and
  `_summary_by_gene.csv` (`P_CG`, `P_CHG`, `P_CHH`, `Bg_Mean_Total`, `Bg_95pct_Total`,
  `Excess_Score`, `Overall_Z`, `Overall_P`, `Overall_P_Fisher`, `Overall_Evidence`) and writes
  `_bootstrap.csv`. New helper `boot_results_table()`.
* `plot_score_summary()` shows the background mean (solid) and 95th percentile (dashed) per bar and
  labels each bar with the excess score and overall p. When a treatment targeted several genes the
  figure is drawn per treatment x gene.
* Example workflows pass `overall_cutoff`, keep the overall test in sync in step 4.0 and pass
  `boots = dmr_boots` to `run_dmr_downstream()`.

# sounDMR 3.1.6
	- boot_score() revised:
		- distance to the target window is the gap between region and window, so regions
		  that partly overlap the window get distance 0 (were penalised before)
		- background windows have the same width as the target window, centred on random
		  cytosines in other genes (were single points, which made p-values optimistic)
		- bootstrap p-value = (n background >= target + 1) / (nboots + 1) over all
		  background windows (duplicates were dropped before, which made p-values
		  conservative by a data-dependent amount)
		- final score uses the background mean and SD only (SD included the target)
		- a context with no regions scores 0 instead of -Inf
		- new Background_Z = (target - background mean) / SD; Final_Score (target x z)
		  kept as before. The old 1/2/3/5 interpretation thresholds were made for small
		  scores (dmr_score2) and label nearly everything "very strong" with
		  dmr_score3/4, so the Evidence label now comes from the p-value
		- returns `summary` (per context: best region, score, background mean / SD / 95th
		  percentile, p-value, final score, evidence), `plot` (background distribution with
		  the target marked), `region_plot` and `settings`, in addition to
		  `bootstrap_scores` and `target_rs`; prints a compact table instead of raw rows
		- new `verbose` and `make_plot` arguments
	- Example workflows write <id>_bootstrap_summary.csv and <id>_bootstrap_plots.pdf

# sounDMR 3.1.5
	- sound_score(): new dmr_score4 defaults - score4_count_exponent = 0.5,
	  score4_scale = 0.7, score4_min_mean_z = 0.175 (score4_min_mean_dif stays 2).
	  Relative to dmr_score3: x0.70 at 1 cytosine, x0.92 at 5, x1.15 at 20, x1.51 at 100
	- Example workflows pass these four settings explicitly in their sound_score() calls.
	  db210 (EAB_chr6B, final cutoff 8): 3 / 7 / 10 / 17 significant DMRs for T2-T5

# sounDMR 3.1.4
	- changepoint_analysis(): new `plot_prefix` and `plot_dir` arguments. Plot files are
	  now [<plot_prefix>_]<gene>_<CX>_changepoints_<line|volcano>.png in plot_dir, with
	  the prefix also in the plot titles, so plots from different treatments no longer
	  overwrite each other. Characters unsafe in file names (e.g. ':' in
	  chr7:59866506_tr2_positive) are replaced with '_'
	- Example workflows pass plot_prefix = <treatment> and write the plots to
	  <out_dir>/changepoint_plots/. The looped scripts plot only each treatment's target
	  gene(s) by default (plot_all_genes = TRUE for every gene, as before)

# sounDMR 3.1.3
	- sound_score(): dmr_score4 is multiplied by a new `score4_scale` (default 0.9) so it is
	  on the same scale as dmr_score3 and the same cutoffs apply. With the defaults the two
	  are equal for a ~5-cytosine region; dmr_score4 is x0.90 at 1 cytosine, x1.10 at 20
	  and x1.22 at 100. On db210 (cutoff 6) it gives the same number of significant DMRs as
	  dmr_score3 (51), swapping two single-cytosine regions for two ~20-cytosine ones.
	  Set score4_scale = 1 for the 3.1.2 behaviour
	- Example workflows: deleting the off_target_trts / off_targets line no longer errors;
	  it is treated as no off-targets (same as NULL)
	- Removed inst/examples/DMR_analysis_workflow.R (outdated, did not run as written).
	  New DMR_workflow_individual.R: per-plant beta-binomial model vs. the controls on a
	  window around the target gene, with a per-plant summary table and Z-score heatmap
	- Example workflows now default to scoring_col = "dmr_score4" and a final cutoff of 8
	  in step 4.0 (new_min_sig_score <- 8; NULL keeps min_sig_score). db210 with these
	  defaults: 4 / 8 / 14 / 18 significant DMRs for T2-T5

# sounDMR 3.1.2
	- Off-target treatments: run_dmr_downstream() / add_target_stats() take `off_targets`,
	  a named list of the treatments that targeted a DIFFERENT gene for each treatment
	  (e.g. list(T2 = c("T5","T6","T7"))). Adds Off_Targets, Percent_Off_Target,
	  RD_Off_Target and Percent_Dif_vs_Off_Target to _dmrs.csv; plot_dmr_methylation()
	  shows off-target treatments in orange with a legend
	- sound_score(): new dmr_score4 (+ dmr_score4_Percentile) = dmr_score3 with region size
	  n^(1/2.5) instead of n^(1/3), giving larger regions a slight boost; exponent set by
	  `score4_count_exponent`. Signal gate: dmr_score4 is 0 for regions with |mean Z| <
	  `score4_min_mean_z` (0.25) or |mean change| < `score4_min_mean_dif` (2 % points), so
	  long flat regions can't score on size alone (flag in dmr_score4_signal). Existing
	  scores are unchanged
	- add_off_target_scores() (run automatically by run_dmr_downstream() when off-targets
	  are set): Off_Target_Fraction = (Dif_Vs_Control - Dif_Vs_Off_Target) / Dif_Vs_Control
	  and Off_Target_Adjusted_Score = score x (1 + (1 - Off_Target_Fraction)) in _dmrs.csv
	- Renamed for clarity: Percent_Dif_Observed -> Percent_Dif_vs_Control,
	  Off_Target_Dif_* -> Dif_Vs_Off_Target_*
	- Example workflows: `use_off_target` (all other treatments) replaced by explicit
	  off-target treatment sets (off_target_trts / off_targets); see README.md
	- DMR_workflow_stepwise.R: all treatments share one methyl_summary; optional step 4.0
	  re-applies a significance cutoff (one for all, or per treatment) to the kept
	  treatments without rerunning Part 3; step 3.1 check no longer fails when
	  off_target_trts is NULL
	- All example workflows (not just stepwise) have an optional step 4.0 to re-apply a
	  significance cutoff, one for all or per treatment, before run_dmr_downstream()
	- DMR_workflow.R (default) and DMR_workflow_stepwise.R are set up for db210: T2-T5 at
	  EAB_chr6B, T6-T9 as the off-target control; reproduces the saved db210 sig tables
	- Example workflows end by writing the combined methyl_summary to <id>_ms.csv and
	  saving the whole session to <id>.RData (replaces the _results.rds file)

# sounDMR 3.1.1
	- boot_score(): new optional `exclude_genes` argument to leave other genes targeted
	  by the same treatment out of the bootstrap background (default unchanged)
	- Example workflows split by experimental design (inst/examples, see README.md):
		- DMR_workflow.R: one target gene shared by all treatments (default)
		- DMR_workflow_multi_gene.R: one treatment targets several genes
		- DMR_workflow_treatment_specific_genes.R: treatments target different genes
		- DMR_workflow_stepwise.R: any design, run one treatment at a time with
		  treatment-specific penalties, windows, direction and cutoffs; writes a settings log
	- Replaces inst/examples/DMR_multi_target_workflow.R from 3.1.0
	- boot_score(): when several regions tie for the target's max score, take the first
	  (as the bootstrap rows already did) instead of warning
	- run_dmr_downstream(): a treatment x gene with no significant DMRs now appears as a
	  zero row in _summary_by_gene.csv (gene taken from the table name
	  DMR_boot_<TX>_<gene>_sig); summarise_dmrs() gains `required_keys`

# sounDMR 3.1.0
	- New downstream pipeline for significant DMRs (R/dmr_downstream.R):
		- run_dmr_downstream(): one call that combines sig-DMR tables and writes summary
		  CSVs, a BED file and figures
		- get_sig_dmrs(): threshold a boot_score() object's target regions
		- combine_sig_dmrs(): combines any number of sig tables by column name; the
		  treatment comes from the object name (DMR_boot_<TX>_sig) and the gene(s) from
		  the Gene column, so several target genes per treatment are supported
		- dmr_cytosine_data(), dmr_group_stats(), add_target_stats(): per-DMR, per-group
		  methylation and read depth as plain numeric columns (fixes the empty list-column
		  RD_Target produced by DMR_Info())
		- summarise_dmrs(), prettify_summary(): summary tables by treatment and by
		  treatment x gene; empty contexts / treatments appear as zeros
		- write_dmr_bed(): valid BED4 output (tab-separated, 0-based half-open)
		- plot_dmr_methylation(), plot_dmr_map(), plot_score_summary(): figures
	- DMR_Info() and treatment_plots() are kept for compatibility but superseded
	- NAMESPACE regenerated with roxygen2; man pages added for Treatment_Compare(),
	  cpt_compare(), treatment_plots() and DMR_Info()

# sounDMR 2.3.2
	- Added new feature to calculate number of cytosines included in a changepoint region
	- Fixed a bug in creating line plots for changepoints

# sounDMR 2.3.1
        - In create_dmr_obj():
              - Changed calculation of Percent column in LongPercent to weighted mean
              - Fixed bug in LongMeth total_RD calculation to use sum of read depths instead of mean

# sounDMR 2.3.0
	- Removed split_by_chromosome function from workflow due to bugs 
	- Improved notes for running whole genome analysis
	- Improved memory issues with group_DMR()
	- Updated figures produced by changepoint analysis

# sounDMR 2.2.2
	- Updated generate_methylframe() documentation

# sounDMR 2.2.1
	- Updated split_by_chromosome() to ignore scaffolds in the bed file
	- Bugfix for megaframe - was only saving unfiltered megaframe. Will now write out Megaframe after the NAs filter.

# sounDMR 2.2.0
	- find_DMR() local variable bugfix
	- Parameter fix for generate_methylframe() 
	- Minor updates to upstream functions
	- Added split_by_chunk that enables creating manageable chunks of the bedfile
	- updated split_by_chrom0some

# sounDMR 2.1.3
	- Bugfix for exporting max_read_depth parameter
	- minor enhancements to run generate_megaframe faster

# sounDMR 2.1.2

	- Minor readme updates
	- Minor updates to the functions
	- Bugfix in exporting split_by_chromosome function 

# sounDMR 2.1.1

* Package updated 
	-Includes bugfix for saving files with the prefix provided by the user
	-Includes bugfix for filtering the bedfile containing > max_read_depth paarmeter in the generate_methylframe the value for which can be provided by the user. 
	
# sounDMR 2.1.0

* Package updated to handle large bed files incase of whole genome sequencing
	-Includes fix for memory leaks
	-A built-in method to split large bed files by chromosome

# sounDMR 2.0.0

* Initial public release!
