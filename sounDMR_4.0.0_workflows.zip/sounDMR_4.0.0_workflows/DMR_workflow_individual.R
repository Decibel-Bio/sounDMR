# Copyright 2023 Sound Agriculture Company
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# =============================================================================
# sounDMR workflow - PER-INDIVIDUAL analysis
#   >>> set up for db210: each T2-T5 plant vs. the Water controls, around EAB_chr6B
# =============================================================================
#
# The group workflows (DMR_workflow.R etc.) ask "did treatment TX change methylation?"
# using all of its plants together. This script asks "which individual plants changed?":
# each treated plant is compared with all control plants, cytosine by cytosine, with a
# beta-binomial model, giving one Z score per plant per cytosine (<plant>_Z).
#
# It is slow - one model per cytosine per treated plant (~0.1 s per cytosine x plant
# on db210) - so it is run on a window around the target gene(s), not the whole data
# set. db210 defaults (~2,400 cytosines x 8 plants): ~30-40 min; all of EAB_chr6B
# (~13,000 cytosines): ~3 h.
#
#   Part 1  Load methyl beds, gene coordinates and experimental design   [same as DMR_workflow.R]
#   Part 2  dmr_obj, then subset to the window and the plants of interest
#   Part 3  Per-individual model  (find_DMR(analysis_type = "individual"))
#   Part 4  Per-plant summary table, Z-score heatmap, CSVs and RData
# =============================================================================

library(sounDMR)
library(data.table)
library(ggplot2)


# -----------------------------------------------------------------------------
# SETTINGS
# -----------------------------------------------------------------------------

experiment_id <- "db210"
out_dir       <- paste0(experiment_id, "_individual")

# Input files (same as DMR_workflow.R)
bed_dir      <- "."
bed_pattern  <- "\\.methylbed$"
geneco_file  <- file.choose()            # gene coordinates
gene_column  <- "Gene_Name"
design_file  <- file.choose()            # design: ID, Bedfile, Plant, Group (C/T), Treatment

# Experimental design columns / levels
target_variable <- "Treatment"
control_label   <- "Water"               # control level of `target_variable`
control_group   <- "C"                   # control level of the Group column (the model compares
                                         #   each plant with every plant in this group)
treated_group   <- "T"

# Which plants to model: every plant of these treatments (others are left out)
individual_treatments <- c("T2", "T3", "T4", "T5")

# Region to model: gene(s) and a window relative to the gene (Zeroth_pos, bp).
# Keep it focused - run time scales with (cytosines in window) x (plants).
individual_genes <- "EAB_chr6B"
window           <- c(-3000, 5000)
target_start     <- -150                 # oligo target window, marked on the heatmap
target_end       <- 3000

reads_threshold <- 5                     # min methylated AND unmethylated reads per comparison
z_threshold     <- 2                     # |Z| above this counts as a changed cytosine in the summary
bin_size        <- 100                   # bp per heatmap bin


# -----------------------------------------------------------------------------
# PART 1: Load data                                     [same as DMR_workflow.R]
# -----------------------------------------------------------------------------

methyl_bed <- list.files(path = bed_dir, pattern = bed_pattern, full.names = TRUE)
Geneco     <- read.csv(geneco_file, header = TRUE)

Methylframe <- generate_methylframe(methyl_bed_list      = methyl_bed,
                                    Sample_count         = 0,
                                    Methyl_call_type     = "Modkit",
                                    filter_NAs           = 2,
                                    gene_info            = TRUE,
                                    gene_coordinate_file = Geneco,
                                    Gene_column          = gene_column,
                                    target_info          = FALSE,
                                    File_prefix          = "Sample")

experimental_design_df <- read.csv(design_file, header = TRUE)
head(experimental_design_df)
stopifnot(control_label %in% experimental_design_df[[target_variable]],
          all(individual_treatments %in% experimental_design_df[[target_variable]]),
          all(individual_genes %in% Geneco[[gene_column]]))


# -----------------------------------------------------------------------------
# PART 2: dmr_obj, then subset to the window and the plants of interest
# -----------------------------------------------------------------------------

dmr_obj <- create_dmr_obj(Methylframe, experimental_design_df)

# Keep only cytosines in the window around the chosen gene(s)
in_window <- function(d) d$Gene %in% individual_genes &
                         d$Zeroth_pos >= window[1] & d$Zeroth_pos <= window[2]
dmr_ind <- dmr_obj
dmr_ind$ZoomFrame_filtered <- dmr_obj$ZoomFrame_filtered[in_window(dmr_obj$ZoomFrame_filtered), ]
dmr_ind$LongPercent        <- dmr_obj$LongPercent[in_window(dmr_obj$LongPercent), ]
dmr_ind$LongMeth           <- dmr_obj$LongMeth[in_window(dmr_obj$LongMeth), ]
cat("Cytosines in window:", nrow(dmr_ind$ZoomFrame_filtered), "\n")

# Per-cytosine summary for the window. Creates <plant>_Z (filled in Part 3),
# <plant>_MethChange (plant % - control mean %) and <plant>_RD for every treated plant.
methyl_summary <- create_methyl_summary(dmr_ind,
                                        control = control_group,
                                        treated = treated_group,
                                        additional_summary_cols = list(c("mean", target_variable)))

# The model loops over every Group "T" plant. Relabel plants of treatments we don't
# want so they are neither modelled nor used as controls.
design_ind <- dmr_ind$experimental_design_df
skip <- !design_ind[[target_variable]] %in% c(control_label, individual_treatments)
design_ind$Group[skip] <- "not_modelled"
dmr_ind$experimental_design_df <- design_ind
plants <- design_ind[design_ind$Group == treated_group, c("ID", "Individual_Name", target_variable)]
cat("Plants to model:", nrow(plants), "| models to fit: up to",
    nrow(plants) * nrow(dmr_ind$ZoomFrame_filtered), "\n")


# -----------------------------------------------------------------------------
# PART 3: Per-individual model
# -----------------------------------------------------------------------------
# For each cytosine and each treated plant:
#   cbind(Meth, UnMeth) ~ (1|Individual) + Group, beta-binomial,
#   data = that plant + all control plants.
# The Z score of the Group effect goes into <plant>_Z (left at 0 if not enough reads).

methyl_summary <- find_DMR(methyl_summary, dmr_ind,
                           fixed           = "Group",
                           random          = "Individual",
                           reads_threshold = reads_threshold,
                           control         = control_group,
                           model           = "beta-binomial",
                           analysis_type   = "individual")


# -----------------------------------------------------------------------------
# PART 4: Per-plant summaries and figure
# -----------------------------------------------------------------------------
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
f <- function(x) file.path(out_dir, paste0(experiment_id, x))

# Long table: one row per cytosine x plant
ms <- as.data.table(methyl_summary)
ind <- rbindlist(lapply(seq_len(nrow(plants)), function(i) {
  p <- plants$Individual_Name[i]
  ms[, .(Gene, Chromosome, Position, Zeroth_pos, Strand, CX,
         Plant = p, Treatment = plants[[target_variable]][i],
         Z          = get(paste0(p, "_Z")),
         MethChange = get(paste0(p, "_MethChange")),
         RD         = get(paste0(p, "_RD")))]
}))
ind[Z == 0, Z := NA]                     # 0 = not modelled (too few reads)
ind[, in_target := Zeroth_pos >= target_start & Zeroth_pos <= target_end]

# Per plant x context summary, for the whole window and for the oligo target window
summ_fun <- function(d) d[!is.na(Z), .(
  cytosines_modelled = .N,
  mean_Z             = round(mean(Z), 3),
  n_Z_up             = sum(Z >  z_threshold),
  n_Z_down           = sum(Z < -z_threshold),
  frac_changed       = round(mean(abs(Z) > z_threshold), 3),
  mean_MethChange    = round(mean(MethChange, na.rm = TRUE), 2)),
  by = .(Treatment, Plant, CX)]
summ <- rbind(cbind(Region = "window", summ_fun(ind)),
              cbind(Region = "target", summ_fun(ind[in_target == TRUE])))
setorder(summ, Region, Treatment, Plant, CX)
summ

fwrite(summ, f("_individual_summary.csv"))
fwrite(ind,  f("_individual_cytosines.csv"))

# Heatmap: mean Z per plant in bins along the window, one panel per context
ind[, bin := floor(Zeroth_pos / bin_size) * bin_size + bin_size / 2]
hm <- ind[!is.na(Z), .(Z = mean(Z)), by = .(Treatment, Plant, CX, bin)]
plant_order <- plants[order(plants[[target_variable]], plants$Individual_Name), "Individual_Name"]
lab <- setNames(paste(plants[[target_variable]], plants$Individual_Name, sep = " / "),
                plants$Individual_Name)
hm[, Plant := factor(lab[Plant], levels = rev(lab[plant_order]))]
hm[, CX := factor(CX, levels = c("CG", "CHG", "CHH"))]
p <- ggplot(hm, aes(bin, Plant, fill = pmax(pmin(Z, 4), -4))) +
  geom_tile(width = bin_size, height = 0.9) +
  annotate("rect", xmin = target_start, xmax = target_end, ymin = -Inf, ymax = Inf,
           fill = NA, colour = "grey30", linetype = "dashed", linewidth = 0.4) +
  scale_fill_gradient2(low = "#2a78d6", mid = "#f2f2f2", high = "#eb6834", midpoint = 0,
                       limits = c(-4, 4), name = "Mean Z\n(plant vs\ncontrols)") +
  facet_grid(CX ~ ., scales = "free_y", space = "free_y") +
  labs(x = paste0("Position relative to ", paste(individual_genes, collapse = ", "),
                  " (bp); dashed = oligo target window"), y = NULL,
       title = paste(experiment_id, "- per-plant methylation change vs. controls")) +
  theme_minimal(base_size = 10) +
    theme(plot.background = element_rect(fill = "white", colour = NA)) +
  theme(panel.grid = element_blank(), strip.text = element_text(face = "bold"))
ggsave(f("_individual_heatmap.pdf"), p, width = 10, height = 2 + 0.25 * nrow(plants) * 3)

# Per-cytosine methyl_summary for the window, and the whole session
fwrite(methyl_summary, f("_individual_ms.csv"))
save.image(f("_individual.RData"))
